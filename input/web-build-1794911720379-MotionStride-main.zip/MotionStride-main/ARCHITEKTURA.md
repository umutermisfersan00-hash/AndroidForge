# PrismForge 1.7 – élő komponensek

```
MainActivity (indítás, profil, tesztidőzítő, app-only kiválasztó)
  ├─ NativeLsfgShaders (+ DllInspector): Lossless.dll → SPIR-V
  ├─ PrismForgeAccessibilityService: trusted touch-through ablak
  └─ NativeLsfgService: ImageReader → AHardwareBuffer → NativeBridge / liblsfg-android.so
       ├─ GameVideoOverlay: teljes felületű TextureView
       └─ NativeLsfgStats: teljesítmény és crash diagnosztika
```

## Profilparaméterek
- Natív gyorsított: EXTRA_FAST=false, flowScale=0.45, eredeti belső felbontás.
- 720p gyorsított: EXTRA_FAST=true, flowScale=0.45, tájolásnál követett 1560×720 körüli belső felbontás.
- Azonos initContext, performance, FP16, queue, pacing és shader útvonal.

## Időzítés
- EXTRA_TIMEOUT_MS=0: nem indul session-autostop; a munkamenet a felhasználó vagy az OS leállításáig fut.
- Pozitív érvényes idő: egyszeri autoStop a teljes képernyős réteg aktiválásától.
- A 24 másodperces, csak az első kép/játékfelbontás beérkezésére vonatkozó indulási védőkorlát megmaradt.

A korábbi Capture Lab, GPU Bridge, Temporal Blend, GameProbe és szintetikus 120 Hz demó nincs a projektben.
