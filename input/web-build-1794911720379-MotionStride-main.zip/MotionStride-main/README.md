# MotionStride

MotionStride is an experimental Android application that brings real-time frame generation to games and other apps. It captures one selected application, processes its frames through an ARM64 Vulkan pipeline, generates intermediate frames with LSFG, and displays the result in a full-screen accessibility overlay.

The goal is simple: make lower input frame rates look smoother on high-refresh-rate Android displays. For example, a game running around 60 FPS can be presented closer to 120 FPS by alternating captured and generated frames.

> MotionStride is an independent community project. It is not affiliated with, endorsed by, or distributed by the developers of Lossless Scaling.

## What it does

- Real-time LSFG frame generation through Vulkan on ARM64 Android devices.
- Native accelerated and reduced-resolution 720p processing profiles.
- 2x and 4x frame-generation modes, limited by the display's maximum refresh rate.
- Direct `AHardwareBuffer` capture path designed to reduce full-frame memory copies.
- Automatic compatibility fallback plus manually selectable `AUTO`, `DIR`, and `SAFE` paths.
- Movable in-game performance HUD showing game FPS, posted FPS, frame time, thermal state, queue timing, and diagnostics.
- Portrait and landscape application capture with dynamic aspect-ratio handling.
- English and Hungarian interface following the system language.
- No internet permission. Captured images and imported files remain on the device.

## How it works

At a high level, the processing chain is:

```text
Android app-only capture
        ↓
ImageReader / AHardwareBuffer
        ↓
ARM64 Vulkan + LSFG frame generation
        ↓
Full-screen accessibility overlay
```

MotionStride deliberately asks Android to capture a single selected application rather than the whole display. Full-display capture would include MotionStride's own output overlay and create a feedback loop.

The direct path imports capture buffers into Vulkan without performing the older full-screen CPU copy. A copied `SAFE` path remains available for devices or drivers where direct buffer import is unstable.

## Requirements

- A 64-bit ARM Android device with Vulkan support.
- Android 17 for the current app-only capture implementation.
- A high-refresh-rate display is strongly recommended.
- The MotionStride accessibility service must be enabled.
- A legally obtained copy of `Lossless.dll` from Lossless Scaling on Steam.

The application does **not** include or distribute `Lossless.dll`, Lossless Scaling, or its proprietary shader binaries. You must own Lossless Scaling and import your own DLL into MotionStride. The app extracts the required shader data locally on the device.

## Basic setup

1. Build and install MotionStride.
2. Open the app and enable its accessibility service.
3. In Steam, open the installed Lossless Scaling files:
   - Lossless Scaling → **Properties**
   - **Installed Files** → **Browse**
4. Copy `Lossless.dll` to the Android device.
5. In MotionStride, expand **Lossless.dll**, select **Import**, and choose the copied file.
6. Select a processing profile and press **Start LSFG**.
7. In Android's capture dialog, select the game or application itself. Do not select the entire screen.

If Android blocks the accessibility permission for a manually installed APK, open MotionStride's system app-info page, use the three-dot menu, select **Allow restricted settings**, and try again.

## Processing profiles

### Native accelerated

Processes the selected application at its captured resolution. This provides the best image quality but has the highest GPU and memory-bandwidth cost.

### 720p accelerated

Preserves the selected application's aspect ratio while reducing the internal long edge to approximately 1560 pixels (about 1560×720 on a 19.5:9 display). This reduces frame-generation cost and may behave better under sustained load.

## Compatibility modes

- **AUTO** — uses the direct buffer path and can fall back to the copied path if necessary.
- **DIR** — keeps the direct `AHardwareBuffer` path active. This is normally the fastest option on supported devices.
- **SAFE** — forces the older copied-buffer path. It is intended for compatibility, not higher performance.

On the device used during development, `DIR` substantially reduces copy time. Under prolonged heavy gaming, thermal throttling can still become the primary limit: frame generation cannot create GPU capacity that the device has removed through thermal power management.

## Current limitations

- Hardware and driver behaviour vary significantly between Android devices.
- Sustained 120 FPS is not guaranteed, especially while the phone is thermally throttled.
- Generated frames can show artifacts around moving characters, disocclusions, particles, and UI elements.
- The accessibility overlay covers other visual layers while streaming. The HUD or foreground notification should be used to stop the session; turning the screen off also ends it safely.
- This is an experimental debug-oriented project, not a finished Play Store release.

## Building

The project is intended to be opened in Android Studio.

Required native toolchain:

- Android SDK 36 or newer
- Android NDK `27.0.12077973`
- CMake `3.22.1`
- ARM64 target device

The repository defaults to the CMake/native source route:

```properties
prismforgeNativeMode=cmake
prismforgeDirectAhb=true
```

Build the `app` debug variant in Android Studio, or run the Gradle wrapper from an environment that provides Java and a POSIX-compatible shell:

```bash
./gradlew :app:assembleDebug -PprismforgeNativeMode=cmake
```

The generated APK is placed under:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Privacy

MotionStride has no internet permission. Captured frames are processed in memory on the device. Imported files and extracted shader data stay in the app's private local storage.

## Project status

MotionStride is under active experimentation. The current focus is stable frame pacing, lower memory bandwidth, direct capture-buffer reuse, compatibility across Vulkan drivers, and acceptable performance during thermal throttling.

Bug reports should include the device model, Android version, selected profile and compatibility mode, display refresh rate, and relevant MotionStride diagnostics.

## License and third-party components

The Android application is distributed under the GNU General Public License v3. See [`LICENSES/LSFG_Android_App_LICENSE.txt`](LICENSES/LSFG_Android_App_LICENSE.txt).

The repository also contains components under their respective licenses, including `lsfg-vk`, Volk, DXBC parsing code, and PE parsing code. The corresponding license texts are retained in the [`LICENSES`](LICENSES) directory and within the relevant source directories.

Lossless Scaling and LSFG are property of their respective rights holders. No proprietary Lossless Scaling DLL or extracted shader package is included in this repository.
