package com.prismforge.mobile;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.HardwareBuffer;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Surface;
import com.frameflow.s25.session.NativeBridge;

/**
 * App-only MediaProjection -> RGBA ImageReader -> native LSFG 3.1 Vulkan ->
 * trusted, opaque, touch-through TextureView output.
 *
 * v1.5.0: The capture HandlerThread NEVER runs the potentially multi-second
 * Vulkan initContext. MediaProjection resize callbacks stay responsive while
 * native setup takes place. We wait for the selected game's actual stable
 * LANDSCAPE dimensions before initializing the engine. A late size change
 * invalidates the in-flight setup and safely re-creates its context, using
 * the same one-time MediaProjection consent / VirtualDisplay session.
 */
public final class NativeLsfgService extends Service {
    private static final int COMPAT_AUTO=0,COMPAT_DIRECT=1,COMPAT_STABLE=2;
    public static final String START = "com.prismforge.mobile.NATIVE_LSFG_START";
    public static final String STOP = "com.prismforge.mobile.NATIVE_LSFG_STOP";
    public static final String EXTRA_CODE = "lsfg_code", EXTRA_DATA = "lsfg_data";
    public static final String EXTRA_W = "lsfg_width", EXTRA_H = "lsfg_height";
    public static final String EXTRA_APP_ONLY = "lsfg_app_only";
    public static final String EXTRA_FAST = "lsfg_fast";
    public static final String EXTRA_HUD_ENABLED = "lsfg_hud_enabled";
    public static final String EXTRA_TIMEOUT_MS = "lsfg_timeout_ms";
    private static final int NOTIFY_ID = 563;
    // Session timeout is opt-in, supplied by the UI. Zero = unlimited.
    private static final long CAPTURE_READY_TIMEOUT_MS = 24_000L;
    private static final long RESIZE_QUIET_MS = 950L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread captureThread, nativeThread, telemetryThread;
    private Handler capture, engine, telemetryHandler;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private NativeBridge nativeBridge;
    private GameVideoOverlay overlay;

    // Written by the capture Looper, read by the native Looper. Java volatile
    // establishes the needed happens-before relationship for the dimensions.
    private volatile int width, height, captureRevision;
    // App dimensions are tracked separately from the scaled VirtualDisplay output.
    // The Android size callback always reports the real selected application bounds.
    private volatile int appWidth, appHeight;
    private volatile boolean fastMode;
    private volatile boolean hudEnabled=true;
    private volatile boolean leasedCaptureSupported;
    private volatile boolean hashedLeaseSupported;
    private long sessionTimeoutMs;
    private volatile boolean appVisible = true;
    private volatile long lastResizeMs, inputFrames;
    private volatile long lastNativeQueuePollMs;
    private volatile boolean hasSizeCallback, nativeReady, stopping;
    private volatile int nativeRevision = -1; // written by native thread, read by capture
    private boolean contextLive;    // native-thread only
    private volatile Surface outputSurface;
    private volatile Surface surfaceToReleaseOnExit;
    private volatile int outputW, outputH;
    private volatile int requestedMultiplier=2, activeMultiplier=2;
    private volatile float activeFlowScale=0.45f;
    private volatile float displayMaxFps=120f;
    private volatile int compatibilityMode=COMPAT_AUTO;
    private long lastMultiplierChangeMs;
    private long lastAwaitingLogMs;
    // Capture thread only; re-created when the selected application's size changes.
    private CaptureCadence captureCadence = new CaptureCadence();
    private FrameSignature.Sampler signatureSampler = new FrameSignature.Sampler();
    private long lastCadenceReportMs;
    private long lastThermalPollMs;
    private long lastOverloadNoticeMs;
    private DeviceTelemetry deviceTelemetry;
    private boolean screenOffReceiverRegistered;
    private final BroadcastReceiver screenOffReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context context,Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction()) && !stopping) {
                NativeLsfgStats.note("SCREEN_OFF: stopping stream");
                stopSelf();
            }
        }
    };
    private final Runnable pollTelemetry = new Runnable() {
        @Override public void run() {
            if (stopping || telemetryHandler == null) return;
            try {
                NativeLsfgStats.telemetry(deviceTelemetry.sample());
                // If the native statistics poll stalls, the independent CPU/RAM
                // observer can still refresh the panel with the last known FPS.
                NativeLsfgStats.Snapshot latest = NativeLsfgStats.snapshot();
                main.post(() -> { if (!stopping && overlay != null) overlay.update(latest); });
            }
            catch (Throwable t) { NativeLsfgStats.note("PERF_MONITOR unavailable: " + t); }
            if (!stopping) telemetryHandler.postDelayed(this, 1900L);
        }
    };

    private final Runnable autoStop = () -> {
        if (!stopping) { NativeLsfgStats.note("TEST_TIMER: session duration ended (" + sessionTimeoutMs + "ms)"); stopSelf(); }
    };
    private final Runnable captureReadyTimeout = () -> {
        if (!stopping && !nativeReady) {
            NativeLsfgStats.error(getString(R.string.capture_timeout,width,height));
            stopSelf();
        }
    };
    private final Runnable settleCheck = this::maybeStartNative;
    private final Runnable updateCounters = new Runnable() {
        @Override public void run() {
            if (stopping || engine == null) return;
            if (nativeReady) {
                try {
                    NativeLsfgStats.poll(nativeBridge);
                    // Capture native load metrics without trying to request an
                    // unsupported queue depth. The shipped binary clamps its
                    // queue to >=2; silently requesting 1 cannot improve pacing.
                    NativeLsfgStats.LoadSnapshot load = NativeLsfgStats.loadSnapshot();
                    long overloadNow = SystemClock.elapsedRealtime();
                    if (load.wallMs >= 16.67 && load.postedFps > 0 &&
                        load.postedFps < 100.0 && load.queueMs >= 8.0 &&
                        overloadNow - lastOverloadNoticeMs >= 5000L) {
                        lastOverloadNoticeMs = overloadNow;
                        NativeLsfgStats.note(String.format(java.util.Locale.ROOT,
                            "CAPACITY_LIMIT: wall=%.2fms > 16.67ms/frame, queue=%.2fms, post=%.1fFPS; " +
                            "native queue stays 2 (binary requires >=2)",
                            load.wallMs, load.queueMs, load.postedFps));
                    }
                    // Thermal status changes much more slowly than frame stats.
                    // Avoid an OS service query at every 650-ms FPS poll.
                    long nowMs = SystemClock.elapsedRealtime();
                    if (Build.VERSION.SDK_INT >= 29 &&
                        (lastThermalPollMs == 0 || nowMs - lastThermalPollMs >= 4000L)) {
                        lastThermalPollMs = nowMs;
                        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                        if (pm != null) NativeLsfgStats.setThermalStatus(pm.getCurrentThermalStatus());
                    }
                    NativeLsfgStats.Snapshot diagnostics = NativeLsfgStats.snapshot();
                    maybeAutoMultiplier(diagnostics);
                    main.post(() -> { if (!stopping && overlay != null) overlay.update(diagnostics); });
                } catch (Throwable t) { NativeLsfgStats.error("Native stats: " + t); }
            }
            if (!stopping) engine.postDelayed(this, 650L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
            new NotificationChannel("prismforge_lsfg_native", getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW));
        IntentFilter screenFilter=new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT>=33)
            registerReceiver(screenOffReceiver,screenFilter,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenOffReceiver,screenFilter);
        screenOffReceiverRegistered=true;
    }
    @SuppressWarnings("deprecation")
    private static Intent consentFrom(Intent i) {
        return Build.VERSION.SDK_INT >= 33 ? i.getParcelableExtra(EXTRA_DATA, Intent.class) : i.getParcelableExtra(EXTRA_DATA);
    }
    private Notification notification() {
        PendingIntent stop = PendingIntent.getService(this, 123,
            new Intent(this, NativeLsfgService.class).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(this, 124,
            new Intent(this, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "prismforge_lsfg_native")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(sessionTimeoutMs > 0 ? getString(R.string.notification_running_test) : getString(R.string.notification_running))
            .setOngoing(true).setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, getString(R.string.stop), stop).build();
    }
    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (i == null) return START_NOT_STICKY;
        if (STOP.equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!START.equals(i.getAction()) || captureThread != null || stopping) return START_NOT_STICKY;
        try {
            if (Build.VERSION.SDK_INT < 37 || !i.getBooleanExtra(EXTRA_APP_ONLY, false))
                throw new IllegalStateException("SDK37 APP-ONLY permission request required");
            int code = i.getIntExtra(EXTRA_CODE, 0);
            Intent data = consentFrom(i);
            width = i.getIntExtra(EXTRA_W, 0);
            height = i.getIntExtra(EXTRA_H, 0);
            appWidth = width; appHeight = height;
            fastMode = i.getBooleanExtra(EXTRA_FAST, false);
            hudEnabled = i.getBooleanExtra(EXTRA_HUD_ENABLED, true);
            compatibilityMode=getSharedPreferences("motionstride",MODE_PRIVATE)
                .getInt("compatibility_mode",COMPAT_AUTO);
            long requestedTimeout = i.getLongExtra(EXTRA_TIMEOUT_MS, 0L);
            sessionTimeoutMs = requestedTimeout >= 30_000L && requestedTimeout <= 3_600_000L
                ? requestedTimeout : 0L;
            startForeground(NOTIFY_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            if (code != Activity.RESULT_OK || data == null || width <= 0 || height <= 0)
                throw new IllegalStateException("Missing MediaProjection consent");
            if (!PrismForgeAccessibilityService.isReady())
                throw new IllegalStateException("Trusted Accessibility overlay not enabled");
            if (!NativeLsfgShaders.available(this))
                throw new IllegalStateException("Import your Lossless.dll shaders first");
            NativeLsfgStats.reset(width, height);
            NativeLsfgStats.setMode(getString(fastMode ? R.string.mode_fast_720p : R.string.mode_native_fast));
            NativeLsfgStats.note("MotionStride 1.9.19: aligned dashboard; selectable compatibility path; " +
                (fastMode ? "720p internal capture" : "native internal capture") +
                ", flow=" + flowScale() + ", queue=3, cap=120, session timeout=" + sessionTimeoutMs + "ms");
            nativeBridge = new NativeBridge();
            String libId = nativeBridge.nativeVersion();
            // Capability matching intentionally uses the stable feature prefix,
            // not an exact release suffix.  The previous build shipped the
            // complete direct-AHB implementation under a newer version marker,
            // so this exact-string gate silently kept zero-copy disabled.
            leasedCaptureSupported = BuildConfig.DIRECT_AHB_EXPERIMENT &&
                libId != null && libId.contains("direct-ahb");
            hashedLeaseSupported = leasedCaptureSupported &&
                libId.contains("capture-admission");
            NativeLsfgStats.note("DIRECT_AHB_BUILD: optIn=" + BuildConfig.DIRECT_AHB_EXPERIMENT +
                " leasedCapture=" + leasedCaptureSupported + " native=" + libId);
            NativeLsfgStats.note("Native lib: " + nativeBridge.nativeVersion());
            try {
                nativeBridge.initCrashReporter(
                    new java.io.File(getFilesDir(), "lsfg_last_crash.txt").getAbsolutePath(),
                    new java.io.File(getFilesDir(), "lsfg_native_trace.txt").getAbsolutePath());
                NativeLsfgStats.note("Native crash logger enabled (private app files; retained after crash)");
            } catch (Throwable t) { NativeLsfgStats.note("Native crash logger unavailable: " + t); }
            captureThread = new HandlerThread("MotionStrideCaptureEvents");
            nativeThread = new HandlerThread("MotionStrideSlowVulkanInit");
            telemetryThread = new HandlerThread("MotionStrideCpuRamProbe", android.os.Process.THREAD_PRIORITY_BACKGROUND);
            captureThread.start(); nativeThread.start(); telemetryThread.start();
            capture = new Handler(captureThread.getLooper());
            engine = new Handler(nativeThread.getLooper());
            telemetryHandler = new Handler(telemetryThread.getLooper());
            deviceTelemetry = new DeviceTelemetry(this);
            telemetryHandler.post(pollTelemetry);
            capture.post(() -> {
                try { startCapture(code, data); }
                catch (Throwable t) { failure("Capture start: " + t); }
            });
            main.postDelayed(captureReadyTimeout, CAPTURE_READY_TIMEOUT_MS);
        } catch (Throwable t) { failure("Service startup: " + t); }
        return START_NOT_STICKY;
    }
    private void failure(String message) {
        if (stopping) return;
        NativeLsfgStats.error(message);
        stopSelf();
    }
    private void startCapture(int code, Intent token) {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(code, token);
        if (projection == null) throw new IllegalStateException("MediaProjection null");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                if (stopping) return;
                NativeLsfgStats.status(getString(R.string.capture_stopped));
                stopSelf();
            }
            @Override public void onCapturedContentResize(int w, int h) {
                // Handler is capture: never blocked by Vulkan shader compilation.
                if (!stopping && w > 0 && h > 0) onAppSize(w, h);
            }
            @Override public void onCapturedContentVisibilityChanged(boolean visible) {
                appVisible = visible;
                NativeLsfgStats.note("App visible: " + visible);
            }
        }, capture);
        makeReader(width, height);
        virtualDisplay = projection.createVirtualDisplay("MotionStrideNativeLSFG",
            width, height, getResources().getConfiguration().densityDpi,
            0, reader.getSurface(), null, capture);
        if (virtualDisplay == null) throw new IllegalStateException("createVirtualDisplay failed");
        NativeLsfgStats.status(getString(R.string.capture_waiting_size));
        // The first onCapturedContentResize supplies the selected APP's size.
        // We must not trust the portrait dimensions of the PrismForge picker.
        engine.post(updateCounters);
    }
    private void makeReader(int w, int h) {
        // The direct AHB experiment retains Java Images until their GPU users
        // retire; it needs more than two ImageReader acquisition slots. A
        // bounded pool prevents Image.close() recycling in-flight GPU inputs.
        // The normal copied pipeline keeps the original two-slot allocation.
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888,
            leasedCaptureSupported ? 8 : 2,
            HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE |
            HardwareBuffer.USAGE_GPU_COLOR_OUTPUT);
        reader.setOnImageAvailableListener(r -> {
            Image img = null;
            try {
                // No growing image queue while native shaders initialize.
                img = r.acquireLatestImage();
                if (img == null || stopping) return;
                inputFrames++;
                boolean eligible = nativeReady && nativeRevision == captureRevision &&
                    img.getWidth() == width && img.getHeight() == height;
                if (eligible) {
                    // Match the native 8x8 luma signature. Skip duplicates and
                    // steady the timestamps of UNIQUE frames, not every 120Hz
                    // MediaProjection callback. On an unreadable pixel buffer
                    // CaptureCadence returns the original timestamp untouched.
                    int signature = signatureSampler.hash(img);
                    CaptureCadence.Result cadence = captureCadence.accept(img.getTimestamp(), signature);
                    boolean forward = cadence.forward;
                    HardwareBuffer hb = forward ? img.getHardwareBuffer() : null;
                    if (hb != null) {
                        NativeLsfgStats.frame(true);
                        try {
                            if (leasedCaptureSupported) {
                                // On success native owns Image.close(), including
                                // queue-drop and session-shutdown paths.
                                boolean leased = hashedLeaseSupported
                                    ? nativeBridge.pushFrameLeasedWithHash(hb, img, cadence.timestampNs, signature)
                                    : nativeBridge.pushFrameLeased(hb, img, cadence.timestampNs);
                                if (leased) {
                                    img = null;
                                } else {
                                    nativeBridge.pushFrame(hb, cadence.timestampNs);
                                }
                            } else nativeBridge.pushFrame(hb, cadence.timestampNs);
                        } finally { hb.close(); }
                    } else NativeLsfgStats.frame(false);
                    long nowMs = SystemClock.elapsedRealtime();
                    if (nowMs - lastCadenceReportMs >= 1200L) {
                        lastCadenceReportMs = nowMs;
                        NativeLsfgStats.inputCadence(
                            captureCadence.getEstimatedFps(), captureCadence.rawJitterP95Ms(),
                            captureCadence.smoothJitterP95Ms(), captureCadence.getDuplicates(),
                            captureCadence.getRebases(), captureCadence.getUnavailable());
                    }
                } else NativeLsfgStats.frame(false);
            } catch (IllegalStateException busy) {
                // During the opt-in direct path, all ImageReader slots can be
                // leased briefly. Wait for the native GPU-fence poller to
                // return a slot instead of tearing down the whole stream.
                if (leasedCaptureSupported)
                    NativeLsfgStats.note("DIRECT_AHB_BACKPRESSURE: ImageReader waiting for GPU release");
                else failure("AHardwareBuffer input: " + busy);
            } catch (Throwable t) { failure("AHardwareBuffer input: " + t); }
            finally { if (img != null) img.close(); }
        }, capture);
    }
    /** Preserve the selected game's aspect ratio, but process fewer pixels in
     *  Vulkan. Android scales the app into the VirtualDisplay surface. The
     *  Accessibility window stays at the phone's FULL physical resolution.
     */
    private int[] scaledCapture(int sourceW, int sourceH) {
        if (!fastMode) return new int[]{sourceW, sourceH};
        // Scale either orientation by its long edge; never bake in a device
        // resolution or assume landscape.
        final float scale = Math.min(1.0f, 1560f / Math.max(sourceW,sourceH));
        int w = Math.max(2, Math.round(sourceW * scale / 2f) * 2);
        int h = Math.max(2, Math.round(sourceH * scale / 2f) * 2);
        return new int[]{w, h};
    }
    private void onAppSize(int w, int h) {
        if (stopping || virtualDisplay == null) return;
        hasSizeCallback = true;
        boolean sourceChanged = w != appWidth || h != appHeight;
        appWidth = w; appHeight = h;
        int[] dest = scaledCapture(w,h);
        int rw = dest[0], rh = dest[1];
        if (rw != width || rh != height) {
            // Pause pushes before replacing the ImageReader buffers.
            nativeReady = false;
            captureCadence = new CaptureCadence();
            signatureSampler = new FrameSignature.Sampler();
            lastCadenceReportMs = 0L;
            // Preserve the last landscape INPUT_CADENCE sample in exported
            // diagnostics; after returning to the app the portrait transition
            // must not erase the only useful in-game jitter measurements.
            int rev = ++captureRevision;
            NativeLsfgStats.dims(rw,rh);
            NativeLsfgStats.note("CAPTURE_RESIZE rev=" + rev + ": app=" + w + "x" + h +
                " -> GPU=" + rw + "x" + rh + " (was " + width + "x" + height + ")");
            try {
                virtualDisplay.setSurface(null);
                reader.setOnImageAvailableListener(null, null);
                reader.close(); reader = null;
                width = rw; height = rh;
                makeReader(rw, rh);
                virtualDisplay.resize(rw, rh, getResources().getConfiguration().densityDpi);
                virtualDisplay.setSurface(reader.getSurface());
            } catch (Throwable e) { failure("MediaProjection scaled resize: " + e); return; }
        } else if (sourceChanged) {
            // App dimensions can change even when the chosen processing size
            // stays the same. Keep the settling timer, do not rebuild the GPU.
            NativeLsfgStats.note("App source dimensions: " + w + "x" + h +
                " | GPU: " + rw + "x" + rh);
        }
        // Avoid endlessly postponing the quiet timer if Android repeats an
        // unchanged size callback. Only meaningful size changes reset it.
        if (sourceChanged || lastResizeMs == 0L) {
            lastResizeMs = SystemClock.elapsedRealtime();
            capture.removeCallbacks(settleCheck);
            capture.postDelayed(settleCheck, RESIZE_QUIET_MS);
        }
    }
    private void maybeStartNative() {
        if (stopping || !hasSizeCallback || nativeReady) return;
        long quiet = SystemClock.elapsedRealtime() - lastResizeMs;
        if (quiet < RESIZE_QUIET_MS) {
            capture.postDelayed(settleCheck, RESIZE_QUIET_MS - quiet);
            return;
        }
        if (inputFrames < 2) {
            capture.postDelayed(settleCheck, 350L);
            return;
        }
        final int req = captureRevision, w = width, h = height;
        NativeLsfgStats.note("STABLE_APP_SIZE: " + w + "x" + h + " rev=" + req +
            " -> native init queued on independent worker");
        engine.post(() -> initializeNative(req, w, h));
    }
    private float flowScale() {
        return activeFlowScale;
    }
    private void initializeNative(int revision, int w, int h) {
        if (stopping || revision != captureRevision) return;
        if (contextLive) {
            nativeReady = false;
            try { nativeBridge.setOutputSurface(null, 0, 0); nativeBridge.destroyContext(); }
            catch (Throwable t) { failure("Native reset on resize: " + t); return; }
            contextLive = false;
        }
        try {
            NativeLsfgStats.status("LSFG Vulkan init " + w + "x" + h + " (app resize callback remains live)");
            long startNs = SystemClock.elapsedRealtime();
            // The library already supports an optimized LSFG 3.1P context.
            // Use it on the full-resolution comparison path too so the two
            // experiments differ principally in pixels, not engine selection.
            boolean halfPrecision = nativeBridge.isFramegenFp16Supported(
                NativeLsfgShaders.cache(this).getAbsolutePath());
            NativeLsfgStats.note("LSFG_SETUP perf=1 flowScale=" + flowScale() +
                " fp16=" + halfPrecision + " antiArtifacts=0 queue=3 cap=120, pacing slack=1ms");
            int rc = nativeBridge.initContext(NativeLsfgShaders.cache(this).getAbsolutePath(),
                w, h, activeMultiplier, flowScale(), true, false, false, halfPrecision,
                false, 0, 1, 0f, 1f, 0f, false,
                false, 0, 0f, 0f, 0f, 0f,
                false, 0, 0, 1f, 0f, 0f,
                120, 0.12f, 3.0f, 1.0f, 3);
            NativeLsfgStats.note("INIT_RESULT " + w + "x" + h + " rev=" + revision +
                " rc=" + rc + " elapsed=" + (SystemClock.elapsedRealtime() - startNs) + "ms");
            if (stopping || revision != captureRevision || w != width || h != height) {
                // Rotation happened DURING the multi-second Vulkan init.
                // Destroy the stale context and let the queued stable resize
                // start a new one, without stopping MediaProjection.
                NativeLsfgStats.note("STALE_INIT_DISCARDED: landscape size changed during Vulkan compilation");
                try { nativeBridge.destroyContext(); } catch (Throwable ignored) { }
                contextLive = false;
                return;
            }
            NativeLsfgStats.initResult(rc);
            if (rc != 0) {
                NativeLsfgStats.note("Performance path init rc=" + rc + "; retry normal LSFG 3.1");
                try { nativeBridge.destroyContext(); } catch (Throwable ignored) { }
                rc = nativeBridge.initContext(NativeLsfgShaders.cache(this).getAbsolutePath(),
                    w, h, activeMultiplier, flowScale(), false, false, false, false,
                    false, 0, 1, 0f, 1f, 0f, false,
                    false, 0, 0f, 0f, 0f, 0f,
                    false, 0, 0, 1f, 0f, 0f,
                    120, 0.12f, 3.0f, 1.0f, 3);
                NativeLsfgStats.note("FALLBACK_INIT_RESULT rc=" + rc);
                NativeLsfgStats.initResult(rc);
                if (rc != 0) {
                    try { nativeBridge.destroyContext(); } catch (Throwable ignored) { }
                    failure("LSFG Vulkan init rc=" + rc); return;
                }
            }
            contextLive = true;
            if (leasedCaptureSupported) {
                nativeBridge.setDirectFallbackAllowed(compatibilityMode!=COMPAT_DIRECT);
                nativeBridge.setDirectCaptureEnabled(compatibilityMode!=COMPAT_STABLE);
                NativeLsfgStats.note("COMPATIBILITY_MODE="+
                    (compatibilityMode==COMPAT_DIRECT?"DIRECT_LOCKED":
                     compatibilityMode==COMPAT_STABLE?"STABLE_COPY":"AUTO"));
            }
            // JNI is already exported by this exact liblsfg-android.so.
            // The older 0.25ms slack was silently clamped to 2ms by native code.
            int outputCap=Math.max(30,Math.round(displayMaxFps));
            nativeBridge.setPacingParams(outputCap, 0.12f, 3.0f, 1.0f, 3);
            NativeLsfgStats.note("PACING_APPLIED: cap="+outputCap+" alpha=0.12 outlier=3.0 slack=1.0ms queue=3");
            nativeRevision = revision;
            nativeReady = true;
            NativeLsfgStats.resetNativeRates();
            lastOverloadNoticeMs = 0;
            NativeLsfgStats.status(getString(R.string.context_active,activeMultiplier,w,h));
            bindOutputIfReady();
            main.post(() -> {
                if (!stopping && nativeReady) {
                    main.removeCallbacks(captureReadyTimeout);
                    if (overlay == null) showOverlay();
                    else overlay.update(NativeLsfgStats.snapshot());
                }
            });
        } catch (Throwable t) { failure("Native Vulkan init: " + t); }
    }
    private void bindOutputIfReady() {
        Surface surface = outputSurface;
        if (stopping || !nativeReady || !contextLive || surface == null || !surface.isValid()) return;
        try {
            nativeBridge.setOutputSurface(surface, outputW, outputH);
            nativeBridge.setVsyncPeriodNs((long)(1_000_000_000.0/Math.max(30f,displayMaxFps)));
            NativeLsfgStats.note("Output surface connected to LSFG: " + outputW + "x" + outputH);
        } catch (Throwable t) { failure("Native output attach: " + t); }
    }
    private void showOverlay() {
        if (stopping || overlay != null) return;
        PrismForgeAccessibilityService accessibility = PrismForgeAccessibilityService.current();
        if (accessibility == null) { failure("AccessibilityService disconnected"); return; }
        overlay = new GameVideoOverlay(accessibility, new GameVideoOverlay.Callback() {
            @Override public void surfaceAvailable(Surface surface, int w, int h) {
                outputSurface = surface;
                outputW = w; outputH = h;
                if (Build.VERSION.SDK_INT >= 30) {
                    try { surface.setFrameRate(displayMaxFps, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT); }
                    catch (Throwable ignored) { }
                }
                if (engine != null) engine.post(NativeLsfgService.this::bindOutputIfReady);
            }
            @Override public void surfaceGone(Surface surface) {
                if (outputSurface == surface) outputSurface = null;
                if (stopping) {
                    // onDestroy cancels pending native callbacks: release this
                    // Surface after the engine has detached its native window.
                    surfaceToReleaseOnExit = surface;
                    return;
                }
                if (engine != null) engine.post(() -> {
                    try { if (contextLive) nativeBridge.setOutputSurface(null, 0, 0); }
                    catch (Throwable t) { NativeLsfgStats.note("Surface detach: " + t); }
                    finally { surface.release(); }
                });
                else surface.release();
            }
            @Override public void stopRequested() {
                NativeLsfgStats.note("HUD requested stream stop");
                stopSelf();
            }
            @Override public void multiplierRequested(int multiplier) {
                requestMultiplier(multiplier);
            }
            @Override public void flowScaleRequested(float flowScale) {
                requestFlowScale(flowScale);
            }
            @Override public void compatibilityRequested(int mode) {
                requestCompatibilityMode(mode);
            }
        });
        displayMaxFps=overlay.getMaximumRefreshRate();
        if(engine!=null)engine.post(()->{
            if(contextLive)nativeBridge.setPacingParams(
                Math.max(30,Math.round(displayMaxFps)),0.12f,3.0f,1.0f,3);
        });
        overlay.setSessionInfo(requestedMultiplier,activeMultiplier,width,height,displayMaxFps,activeFlowScale);
        overlay.setCompatibilityMode(compatibilityMode);
        overlay.setSessionTimeout(sessionTimeoutMs);
        overlay.setMonitorEnabled(hudEnabled);
        if (!overlay.show()) { failure("Trusted overlay failed to create"); return; }
        overlay.update(NativeLsfgStats.snapshot());
        NativeLsfgStats.note("100% trusted output shown; app-only capture remains separated");
        if (sessionTimeoutMs > 0L) {
            main.postDelayed(autoStop, sessionTimeoutMs);
            NativeLsfgStats.note("TEST_TIMER: enabled, " + sessionTimeoutMs + "ms from overlay start");
        } else {
            NativeLsfgStats.note("TEST_TIMER: disabled, session has no automatic time limit");
        }
    }
    private int effectiveMultiplier(int requested,double inputFps) {
        if(requested<=2)return 2;
        if(inputFps<=1.0)return 4;
        return inputFps*4.0<=displayMaxFps*1.08 ? 4 : 2;
    }
    private void requestCompatibilityMode(int requested) {
        final int mode=Math.max(COMPAT_AUTO,Math.min(COMPAT_STABLE,requested));
        compatibilityMode=mode;
        getSharedPreferences("motionstride",MODE_PRIVATE).edit()
            .putInt("compatibility_mode",mode).apply();
        if(overlay!=null)overlay.setCompatibilityMode(mode);
        if(engine!=null)engine.post(()->{
            if(!contextLive||!leasedCaptureSupported)return;
            nativeBridge.setDirectFallbackAllowed(mode!=COMPAT_DIRECT);
            nativeBridge.setDirectCaptureEnabled(mode!=COMPAT_STABLE);
            NativeLsfgStats.note("COMPATIBILITY_CHANGED="+
                (mode==COMPAT_DIRECT?"DIRECT_LOCKED":mode==COMPAT_STABLE?"STABLE_COPY":"AUTO"));
        });
    }
    private void requestMultiplier(int requested) {
        requestedMultiplier=requested>=4?4:2;
        NativeLsfgStats.Snapshot s=NativeLsfgStats.snapshot();
        int desired=effectiveMultiplier(requestedMultiplier,s.realFps);
        if(overlay!=null)overlay.setSessionInfo(requestedMultiplier,desired,width,height,displayMaxFps,activeFlowScale);
        if(engine!=null)engine.post(()->applyMultiplier(desired,"user"));
    }
    private void maybeAutoMultiplier(NativeLsfgStats.Snapshot s) {
        if(requestedMultiplier!=4||s.realFps<=1.0)return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastMultiplierChangeMs<7000L)return;
        int desired=effectiveMultiplier(4,s.realFps);
        if(desired!=activeMultiplier)applyMultiplier(desired,"display-cap");
    }
    private void applyMultiplier(int desired,String reason) {
        if(stopping||!contextLive||desired==activeMultiplier)return;
        activeMultiplier=desired;
        lastMultiplierChangeMs=SystemClock.elapsedRealtime();
        nativeReady=false;
        NativeLsfgStats.note("MULTIPLIER_RECONFIG: requested="+requestedMultiplier+
            " effective="+desired+" reason="+reason+" display="+displayMaxFps+"Hz");
        main.post(()->{if(overlay!=null)overlay.setSessionInfo(requestedMultiplier,activeMultiplier,width,height,displayMaxFps,activeFlowScale);});
        initializeNative(captureRevision,width,height);
    }
    private void requestFlowScale(float requested) {
        float desired=Math.max(0.25f,Math.min(1.0f,Math.round(requested*20f)/20f));
        if(engine!=null)engine.post(()->applyFlowScale(desired));
    }
    private void applyFlowScale(float desired) {
        if(stopping||!contextLive||Math.abs(desired-activeFlowScale)<0.001f)return;
        activeFlowScale=desired;
        nativeReady=false;
        NativeLsfgStats.note("FLOW_RECONFIG: user scale="+desired+" (stream capture retained)");
        main.post(()->{if(overlay!=null)overlay.setSessionInfo(
            requestedMultiplier,activeMultiplier,width,height,displayMaxFps,activeFlowScale);});
        initializeNative(captureRevision,width,height);
    }
    private void closeCapture() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (reader != null) {
            reader.setOnImageAvailableListener(null, null);
            reader.close(); reader = null;
        }
        if (projection != null) {
            MediaProjection p = projection; projection = null;
            try { p.stop(); } catch (Throwable ignored) { }
        }
        NativeLsfgStats.note("Capture released");
    }
    private void closeNative() {
        try {
            nativeReady = false;
            if (nativeBridge != null) {
                nativeBridge.setOutputSurface(null, 0, 0);
                nativeBridge.destroyContext();
            }
        } catch (Throwable t) { NativeLsfgStats.note("Native cleanup: " + t); }
        contextLive = false;
        Surface stale = surfaceToReleaseOnExit;
        surfaceToReleaseOnExit = null;
        if (stale != null) stale.release();
        NativeLsfgStats.note("Native context released");
    }
    @Override public void onDestroy() {
        stopping = true;
        if(screenOffReceiverRegistered) {
            try { unregisterReceiver(screenOffReceiver); } catch(Throwable ignored) { }
            screenOffReceiverRegistered=false;
        }
        nativeReady = false;
        main.removeCallbacks(autoStop);
        main.removeCallbacks(captureReadyTimeout);
        if (overlay != null) { overlay.hide(); overlay = null; }
        if (telemetryHandler != null) {
            telemetryHandler.removeCallbacksAndMessages(null);
            if (telemetryThread != null) telemetryThread.quitSafely();
            telemetryHandler = null;
        }
        if (capture != null) {
            capture.removeCallbacksAndMessages(null);
            capture.post(() -> {
                try { closeCapture(); }
                finally { if (captureThread != null) captureThread.quitSafely(); }
            });
        } else closeCapture();
        if (engine != null) {
            // Do not interrupt an in-flight Vulkan init; it must return before
            // teardown to avoid destroying half-created native GPU objects.
            engine.removeCallbacksAndMessages(null);
            engine.post(() -> {
                try { closeNative(); }
                finally { if (nativeThread != null) nativeThread.quitSafely(); }
            });
        } else closeNative();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
