package com.prismforge.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Toast;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** MotionStride native-LSFG dashboard.
 * Only the UI and legacy lab entry points changed. Native capture, Vulkan processing,
 * trusted TextureView output, and native shader import are intentionally preserved.
 */
public final class MainActivity extends Activity {
    private static final int CAPTURE_DISCLOSURE_VERSION = 1;
    private static final int PICK_DLL = 206;
    private static final int NATIVE_LSFG_REQUEST = 209;
    private static final int INFO_NONE = 0;
    private static final int INFO_STATUS = 1;
    private static final int INFO_FRAME_GENERATION = 2;
    private static final int INFO_LOSSLESS = 3;
    private static final int BASE = 0xff09111f;
    private static final int CARD = 0xff14253b;
    private static final int CARD_ALT = 0xff192e48;
    private static final int OUTLINE = 0xff2a435f;
    private static final int AQUA = 0xff72e5df;
    private static final int SKY = 0xff77afff;
    private static final int WHITE = 0xfff1f7ff;
    private static final int MUTED = 0xff9fb4cd;
    private static final int AMBER = 0xffffd48e;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean visible;
    private boolean lowResolutionMode;
    private boolean testMode;
    private boolean timerEnabled;
    private boolean hudEnabled = true;
    private long timerDurationMs = 45_000L;
    private boolean detailsExpanded;
    private boolean importing;
    private TextView accessibilityValue, shadersValue, engineStatus, profileValue;
    private TextView realValue, generatedValue, postedValue, latencyValue, queueValue, p95Value;
    private TextView detailBody, dllDetails, readyHint;
    private LinearLayout optimizedCard, lowResCard, detailsContainer;
    private LinearLayout testDetails, timerChoices;
    private Button launchButton;
    private String cachedDllSummary;
    private String s(int id) { return getString(id); }

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (!visible) return;
            updateDashboard();
            ui.postDelayed(this, 800);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BASE);
        getWindow().setNavigationBarColor(BASE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        lowResolutionMode = getSharedPreferences("prismforge_ui", 0).getBoolean("low_resolution", false);
        testMode = getSharedPreferences("prismforge_ui", 0).getBoolean("test_mode", false);
        timerEnabled = getSharedPreferences("prismforge_ui", 0).getBoolean("test_timer", false);
        hudEnabled = getSharedPreferences("prismforge_ui", 0).getBoolean("hud_enabled", true);
        timerDurationMs = getSharedPreferences("prismforge_ui", 0).getLong("test_duration_ms", 45_000L);
        cachedDllSummary = getPreferences(0).getString("dll_summary", "");
        buildDashboard();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable surface(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private GradientDrawable gradient(int first, int second, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{first, second});
        d.setCornerRadius(dp(radius));
        return d;
    }
    private void tappable(View v, GradientDrawable drawable) {
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x4472e5df),drawable,null));
    }
    private TextView label(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setIncludeFontPadding(false);
        if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams margins(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }
    private void addText(LinearLayout host, String value, int sp, int color, boolean bold, int top) {
        host.addView(label(value,sp,color,bold),margins(top,0));
    }
    private LinearLayout panel(LinearLayout parent) {
        LinearLayout l = column();
        l.setPadding(dp(18),dp(18),dp(18),dp(18));
        l.setBackground(surface(CARD,OUTLINE,22));
        parent.addView(l,margins(14,0));
        return l;
    }
    private TextView pill(String text, int foreground, int background) {
        TextView v = label(text,11,foreground,true);
        v.setPadding(dp(11),dp(7),dp(11),dp(7));
        v.setGravity(Gravity.CENTER);
        v.setBackground(surface(background,0,30));
        return v;
    }
    private Button button(String title, boolean primary, View.OnClickListener click) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BASE : WHITE);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(14),0,dp(14),0);
        GradientDrawable d = primary ? gradient(0xff78e9df,0xff70b8f5,16)
                : surface(0xff243c56,0xff34536d,16);
        tappable(b,d);
        b.setOnClickListener(click);
        return b;
    }
    private void fullButton(LinearLayout host, String title, boolean primary, View.OnClickListener click, int top) {
        Button b=button(title,primary,click);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(53));
        p.topMargin=dp(top);
        host.addView(b,p);
    }
    private void sectionHeading(LinearLayout host, String heading, String description) {
        sectionHeading(host,heading,description,INFO_NONE);
    }
    private void sectionHeading(LinearLayout host, String heading, String description, int infoKind) {
        LinearLayout line=row();
        line.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        line.addView(label(heading,20,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        if (infoKind != INFO_NONE) {
            TextView help=label("?",16,AQUA,true);
            help.setGravity(Gravity.CENTER);
            help.setContentDescription(getString(R.string.more_information_about,heading));
            help.setClickable(true);
            help.setFocusable(true);
            tappable(help,surface(0xff20394e,AQUA,18));
            help.setOnClickListener(v -> showInfo(infoKind,heading));
            LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(dp(34),dp(34));
            hp.leftMargin=dp(12);
            line.addView(help,hp);
        }
        host.addView(line);
        if (description!=null) addText(host,description,12,MUTED,false,6);
    }
    private void showInfo(int infoKind, String heading) {
        if (infoKind == INFO_LOSSLESS) {
            showLosslessGuide();
            return;
        }
        int message = infoKind == INFO_STATUS
            ? R.string.status_help
            : R.string.frame_generation_help;
        new AlertDialog.Builder(this)
            .setTitle(heading)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok,null)
            .show();
    }
    private ScrollView dialogScroll(View content) {
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(false);
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        int available=getResources().getDisplayMetrics().heightPixels;
        int height=Math.min(dp(480),Math.max(dp(150),Math.round(available*0.58f)));
        scroll.setLayoutParams(new ViewGroup.LayoutParams(-1,height));
        return scroll;
    }
    private void showLosslessGuide() {
        LinearLayout content=column();
        content.setPadding(dp(20),dp(8),dp(20),0);
        LinearLayout tabs=row();
        TextView obtain=label(s(R.string.dll_tab_obtain),14,WHITE,true);
        TextView importTab=label(s(R.string.dll_tab_import),14,WHITE,true);
        obtain.setGravity(Gravity.CENTER);
        importTab.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tabParams=new LinearLayout.LayoutParams(0,dp(44),1);
        tabs.addView(obtain,tabParams);
        LinearLayout.LayoutParams secondParams=new LinearLayout.LayoutParams(0,dp(44),1);
        secondParams.leftMargin=dp(8);
        tabs.addView(importTab,secondParams);
        content.addView(tabs);
        TextView body=label(s(R.string.dll_obtain_steps),14,WHITE,false);
        body.setLineSpacing(dp(4),1f);
        content.addView(body,margins(18,8));
        Runnable showObtain=() -> {
            body.setText(R.string.dll_obtain_steps);
            tappable(obtain,surface(0xff28526a,AQUA,12));
            tappable(importTab,surface(0xff192e48,OUTLINE,12));
        };
        Runnable showImport=() -> {
            body.setText(R.string.dll_import_steps);
            tappable(obtain,surface(0xff192e48,OUTLINE,12));
            tappable(importTab,surface(0xff28526a,AQUA,12));
        };
        obtain.setOnClickListener(v -> showObtain.run());
        importTab.setOnClickListener(v -> showImport.run());
        showObtain.run();
        new AlertDialog.Builder(this)
            .setTitle("Lossless.dll")
            .setView(dialogScroll(content))
            .setPositiveButton(android.R.string.ok,null)
            .show();
    }
    private TextView metric(LinearLayout parent, String title, String initial, String unit) {
        LinearLayout cell = column();
        cell.setPadding(dp(12),dp(12),dp(8),dp(12));
        cell.setBackground(surface(CARD_ALT,0,16));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);
        cp.rightMargin=dp(6);
        parent.addView(cell,cp);
        cell.addView(label(title,10,MUTED,true));
        TextView value=label(initial,23,WHITE,true);
        value.setSingleLine(true);
        value.setAutoSizeTextTypeUniformWithConfiguration(13,23,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        cell.addView(value,margins(8,0));
        cell.addView(label(unit,10,AQUA,false),margins(4,0));
        return value;
    }
    private LinearLayout profileCard(LinearLayout host, boolean lowResolution, String title, String subtitle) {
        LinearLayout wrapper=column();
        wrapper.setPadding(dp(16),dp(16),dp(16),dp(16));
        LinearLayout line=row();
        TextView name=label(title,15,WHITE,true);
        line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView chip=pill(lowResolution?"720p":"1080p",lowResolution?SKY:AQUA,0xff20394e);
        line.addView(chip);
        wrapper.addView(line);
        addText(wrapper,subtitle,12,MUTED,false,7);
        host.addView(wrapper,margins(10,0));
        wrapper.setClickable(true);
        wrapper.setFocusable(true);
        wrapper.setContentDescription(title+". "+subtitle);
        wrapper.setOnClickListener(v -> selectProfile(lowResolution));
        return wrapper;
    }
    private void selectProfile(boolean lowResolution) {
        lowResolutionMode=lowResolution;
        getSharedPreferences("prismforge_ui",0).edit().putBoolean("low_resolution",lowResolution).apply();
        repaintProfiles();
    }
    private void repaintProfiles() {
        if (optimizedCard==null || lowResCard==null) return;
        tappable(optimizedCard,surface(lowResolutionMode?0xff172840:0xff20435b,
            lowResolutionMode?OUTLINE:AQUA,18));
        tappable(lowResCard,surface(lowResolutionMode?0xff20435b:0xff172840,
            lowResolutionMode?AQUA:OUTLINE,18));
        if (profileValue!=null) profileValue.setText(lowResolutionMode?s(R.string.profile_720p_accelerated):s(R.string.profile_native_accelerated));
    }
    private void saveTestSettings() {
        getSharedPreferences("prismforge_ui",0).edit()
            .putBoolean("test_mode",testMode)
            .putBoolean("test_timer",timerEnabled)
            .putLong("test_duration_ms",timerDurationMs).apply();
    }
    private void redrawTestSettings() {
        if (testDetails != null) testDetails.setVisibility(testMode?View.VISIBLE:View.GONE);
        if (timerChoices != null) timerChoices.setVisibility(testMode && timerEnabled?View.VISIBLE:View.GONE);
    }
    private void addTestSettings(LinearLayout parent) {
        LinearLayout settings=panel(parent);
        LinearLayout line=row();
        line.addView(label(s(R.string.test_mode),16,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        Switch modeSwitch=new Switch(this);
        modeSwitch.setContentDescription(s(R.string.test_mode));
        modeSwitch.setThumbTintList(new ColorStateList(
            new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},
            new int[]{AQUA,0xff72869f}));
        modeSwitch.setChecked(testMode);
        line.addView(modeSwitch);
        settings.addView(line);
        testDetails=column();
        LinearLayout limitLine=row();
        limitLine.setPadding(0,dp(16),0,dp(8));
        limitLine.addView(label(s(R.string.timed_stop),14,WHITE,false),new LinearLayout.LayoutParams(0,-2,1));
        Switch limitSwitch=new Switch(this);
        limitSwitch.setContentDescription(s(R.string.timed_stop));
        limitSwitch.setThumbTintList(new ColorStateList(
            new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},
            new int[]{AQUA,0xff72869f}));
        limitSwitch.setChecked(timerEnabled);
        limitLine.addView(limitSwitch);
        testDetails.addView(limitLine);
        timerChoices=column();
        addText(timerChoices,s(R.string.test_duration),12,MUTED,false,5);
        final long[] durations={45_000L,120_000L,300_000L,900_000L};
        final String[] titles={s(R.string.seconds_45),s(R.string.minutes_2),s(R.string.minutes_5),s(R.string.minutes_15)};
        for (int rowIndex=0;rowIndex<2;rowIndex++) {
            LinearLayout choiceRow=row();
            LinearLayout.LayoutParams rp=margins(rowIndex==0?9:7,0);
            timerChoices.addView(choiceRow,rp);
            for (int i=rowIndex*2;i<rowIndex*2+2;i++) {
                final long duration=durations[i];
                TextView option=label(titles[i],13,WHITE,true);
                option.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(43),1);
                if (i%2==1) op.leftMargin=dp(8);
                choiceRow.addView(option,op);
                option.setClickable(true);
                option.setFocusable(true);
                option.setOnClickListener(v -> {
                    timerDurationMs=duration;
                    saveTestSettings();
                    tintTimerChoices(timerChoices,durations);
                });
            }
        }
        tintTimerChoices(timerChoices,durations);
        testDetails.addView(timerChoices);
        settings.addView(testDetails);
        modeSwitch.setOnCheckedChangeListener((button,checked)-> {
            testMode=checked;
            saveTestSettings();
            redrawTestSettings();
        });
        limitSwitch.setOnCheckedChangeListener((button,checked)-> {
            timerEnabled=checked;
            saveTestSettings();
            redrawTestSettings();
        });
        redrawTestSettings();
    }

    private void addHudSetting(LinearLayout parent) {
        LinearLayout settings=panel(parent);
        LinearLayout line=row();
        LinearLayout copy=column();
        copy.addView(label(s(R.string.floating_monitor),16,WHITE,true));
        addText(copy,s(R.string.floating_monitor_description),12,MUTED,false,5);
        line.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        Switch enabled=new Switch(this);
        enabled.setContentDescription(s(R.string.floating_monitor));
        enabled.setThumbTintList(new ColorStateList(
            new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},
            new int[]{AQUA,0xff72869f}));
        enabled.setChecked(hudEnabled);
        line.addView(enabled);
        settings.addView(line);
        enabled.setOnCheckedChangeListener((button,checked)-> {
            if (checked) {
                hudEnabled=true;
                getSharedPreferences("prismforge_ui",0).edit()
                    .putBoolean("hud_enabled",true).apply();
                return;
            }
            LinearLayout warning=column();
            warning.setPadding(dp(24),dp(4),dp(24),0);
            TextView body=label(s(R.string.floating_monitor_off_warning),14,WHITE,false);
            body.setLineSpacing(dp(4),1f);
            warning.addView(body);
            new AlertDialog.Builder(this)
                .setTitle(R.string.floating_monitor_off_title)
                .setView(dialogScroll(warning))
                .setNegativeButton(R.string.keep_monitor,(dialog,which)->enabled.setChecked(true))
                .setPositiveButton(R.string.hide_monitor,(dialog,which)-> {
                    hudEnabled=false;
                    getSharedPreferences("prismforge_ui",0).edit()
                        .putBoolean("hud_enabled",false).apply();
                })
                .setOnCancelListener(dialog->enabled.setChecked(true))
                .show();
        });
    }
    private void tintTimerChoices(LinearLayout container,long[] durations) {
        for (int r=0;r<container.getChildCount();r++) {
            View child=container.getChildAt(r);
            if (!(child instanceof LinearLayout)) continue;
            LinearLayout row=(LinearLayout)child;
            for (int j=0;j<row.getChildCount();j++) {
                TextView option=(TextView)row.getChildAt(j);
                int index=(r-1)*2+j;
                if(index<0 || index>=durations.length) continue;
                boolean chosen=timerDurationMs==durations[index];
                option.setTextColor(chosen?BASE:WHITE);
                tappable(option,surface(chosen?AQUA:0xff243c56,chosen?AQUA:OUTLINE,12));
            }
        }
    }

    private void addBrand(LinearLayout parent) {
        LinearLayout brand=row();
        TextView logo=label("✦",24,AQUA,true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(gradient(0xff254e6c,0xff162b4c,17));
        brand.addView(logo,new LinearLayout.LayoutParams(dp(51),dp(51)));
        LinearLayout brandNames=column();
        brandNames.setPadding(dp(13),0,0,0);
        brandNames.addView(label("MOTIONSTRIDE",19,WHITE,true));
        brandNames.addView(label("FRAME GENERATION",10,AQUA,true),margins(5,0));
        brand.addView(brandNames,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(pill("v1.9.19",WHITE,0xff243a55));
        parent.addView(brand);
    }

    private void addReadiness(LinearLayout parent) {
        LinearLayout readiness=panel(parent);
        sectionHeading(readiness,s(R.string.status),null,INFO_STATUS);
        LinearLayout accessLine=row();
        accessLine.setPadding(0,dp(14),0,dp(11));
        accessLine.addView(label(s(R.string.accessibility_service),13,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        accessibilityValue=label(s(R.string.checking),12,AMBER,true);
        accessLine.addView(accessibilityValue);
        accessLine.setOnClickListener(v -> requestAccessibilityPermission());
        readiness.addView(accessLine);
        View rule=new View(this);rule.setBackgroundColor(OUTLINE);
        readiness.addView(rule,new LinearLayout.LayoutParams(-1,dp(1)));
        LinearLayout shadersLine=row();
        shadersLine.setPadding(0,dp(11),0,dp(7));
        shadersLine.addView(label(s(R.string.lsfg_shaders),13,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        shadersValue=label(s(R.string.checking),12,AMBER,true);
        shadersLine.addView(shadersValue);
        readiness.addView(shadersLine);
        readyHint=label("",12,MUTED,false);
        readiness.addView(readyHint,margins(5,0));
        fullButton(readiness,s(R.string.accessibility_settings),false,v->requestAccessibilityPermission(),10);
    }

    private void addProfiles(LinearLayout parent) {
        LinearLayout profiles=panel(parent);
        sectionHeading(profiles,s(R.string.processing_profile),null);
        optimizedCard=profileCard(profiles,false,s(R.string.native_accelerated),s(R.string.original_resolution));
        lowResCard=profileCard(profiles,true,s(R.string.fast_720p),s(R.string.reduced_resolution_same_processing));
    }

    private void addStart(LinearLayout parent) {
        LinearLayout start=panel(parent);
        sectionHeading(start,s(R.string.frame_generation),null,INFO_FRAME_GENERATION);
        profileValue=label("",12,AQUA,true);
        start.addView(profileValue,margins(14,0));
        launchButton=button(s(R.string.start_lsfg),true,v->requestNativeLsfg());
        start.addView(launchButton,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout.LayoutParams stopParams=new LinearLayout.LayoutParams(-1,dp(45));stopParams.topMargin=dp(7);
        start.addView(button(s(R.string.stop_session),false,v->stopNativeLsfg()),stopParams);
        engineStatus=label(s(R.string.waiting_to_start),12,MUTED,false);
        start.addView(engineStatus,margins(10,0));
    }

    private LinearLayout accordion(LinearLayout parent,String title,String subtitle) {
        LinearLayout card=panel(parent);
        card.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout header=row();
        LinearLayout copy=column();
        copy.addView(label(title,16,WHITE,true));
        if(subtitle!=null && !subtitle.isEmpty()) addText(copy,subtitle,11,MUTED,false,4);
        header.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("⌄",22,AQUA,true);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout body=column();
        body.setVisibility(View.GONE);
        card.addView(header);
        card.addView(body);
        header.setClickable(true);
        header.setFocusable(true);
        header.setContentDescription(title);
        header.setOnClickListener(v -> {
            boolean open=body.getVisibility()!=View.VISIBLE;
            body.setVisibility(open?View.VISIBLE:View.GONE);
            arrow.setText(open?"⌃":"⌄");
            if(body==detailsContainer) {
                detailsExpanded=open;
                if(open) updateDashboard();
            }
        });
        return body;
    }

    private void addLossless(LinearLayout parent) {
        LinearLayout shaderBody=accordion(parent,"Lossless.dll",s(R.string.lossless_compact_summary));
        fillLossless(shaderBody);
    }
    private void addCompactLossless(LinearLayout parent) {
        LinearLayout shaderBody=accordion(parent,"Lossless.dll",null);
        fillLossless(shaderBody);
    }
    private void fillLossless(LinearLayout shaderBody) {
        dllDetails=label("",12,MUTED,false);
        dllDetails.setMaxLines(3);
        shaderBody.addView(dllDetails,margins(11,0));
        fullButton(shaderBody,s(R.string.import_lossless),false,v->chooseDll(),11);
        fullButton(shaderBody,s(R.string.lossless_instructions),false,v->showLosslessGuide(),7);
    }
    private void addDiagnostics(LinearLayout parent) {
        LinearLayout diagnosticsBody=accordion(parent,s(R.string.diagnostics),null);
        detailsContainer=diagnosticsBody;
        detailBody=label("",11,WHITE,false);
        detailBody.setTypeface(Typeface.MONOSPACE);
        detailBody.setTextIsSelectable(true);
        detailBody.setPadding(dp(11),dp(13),dp(11),dp(13));
        detailBody.setBackground(surface(0xff0c192b,0xff223e55,13));
        diagnosticsBody.addView(detailBody,margins(11,0));
        fullButton(diagnosticsBody,s(R.string.copy_full_log),false,v->copy("MotionStride LSFG",NativeLsfgStats.export()),9);
        fullButton(diagnosticsBody,s(R.string.copy_crash_log),false,v->copy("MotionStride Native Crash",NativeLsfgStats.exportCrash(this)),7);
    }
    private void addPrivacy(LinearLayout parent) {
        LinearLayout privacyBody=accordion(parent,s(R.string.privacy_title),s(R.string.privacy_summary));
        fullButton(privacyBody,s(R.string.privacy_details),false,v->showPrivacyDetails(),10);
    }
    private interface DashboardBlock { void add(LinearLayout parent); }
    private LinearLayout addPair(LinearLayout parent,DashboardBlock first,DashboardBlock second) {
        LinearLayout pair=row();
        pair.setGravity(Gravity.TOP);
        LinearLayout left=column(),right=column();
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
        lp.rightMargin=dp(7);
        pair.addView(left,lp);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1);
        rp.leftMargin=dp(7);
        pair.addView(right,rp);
        parent.addView(pair);
        first.add(left);
        second.add(right);
        return pair;
    }
    private void equalizePairCards(LinearLayout pair) {
        pair.post(() -> {
            if(pair.getChildCount()!=2) return;
            ViewGroup left=(ViewGroup)pair.getChildAt(0),right=(ViewGroup)pair.getChildAt(1);
            if(left.getChildCount()==0 || right.getChildCount()==0) return;
            View a=left.getChildAt(0),b=right.getChildAt(0);
            int height=Math.max(a.getMeasuredHeight(),b.getMeasuredHeight());
            a.setMinimumHeight(height);
            b.setMinimumHeight(height);
        });
    }

    private void buildDashboard() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackground(gradient(0xff09111f,0xff0c1a2e,0));
        LinearLayout content=column();
        boolean landscape=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
        content.setPadding(dp(landscape?14:18),dp(landscape?28:26),dp(landscape?14:18),dp(28));
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        setContentView(scroll);
        addBrand(content);
        if(landscape) {
            LinearLayout topPair=addPair(content,this::addStart,this::addProfiles);
            equalizePairCards(topPair);

            LinearLayout columns=row();
            columns.setGravity(Gravity.TOP);
            LinearLayout left=column(),right=column();
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);
            lp.rightMargin=dp(7);
            columns.addView(left,lp);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1);
            rp.leftMargin=dp(7);
            columns.addView(right,rp);
            content.addView(columns);

            addReadiness(left);
            LinearLayout compactPair=addPair(left,this::addTestSettings,this::addCompactLossless);
            equalizePairCards(compactPair);

            addHudSetting(right);
            addDiagnostics(right);
            addPrivacy(right);
        } else {
            addStart(content);
            addReadiness(content);
            addProfiles(content);
            addHudSetting(content);
            addTestSettings(content);
            addLossless(content);
            addDiagnostics(content);
            addPrivacy(content);
        }
        repaintProfiles();

        LinearLayout footer=column();
        footer.setGravity(Gravity.CENTER);
        footer.addView(label("MOTIONSTRIDE  •  v1.9.19",10,MUTED,true));
        content.addView(footer,margins(24,0));
        updateDashboard();
    }

    private static String extractMetric(String src,String regex) {
        Matcher m=Pattern.compile(regex).matcher(src);
        return m.find()?m.group(1):"—";
    }
    private void updateDashboard() {
        if (accessibilityValue==null) return;
        boolean connected=PrismForgeAccessibilityService.isReady();
        boolean enabled=PrismForgeAccessibilityService.enabledInSettings(this);
        boolean ready=NativeLsfgShaders.available(this);
        accessibilityValue.setText(connected?s(R.string.ready):(enabled?s(R.string.reconnect):s(R.string.no_permission)));
        accessibilityValue.setTextColor(connected?AQUA:AMBER);
        shadersValue.setText(ready?s(R.string.ready):s(R.string.import_required));
        shadersValue.setTextColor(ready?AQUA:AMBER);
        readyHint.setText(!connected ? (enabled
            ? s(R.string.reconnect_required)
            : s(R.string.enable_accessibility_hint))
            : !ready ? s(R.string.import_dll_hint) : "");
        readyHint.setVisibility(connected && ready ? View.GONE : View.VISIBLE);
        launchButton.setAlpha(connected && ready ? 1f : .73f);
        dllDetails.setText(importing ? s(R.string.shader_importing) :
            ready ? s(R.string.shaders_ready) :
            cachedDllSummary.isEmpty() ? s(R.string.no_shader_library) : cachedDllSummary);
        String summary=NativeLsfgStats.summary();
        String state=summary.contains("\n") ? summary.substring(0,summary.indexOf('\n')) : summary;
        engineStatus.setText(state);
        engineStatus.setTextColor(state.contains("HIBA")||state.contains("ERROR")?0xffffaaa9:MUTED);
        if (detailsExpanded) detailBody.setText(summary);
    }
    private void chooseDll() {
        if (importing) return;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i,PICK_DLL);
    }
    private void requestAccessibilityPermission() {
        if (PrismForgeAccessibilityService.isReady()) {
            Toast.makeText(this,s(R.string.accessibility_connected),Toast.LENGTH_SHORT).show();
            return;
        }
        showAccessibilityDisclosure();
    }
    private void showAccessibilityDisclosure() {
        LinearLayout disclosure=column();
        disclosure.setPadding(dp(24),dp(4),dp(24),0);
        TextView body=label(s(R.string.accessibility_disclosure_body),14,WHITE,false);
        body.setLineSpacing(dp(4),1f);
        disclosure.addView(body);
        new AlertDialog.Builder(this)
            .setTitle(R.string.accessibility_disclosure_title)
            .setView(dialogScroll(disclosure))
            .setNegativeButton(R.string.cancel,null)
            .setPositiveButton(R.string.accessibility_consent_action,(dialog,which) -> {
                getSharedPreferences("prismforge_ui",0).edit()
                    .putInt("accessibility_consent_version",1).apply();
                openAccessibilitySettings();
            })
            .show();
    }
    private void openAccessibilitySettings() {
        try {startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
        catch (Exception e) {alert(s(R.string.settings),e.toString());}
    }

    private void showPrivacyDetails() {
        new AlertDialog.Builder(this)
            .setTitle(R.string.privacy_title)
            .setMessage(R.string.privacy_body)
            .setPositiveButton(android.R.string.ok,null)
            .show();
    }

    /** Use only the documented Android app-sharing API. The disclosure tells
     * users to select an app window because whole-display capture would feed
     * the output overlay back into the capture. */
    private Intent gameAppCaptureIntent(MediaProjectionManager mgr) {
        NativeLsfgStats.note("APP_WINDOW_SELECTOR: documented MediaProjectionConfig user-choice API");
        return mgr.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice());
    }
    private void requestNativeLsfg() {
        if (!PrismForgeAccessibilityService.isReady()) {
            if (PrismForgeAccessibilityService.enabledInSettings(this)) {
                Toast.makeText(this,s(R.string.waiting_accessibility),Toast.LENGTH_LONG).show();
                ui.postDelayed(() -> {
                    if (!isFinishing() && PrismForgeAccessibilityService.isReady()) requestNativeLsfg();
                    else if (!isFinishing()) requestAccessibilityPermission();
                },2500L);
            } else requestAccessibilityPermission();
            return;
        }
        if (!NativeLsfgShaders.available(this)) {
            new AlertDialog.Builder(this).setTitle(s(R.string.shaders_missing_title))
                .setMessage(s(R.string.shaders_missing_message))
                .setPositiveButton("OK",null).show();
            return;
        }
        if (getSharedPreferences("prismforge_ui",0)
                .getInt("capture_disclosure_version",0) >= CAPTURE_DISCLOSURE_VERSION) {
            openAppCaptureSelector();
            return;
        }
        LinearLayout warning=column();
        warning.setPadding(dp(24),dp(4),dp(24),0);
        TextView warningText=label(s(R.string.capture_warning_message),14,WHITE,false);
        warningText.setLineSpacing(dp(4),1f);
        warning.addView(warningText);
        CheckBox neverAgain=new CheckBox(this);
        neverAgain.setText(R.string.do_not_show_again);
        neverAgain.setTextColor(AQUA);
        neverAgain.setTextSize(14);
        neverAgain.setButtonTintList(ColorStateList.valueOf(AQUA));
        warning.addView(neverAgain,margins(18,0));
        new AlertDialog.Builder(this)
            .setTitle(R.string.capture_warning_title)
            .setView(dialogScroll(warning))
            .setNegativeButton(R.string.cancel,null)
            .setPositiveButton(R.string.continue_action,(dialog,which) -> {
                if (neverAgain.isChecked()) {
                    getSharedPreferences("prismforge_ui",0).edit()
                        .putInt("capture_disclosure_version",CAPTURE_DISCLOSURE_VERSION).apply();
                }
                openAppCaptureSelector();
            })
            .show();
    }
    private void openAppCaptureSelector() {
        MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        try {startActivityForResult(gameAppCaptureIntent(mgr),NATIVE_LSFG_REQUEST);}
        catch (Throwable t) {NativeLsfgStats.error("App-only selector: "+t);alert(s(R.string.app_capture_error),t.toString());}
    }
    private void stopNativeLsfg() {
        // Preserve the service's STOP action: foreground notification + lifecycle cleanup.
        Intent stop=new Intent(this,NativeLsfgService.class).setAction(NativeLsfgService.STOP);
        startService(stop);
        Toast.makeText(this,s(R.string.stop_request_sent),Toast.LENGTH_SHORT).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==PICK_DLL) {
            if (resultCode!=RESULT_OK || data==null || data.getData()==null) return;
            Uri uri=data.getData();
            importing=true;
            updateDashboard();
            worker.execute(() -> {
                try {
                    DllInspector.Result inspection;
                    try (InputStream stream=getContentResolver().openInputStream(uri)) {
                        if (stream==null) throw new Exception(s(R.string.cannot_open_file));
                        inspection=DllInspector.inspect(stream);
                    }
                    String result=inspection.summary();
                    if (!inspection.validPe) throw new Exception(s(R.string.not_windows_dll)+"\n"+result);
                    String nativeResult=NativeLsfgShaders.importDll(this,uri);
                    String full=result+"\n\n"+nativeResult;
                    ui.post(() -> {
                        importing=false;
                        cachedDllSummary=full;
                        getPreferences(0).edit().putString("dll_summary",full).apply();
                        updateDashboard();
                        Toast.makeText(this,s(R.string.shader_import_success),Toast.LENGTH_LONG).show();
                    });
                } catch (Exception e) {
                    ui.post(() -> {
                        importing=false;
                        cachedDllSummary=getString(R.string.shader_import_error,e.getMessage());
                        updateDashboard();
                        alert("LSFG shaderimport",e.toString());
                    });
                }
            });
        } else if (requestCode==NATIVE_LSFG_REQUEST) {
            if (resultCode!=RESULT_OK || data==null) {
                NativeLsfgStats.status(s(R.string.permission_denied));
                return;
            }
            try {
                android.view.Display d=getWindowManager().getDefaultDisplay();
                android.graphics.Point size=new android.graphics.Point();
                d.getRealSize(size);
                Intent launch=new Intent(this,NativeLsfgService.class)
                    .setAction(NativeLsfgService.START)
                    .putExtra(NativeLsfgService.EXTRA_CODE,resultCode)
                    .putExtra(NativeLsfgService.EXTRA_DATA,data)
                    .putExtra(NativeLsfgService.EXTRA_W,size.x)
                    .putExtra(NativeLsfgService.EXTRA_H,size.y)
                    .putExtra(NativeLsfgService.EXTRA_APP_ONLY,true)
                    .putExtra(NativeLsfgService.EXTRA_FAST,lowResolutionMode)
                    .putExtra(NativeLsfgService.EXTRA_HUD_ENABLED,hudEnabled)
                    .putExtra(NativeLsfgService.EXTRA_TIMEOUT_MS,
                        testMode && timerEnabled ? timerDurationMs : 0L);
                startForegroundService(launch);
            } catch (Throwable ex) {
                NativeLsfgStats.error("Nem indult: "+ex);
                alert(s(R.string.native_start_error),ex.toString());
            }
        }
    }
    private void copy(String title,String contents) {
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(title,contents));
        Toast.makeText(this,s(R.string.log_copied),Toast.LENGTH_SHORT).show();
    }
    private void alert(String title,String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK",null).show();
    }
    @Override protected void onResume() {
        super.onResume();
        visible=true;
        ui.removeCallbacks(refresh);
        ui.post(refresh);
    }
    @Override protected void onPause() {
        visible=false;
        ui.removeCallbacks(refresh);
        super.onPause();
    }
    @Override protected void onDestroy() {
        ui.removeCallbacks(refresh);
        worker.shutdownNow();
        super.onDestroy();
    }
}
