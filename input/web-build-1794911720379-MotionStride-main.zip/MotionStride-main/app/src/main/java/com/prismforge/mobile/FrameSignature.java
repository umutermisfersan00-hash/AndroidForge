package com.prismforge.mobile;

import android.media.Image;
import java.nio.ByteBuffer;

/**
 * 8x8 FNV luma signature, bit-for-bit identical to the v1.8 implementation.
 *
 * The selected app's width, height, row stride and pixel stride stay constant
 * between ImageReader resizes. Cache the 64 sample offsets so the hot capture
 * callback does not repeat per-sample integer divisions on every incoming image.
 *
 * One Sampler belongs to the capture HandlerThread only; it is not shared
 * across threads. The native engine still performs its original hash check.
 */
public final class FrameSignature {
    private FrameSignature() {}

    public static final class Sampler {
        private final int[] offsets = new int[64];
        private int width = -1, height = -1, rowStride = -1, pixelStride = -1;
        private int greatestOffset = -1;

        public int hash(Image image) {
            if (image == null || image.getFormat() != android.graphics.PixelFormat.RGBA_8888)
                return 0;
            try {
                Image.Plane[] planes = image.getPlanes();
                if (planes == null || planes.length == 0) return 0;
                Image.Plane plane = planes[0];
                ByteBuffer buf = plane.getBuffer();
                int stride = plane.getRowStride();
                int pixel = plane.getPixelStride();
                int w = image.getWidth(), h = image.getHeight();
                if (buf == null || stride <= 0 || pixel < 4 || w <= 0 || h <= 0)
                    return 0;
                if (w != width || h != height || stride != rowStride || pixel != pixelStride) {
                    int j = 0;
                    int max = -1;
                    for (int y = 0; y < 8; y++) {
                        int py = Math.min((y * h) / 8, h - 1);
                        for (int x = 0; x < 8; x++) {
                            int px = Math.min((x * w) / 8, w - 1);
                            int pos = py * stride + px * pixel;
                            offsets[j++] = pos;
                            if (pos > max) max = pos;
                        }
                    }
                    greatestOffset = max;
                    width = w; height = h; rowStride = stride; pixelStride = pixel;
                }
                if (greatestOffset < 0 || greatestOffset + 2 >= buf.limit()) return 0;
                int hash = 0x811c9dc5;
                for (int pos : offsets) {
                    int r = buf.get(pos) & 255;
                    int g = buf.get(pos + 1) & 255;
                    int b = buf.get(pos + 2) & 255;
                    int luma = (77 * r + 150 * g + 29 * b) >> 10;
                    hash = (hash ^ luma) * 0x01000193;
                }
                return hash != 0 ? hash : 1;
            } catch (Throwable unreadable) {
                // Preserve the exact old fail-safe: let the native pipeline
                // receive the original image and original timestamp.
                return 0;
            }
        }
    }
}
