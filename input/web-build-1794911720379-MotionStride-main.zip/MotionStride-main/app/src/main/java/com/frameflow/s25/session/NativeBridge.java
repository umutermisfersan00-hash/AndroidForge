package com.frameflow.s25.session;

import android.hardware.HardwareBuffer;
import android.view.Surface;

/** ABI-compatibility bridge for the user's previously built LSFG Vulkan library.
 * JNI symbol paths in that binary target com.frameflow.s25.session.NativeBridge.
 * The PrismForge applicationId remains com.prismforge.mobile.
 */
public final class NativeBridge {
    static { System.loadLibrary("lsfg-android"); }
    public native String nativeVersion();
    /** Existing native signal-handler logger: preserves a crash file after process death. */
    public native void initCrashReporter(String crashPath, String logPath);
    public native int extractShaders(String dllPath, String dllSha256, String cacheDir);
    public native int probeShaders(String cacheDir);
    public native int initContext(String cacheDir, int width, int height,
            int multiplier, float flowScale, boolean performance, boolean hdr,
            boolean antiArtifacts, boolean framegenFp16,
            boolean npuPostProcessing, int npuPreset, int npuUpscaleFactor,
            float npuAmount, float npuRadius, float npuThreshold, boolean npuFp16,
            boolean cpuPostProcessing, int cpuPreset, float cpuStrength,
            float cpuSaturation, float cpuVibrance, float cpuVignette,
            boolean gpuPostProcessing, int gpuStage, int gpuMethod,
            float gpuUpscaleFactor, float gpuSharpness, float gpuStrength,
            int targetFpsCap, float emaAlpha, float outlierRatio,
            float vsyncSlackMs, int queueDepth);
    public native void setOutputSurface(Surface surface, int width, int height);
    public native void pushFrame(HardwareBuffer hardwareBuffer, long timestampNs);
    // Available only in the newly compiled native 0.1.3 library.
    // Native assumes responsibility for closing the Java Image when true.
    public native boolean pushFrameLeased(HardwareBuffer hardwareBuffer,
            android.media.Image image, long timestampNs);
    /** v0.1.5: reuses FrameSignature hash, avoiding a second AHB CPU lock. */
    public native boolean pushFrameLeasedWithHash(HardwareBuffer hardwareBuffer,
            android.media.Image image, long timestampNs, int captureHash);
    public native void setDirectCaptureEnabled(boolean enabled);
    public native void setDirectFallbackAllowed(boolean allowed);
    public native long getGeneratedFrameCount();
    public native long getPostedFrameCount();
    public native long getUniqueCaptureCount();
    public native double getAverageLatencyMs();
    public native double getAverageQueueMs();
    public native void setVsyncPeriodNs(long ns);
    /** Exported by the existing binary. Update frame pacing without reinitialization. */
    public native void setPacingParams(int targetFpsCap, float emaAlpha,
            float outlierRatio, float vsyncSlackMs, int queueDepth);
    /** Actual native output POST intervals, not guaranteed display presentation times. */
    public native int getRecentPostIntervalsNs(long[] outIntervals);
    // Already exported by the supplied ARM64 library: no NDK rebuild required.
    public native boolean isFramegenFp16Supported(String shaderCacheDir);
    /** [copyNs, presentNs, waitIdleNs, blitNs, totalNs, samples]. */
    public native int getProfileWindowNs(long[] sixTotals);
    public native void destroyContext();
}
