package com.prismforge.mobile;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.Context;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.view.accessibility.AccessibilityManager;
import android.provider.Settings;
import java.util.List;
import android.view.accessibility.AccessibilityEvent;

/**
 * Only provides a trusted full-screen output window.
 * Never reads UI nodes, collects text, intercepts touches, or injects gestures.
 * Users enable/disable the service explicitly in Android settings.
 */
public final class PrismForgeAccessibilityService extends AccessibilityService {
    private static volatile PrismForgeAccessibilityService active;

    public static PrismForgeAccessibilityService current() { return active; }
    public static boolean isReady() { return active != null; }

    /** Enabled in system settings is NOT the same as a connected service after a crash.
     *  Do not show a misleading "permission missing" error when only reconnection failed.
     */
    public static boolean enabledInSettings(Context context) {
        try {
            AccessibilityManager am = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
            if (am != null) {
                List<AccessibilityServiceInfo> enabled = am.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
                if (enabled != null) for (AccessibilityServiceInfo info : enabled) {
                    if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                        context.getPackageName().equals(info.getResolveInfo().serviceInfo.packageName) &&
                        PrismForgeAccessibilityService.class.getName().equals(
                            info.getResolveInfo().serviceInfo.name)) return true;
                }
            }
        } catch (Throwable ignored) { }
        try {
            String value = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return value != null && value.contains(context.getPackageName() + "/") &&
                value.contains("PrismForgeAccessibilityService");
        } catch (Throwable ignored) { return false; }
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        active = this;
        NativeLsfgStats.note("ACCESSIBILITY: service connected; trusted overlay available");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Intentionally do not inspect event contents.
    }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(Intent intent) {
        revoke();
        return super.onUnbind(intent);
    }
    @Override public void onDestroy() {
        revoke();
        super.onDestroy();
    }
    private void revoke() {
        if (active == this) active = null;
        NativeLsfgStats.note("ACCESSIBILITY: disconnected; native output no longer available");
        // An accessibility overlay must disappear if its owning service is disabled.
        try { stopService(new Intent(this, NativeLsfgService.class)); } catch (Throwable ignored) { }
    }
}
