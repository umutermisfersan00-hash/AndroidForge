package com.prismforge.mobile;

/**
 * Conservative timestamp conditioner for app-only MediaProjection content frames.
 * MediaProjection is usually sampled at display Hz, not game Hz. A 60 FPS game
 * sampled at 120 Hz may produce identical images as well as alternating 8/25 ms
 * intervals for successive DIFFERENT frames. The native LSFG worker uses these
 * deltas to time its output, so irregular capture timestamps can appear as
 * momentary motion-speed changes even if mean output FPS is steady.
 *
 * Hashes must be compatible with the native eight-by-eight RGBA luma hash.
 * For unsupported image formats, callers bypass this class and pass through
 * original timestamps. It does NOT modify pixel content or drop unique frames.
 */
public final class CaptureCadence {
    private static final long MIN_NS = 7_000_000L;
    private static final long MAX_TRACK_NS = 70_000_000L;
    private static final long REBASE_GAP_NS = 100_000_000L;
    private static final long REBASE_PHASE_NS = 20_000_000L;
    private static final long MAX_PHASE_STEP_NS = 500_000L;
    private static final long[] KNOWN_PERIODS_NS = {
        8_333_333L, 11_111_111L, 16_666_667L, 22_222_222L, 33_333_333L
    };
    private static final int RING_SIZE = 96;
    private final long[] rawIntervals = new long[RING_SIZE];
    private final long[] outputIntervals = new long[RING_SIZE];
    // Reused on the capture Looper by the 1.2-second diagnostic report.
    private final long[] jitterScratch = new long[RING_SIZE];
    private int ringIndex, ringCount;
    private long lastRawNs, lastOutNs;
    private int lastHash;
    private boolean hasHash;
    private double expectedPeriodNs = 16_666_667.0;
    private int stableSamples;
    private long unique, duplicates, rebases, unavailable;

    public static final class Result {
        // Single capture thread owns this result; the caller consumes its
        // fields before the next accept() call. Reuse avoids allocations in
        // the 60-120Hz capture hot path; values are otherwise unchanged.
        public boolean forward;
        public long timestampNs;
        Result() { }
    }
    private final Result current = new Result();
    private Result result(boolean forward, long timestampNs) {
        current.forward = forward;
        current.timestampNs = timestampNs;
        return current;
    }

    public Result accept(long rawTimestampNs, int hash) {
        if (rawTimestampNs <= 0 || hash == 0) {
            unavailable++;
            // An unreadable image must not be discarded. Return the unchanged
            // timestamp and reset the phase predictor to avoid a sudden jump.
            lastRawNs = 0; lastOutNs = 0; hasHash = false;
            stableSamples = 0;
            return result(true, rawTimestampNs);
        }
        if (hasHash && lastHash == hash) {
            duplicates++;
            return result(false, rawTimestampNs);
        }
        hasHash = true;
        lastHash = hash;
        unique++;
        if (lastRawNs == 0 || rawTimestampNs <= lastRawNs) {
            lastRawNs = rawTimestampNs;
            lastOutNs = rawTimestampNs;
            return result(true, rawTimestampNs);
        }
        long rawDelta = rawTimestampNs - lastRawNs;
        lastRawNs = rawTimestampNs;
        if (rawDelta > REBASE_GAP_NS || rawDelta < MIN_NS) {
            // Source paused/resumed or switched game FPS: avoid fabricating a
            // backlog of timeline timestamps through the discontinuity.
            rebases++;
            stableSamples = 0;
            lastOutNs = rawTimestampNs;
            return result(true, rawTimestampNs);
        }
        if (rawDelta <= MAX_TRACK_NS) {
            if (stableSamples == 0) {
                expectedPeriodNs = rawDelta;
            } else {
                // Low-pass filter the cadence. Large single spikes are capture
                // jitter, not an immediate game speed change.
                double bounded = Math.max(expectedPeriodNs * 0.5,
                    Math.min(rawDelta, expectedPeriodNs * 1.5));
                expectedPeriodNs = expectedPeriodNs * 0.90 + bounded * 0.10;
            }
            stableSamples++;
        }
        long outputInterval = rawDelta;
        long resultTimestampNs = rawTimestampNs;
        if (stableSamples >= 8) {
            double expected = expectedPeriodNs;
            // Snap to normal refresh divisors only when close enough;
            // 45/50 FPS sources should retain their actual cadence.
            for (long period : KNOWN_PERIODS_NS) {
                if (Math.abs(expected - period) / period < 0.08) {
                    expected = period;
                    break;
                }
            }
            long predicted = lastOutNs + (long) expected;
            long phaseError = rawTimestampNs - predicted;
            if (Math.abs(phaseError) <= REBASE_PHASE_NS) {
                long correction = Math.max(-MAX_PHASE_STEP_NS,
                    Math.min(MAX_PHASE_STEP_NS, phaseError / 6));
                resultTimestampNs = Math.max(lastOutNs + 1, predicted + correction);
            } else {
                rebases++;
                resultTimestampNs = rawTimestampNs;
            }
            outputInterval = resultTimestampNs - lastOutNs;
        }
        rawIntervals[ringIndex] = rawDelta;
        outputIntervals[ringIndex] = outputInterval;
        ringIndex = (ringIndex + 1) % RING_SIZE;
        ringCount = Math.min(RING_SIZE, ringCount + 1);
        lastOutNs = resultTimestampNs;
        return result(true, resultTimestampNs);
    }

    public long getUnique() { return unique; }
    public long getDuplicates() { return duplicates; }
    public long getRebases() { return rebases; }
    public long getUnavailable() { return unavailable; }
    public double getEstimatedFps() {
        return stableSamples >= 2 && expectedPeriodNs > 0 ?
            1_000_000_000.0 / expectedPeriodNs : 0;
    }

    /** 95th percentile absolute deviation from the recent interval median. */
    public double rawJitterP95Ms() { return jitterP95Ms(rawIntervals); }
    public double smoothJitterP95Ms() { return jitterP95Ms(outputIntervals); }
    private double jitterP95Ms(long[] intervals) {
        if (ringCount < 8) return 0;
        System.arraycopy(intervals, 0, jitterScratch, 0, ringCount);
        java.util.Arrays.sort(jitterScratch, 0, ringCount);
        long median = jitterScratch[ringCount / 2];
        for (int i=0; i<ringCount; i++) jitterScratch[i] = Math.abs(jitterScratch[i] - median);
        java.util.Arrays.sort(jitterScratch, 0, ringCount);
        return jitterScratch[(int)Math.ceil(ringCount * 0.95)-1] / 1_000_000.0;
    }
}
