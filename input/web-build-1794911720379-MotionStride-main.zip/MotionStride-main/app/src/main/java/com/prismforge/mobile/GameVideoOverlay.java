package com.prismforge.mobile;

import android.content.Context;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.Display;
import android.view.Surface;
import android.view.TextureView;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Full-opacity touch-through using an AccessibilityService-owned trusted window.
 * TextureView + EGL output are unchanged from the working v0.9 pipeline.
 * The overlay is FLAG_NOT_TOUCHABLE; no gesture redirection or injection occurs.
 */
public final class GameVideoOverlay {
    public interface Callback {
        void surfaceAvailable(Surface surface, int width, int height);
        void surfaceGone(Surface surface);
        void stopRequested();
        void multiplierRequested(int multiplier);
        void flowScaleRequested(float flowScale);
        void compatibilityRequested(int mode);
    }

    private final Context context;
    private final Callback callback;
    private WindowManager windowManager;
    private FrameLayout root;
    private TextureView display;
    private PerformanceHudView monitor;
    private WindowManager.LayoutParams monitorParams;
    private Surface outputSurface;
    private boolean shown;
    private float displayRefreshRate = 0f;
    private long sessionTimeoutMs;
    private int requestedMultiplier=2,activeMultiplier=2,streamW,streamH;
    private float flowScale=0.45f;
    private float maximumRefreshRate=120f;
    private boolean monitorEnabled=true;
    private int compatibilityMode;

    public void setSessionTimeout(long value) { sessionTimeoutMs = Math.max(0L, value); }
    public void setMonitorEnabled(boolean value) { monitorEnabled=value; }
    public void setCompatibilityMode(int value) {
        compatibilityMode=Math.max(0,Math.min(2,value));
        if(monitor!=null)monitor.setCompatibilityMode(compatibilityMode);
    }

    public GameVideoOverlay(Context context, Callback callback) {
        this.context = context;
        this.callback = callback;
    }
    private int dp(int n) {
        return (int)(context.getResources().getDisplayMetrics().density * n + .5f);
    }
    public boolean show() {
        if (!(context instanceof PrismForgeAccessibilityService) ||
            !PrismForgeAccessibilityService.isReady()) {
            NativeLsfgStats.note("VIDEO: trusted accessibility service unavailable");
            return false;
        }
        if (shown) return true;
        try {
            windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            root = new FrameLayout(context);
            root.setBackgroundColor(Color.TRANSPARENT);
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

            display = new TextureView(context);
            display.setOpaque(true); // Full coverage; alpha=1, no underlying game blend.
            display.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override public void onSurfaceTextureAvailable(SurfaceTexture texture, int width, int height) {
                    outputSurface = new Surface(texture);
                    NativeLsfgStats.note("VIDEO TextureView output available: " + width + "x" + height);
                    callback.surfaceAvailable(outputSurface,width,height);
                }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture texture, int width, int height) {
                    if (outputSurface != null) callback.surfaceAvailable(outputSurface,width,height);
                }
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture texture) {
                    Surface old = outputSurface;
                    outputSurface = null;
                    if (old != null) callback.surfaceGone(old);
                    return true; // Framework releases TextureView's SurfaceTexture.
                }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture texture) { }
            });
            root.addView(display, new FrameLayout.LayoutParams(-1,-1));

            WindowManager.LayoutParams w = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                android.graphics.PixelFormat.TRANSLUCENT);
            w.gravity = Gravity.TOP | Gravity.START;
            // Trusted accessibility windows are exempt from untrusted-overlay touch limits.
            // Alpha=1 means the underlying game is NOT deliberately mixed by WindowManager.
            w.alpha = 1.0f;
            // Request high refresh on the actual overlay WINDOW that owns the TextureView.
            // Surface.setFrameRate alone may not update ViewRoot's Choreographer cadence.
            w.preferredRefreshRate = 120.0f;
            if (Build.VERSION.SDK_INT >= 30)
                w.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            else if (Build.VERSION.SDK_INT >= 28)
                w.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            windowManager.addView(root,w);
            if (monitorEnabled) addMonitorWindow();
            shown=true;
            NativeLsfgStats.note("VIDEO TRUSTED accessibility overlay: preferredRefreshRate=120.0, alpha=1.00, NOT_TOUCHABLE video, HUD="+monitorEnabled);
            refreshDisplayRate();
            return true;
        } catch (Throwable error) {
            NativeLsfgStats.note("VIDEO TextureView overlay failed: " + error);
            hide();
            return false;
        }
    }
    private void addMonitorWindow() {
        monitor = new PerformanceHudView(context);
        monitor.setCompatibilityMode(compatibilityMode);
        monitor.setSessionInfo(requestedMultiplier,activeMultiplier,streamW,streamH,maximumRefreshRate,flowScale);
        android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int logicalHeight = Math.round(dm.heightPixels / dm.density);
        int logicalWidth = Math.round(dm.widthPixels / dm.density);
        int availableHeight = Math.max(220, logicalHeight - 16);
        monitorParams = new WindowManager.LayoutParams(
            dp(Math.min(320,Math.max(190,logicalWidth-16))), dp(Math.min(262, availableHeight)),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            android.graphics.PixelFormat.TRANSLUCENT);
        monitorParams.gravity=Gravity.TOP | Gravity.START;
        monitorParams.x=Math.max(0,dm.widthPixels-monitorParams.width-dp(8));
        monitorParams.y=dp(7);
        if(Build.VERSION.SDK_INT>=28)
            monitorParams.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        installMonitorGestures();
        windowManager.addView(monitor,monitorParams);
    }
    private void setMonitorCompact(boolean compact) {
        if(monitor==null||monitorParams==null||monitor.isCompact()==compact)return;
        monitor.setCompact(compact);
        int logicalWidth=Math.round(context.getResources().getDisplayMetrics().widthPixels/
            context.getResources().getDisplayMetrics().density);
        monitorParams.width=dp(compact?(monitor.isCompactHorizontal()?190:132):Math.min(320,Math.max(190,logicalWidth-16)));
        monitorParams.height=dp(compact?(monitor.isCompactHorizontal()?29:96):262);
        android.util.DisplayMetrics dm=context.getResources().getDisplayMetrics();
        monitorParams.x=Math.max(0,Math.min(monitorParams.x,dm.widthPixels-monitorParams.width));
        monitorParams.y=Math.max(0,Math.min(monitorParams.y,dm.heightPixels-monitorParams.height));
        windowManager.updateViewLayout(monitor,monitorParams);
        NativeLsfgStats.note("HUD mode="+(compact?"compact":"expanded"));
    }
    private void toggleCompactLayout() {
        if(monitor==null||monitorParams==null||!monitor.isCompact())return;
        monitor.setCompactHorizontal(!monitor.isCompactHorizontal());
        monitorParams.width=dp(monitor.isCompactHorizontal()?190:132);
        monitorParams.height=dp(monitor.isCompactHorizontal()?29:96);
        android.util.DisplayMetrics dm=context.getResources().getDisplayMetrics();
        monitorParams.x=Math.max(0,Math.min(monitorParams.x,dm.widthPixels-monitorParams.width));
        monitorParams.y=Math.max(0,Math.min(monitorParams.y,dm.heightPixels-monitorParams.height));
        windowManager.updateViewLayout(monitor,monitorParams);
        NativeLsfgStats.note("HUD compact layout="+(monitor.isCompactHorizontal()?"horizontal":"vertical"));
    }
    private void installMonitorGestures() {
        final int slop=ViewConfiguration.get(context).getScaledTouchSlop();
        final long longPressMs=ViewConfiguration.getLongPressTimeout();
        monitor.setOnTouchListener(new View.OnTouchListener() {
            float downRawX,downRawY;
            int startX,startY;
            long downAt;
            long lastCompactTapAt;
            float lastCompactTapX,lastCompactTapY;
            boolean moved;
            @Override public boolean onTouch(View v,MotionEvent e) {
                switch(e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX=e.getRawX();downRawY=e.getRawY();
                        startX=monitorParams.x;startY=monitorParams.y;
                        downAt=android.os.SystemClock.uptimeMillis();moved=false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=e.getRawX()-downRawX,dy=e.getRawY()-downRawY;
                        if(Math.abs(dx)>slop||Math.abs(dy)>slop)moved=true;
                        if(moved) {
                            android.util.DisplayMetrics dm=context.getResources().getDisplayMetrics();
                            monitorParams.x=Math.max(0,Math.min(startX+Math.round(dx),dm.widthPixels-monitorParams.width));
                            monitorParams.y=Math.max(0,Math.min(startY+Math.round(dy),dm.heightPixels-monitorParams.height));
                            windowManager.updateViewLayout(monitor,monitorParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        long held=android.os.SystemClock.uptimeMillis()-downAt;
                        if(!moved&&monitor.isCompact()&&held>=longPressMs) {
                            lastCompactTapAt=0;
                            setMonitorCompact(false);
                        } else if(!moved&&monitor.isCompact()) {
                            long now=android.os.SystemClock.uptimeMillis();
                            boolean doubleTap=lastCompactTapAt>0 &&
                                now-lastCompactTapAt<=ViewConfiguration.getDoubleTapTimeout() &&
                                Math.abs(e.getRawX()-lastCompactTapX)<=slop*2 &&
                                Math.abs(e.getRawY()-lastCompactTapY)<=slop*2;
                            if(doubleTap) {
                                lastCompactTapAt=0;
                                toggleCompactLayout();
                            } else {
                                lastCompactTapAt=now;
                                lastCompactTapX=e.getRawX();lastCompactTapY=e.getRawY();
                            }
                        } else if(!moved&&!monitor.isCompact()) {
                            float x=e.getX()/context.getResources().getDisplayMetrics().density;
                            float y=e.getY()/context.getResources().getDisplayMetrics().density;
                            int action=monitor.actionAt(x,y);
                            if(action==PerformanceHudView.ACTION_MINIMIZE)setMonitorCompact(true);
                            else if(action==PerformanceHudView.ACTION_FPS)monitor.setPage(0);
                            else if(action==PerformanceHudView.ACTION_RESOURCES)monitor.setPage(1);
                            else if(action==PerformanceHudView.ACTION_INFO)monitor.setPage(2);
                            else if(action==PerformanceHudView.ACTION_COMPATIBILITY)
                                callback.compatibilityRequested((compatibilityMode+1)%3);
                            else if(action==PerformanceHudView.ACTION_STOP)callback.stopRequested();
                            else if(action==PerformanceHudView.ACTION_MULTIPLIER)
                                callback.multiplierRequested(requestedMultiplier==4?2:4);
                            else if(action==PerformanceHudView.ACTION_FLOW_DOWN)
                                callback.flowScaleRequested(flowScale-0.05f);
                            else if(action==PerformanceHudView.ACTION_FLOW_UP)
                                callback.flowScaleRequested(flowScale+0.05f);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:return true;
                    default:return false;
                }
            }
        });
    }
    public boolean isShown() { return shown; }
    public float getMaximumRefreshRate() {
        // AccessibilityService is a non-visual Context on recent Android builds;
        // Context.getDisplay() throws instead of returning the default display.
        // DisplayManager is safe from services and still exposes every mode.
        float max=60f;
        try {
            DisplayManager manager=(DisplayManager)context.getSystemService(Context.DISPLAY_SERVICE);
            Display d=manager==null?null:manager.getDisplay(Display.DEFAULT_DISPLAY);
            if(d!=null) {
                max=Math.max(max,d.getRefreshRate());
                for(Display.Mode mode:d.getSupportedModes())max=Math.max(max,mode.getRefreshRate());
            }
        } catch(Throwable error) {
            NativeLsfgStats.note("Display mode query fallback: "+error);
        }
        return max;
    }
    public void setSessionInfo(int requested,int active,int w,int h,float refresh,float flow) {
        requestedMultiplier=requested;activeMultiplier=active;streamW=w;streamH=h;maximumRefreshRate=refresh;
        flowScale=flow;
        if(monitor!=null)monitor.setSessionInfo(requested,active,w,h,refresh,flow);
    }
    public void refreshDisplayRate() {
        if (!shown || root == null) return;
        Display current = root.getDisplay();
        if (current != null) {
            float hz = current.getRefreshRate();
            if (hz > 0f && Math.abs(hz - displayRefreshRate) >= 0.5f) {
                displayRefreshRate = hz;
                NativeLsfgStats.note("VIDEO Display.getRefreshRate changed: " + hz + " Hz");
            }
        }
    }
    public void update(NativeLsfgStats.Snapshot state) {
        if (monitor != null) monitor.update(state);
    }
    public void hide() {
        if (monitor != null && windowManager != null) {
            try { windowManager.removeViewImmediate(monitor); }
            catch (Throwable ignored) { }
        }
        if (root != null && windowManager != null) {
            try { windowManager.removeViewImmediate(root); }
            catch (Throwable ignored) { }
        }
        shown=false;
        root=null;
        display=null;
        monitor=null;
        monitorParams=null;
        windowManager=null;
        // Surface release is owned by the service's EGL/GL thread callback.
    }
}
