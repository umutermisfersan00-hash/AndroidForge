package com.prismforge.mobile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Inspects a user-supplied DLL locally, including DXBC container table boundaries.
 * Does not extract shader code, execute DLLs, decrypt or redistribute anything.
 */
public final class DllInspector {
    private DllInspector() { }
    public static final class Result {
        public final long size;
        public final String digest;
        public final int dxbcMarkers, dxilMarkers, validDxbcContainers, shaderContainers;
        public final boolean validPe;
        Result(long bytes, String hash, int dxbc, int dxil, int validated, int shaders, boolean pe) {
            size=bytes; digest=hash; dxbcMarkers=dxbc; dxilMarkers=dxil;
            validDxbcContainers=validated; shaderContainers=shaders; validPe=pe;
        }
        public String summary() {
            if (!"hu".equals(Locale.getDefault().getLanguage())) {
                return "File: " + String.format(Locale.ROOT, "%.2f MB", size / 1048576.0)
                    + "\nWindows PE format: " + (validPe ? "yes" : "no")
                    + "\nDXBC markers: " + dxbcMarkers
                    + "\nStructurally valid DXBC containers: " + validDxbcContainers
                    + "\nContainers with shader-code chunks: " + shaderContainers
                    + "\nDXIL signatures: " + dxilMarkers + "\nSHA-256: " + digest
                    + "\n\nDXBC structure inspection only. NOT shader conversion or LSFG rendering.";
            }
            return "Fájl: " + String.format(Locale.ROOT, "%.2f MB", size / 1048576.0)
                + "\nWindows PE-formátum: " + (validPe ? "igen" : "nem")
                + "\nDXBC jelöltek: " + dxbcMarkers
                + "\nStrukturálisan érvényes DXBC konténerek: " + validDxbcContainers
                + "\nShaderkód chunkot tartalmazó konténerek: " + shaderContainers
                + "\nDXIL szignatúrák: " + dxilMarkers
                + "\nSHA-256: " + digest
                + "\n\nCsak DXBC struktúravizsgálat. NEM shaderkonverzió és NEM LSFG render.";
        }
    }
    private static int le32(byte[] b, int i) {
        return (b[i]&255)|((b[i+1]&255)<<8)|((b[i+2]&255)<<16)|((b[i+3]&255)<<24);
    }
    private static boolean fourCC(byte[] b, int p, String str) {
        return b[p] == str.charAt(0) && b[p+1] == str.charAt(1)
            && b[p+2] == str.charAt(2) && b[p+3] == str.charAt(3);
    }
    private static int validateDxbc(byte[] all, int pos) {
        long remaining = (long)all.length-pos;
        if (remaining < 36 || !fourCC(all,pos,"DXBC")) return -1;
        int size=le32(all,pos+24), count=le32(all,pos+28);
        if (count < 1 || count > 128 || size < 32 + count*4 || size > remaining) return -1;
        Set<Integer> starts = new HashSet<>();
        boolean shader = false;
        for (int i=0; i<count; i++) {
            int chunkOff=le32(all,pos+32+i*4);
            if (chunkOff < 32+count*4 || chunkOff > size-8 || !starts.add(chunkOff)) return -1;
            int abs=pos+chunkOff;
            int chunkSize=le32(all,abs+4);
            if (chunkSize < 0 || chunkSize > size-chunkOff-8) return -1;
            if (fourCC(all,abs,"SHDR") || fourCC(all,abs,"SHEX")
                || fourCC(all,abs,"DXIL")) shader = true;
        }
        return shader ? 1 : 0;
    }
    public static Result inspect(InputStream source) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // A full-buffer pass is required to validate each DXBC chunk offset, not just scan magic bytes.
            // Lossless.dll in this project is ~7MB. Keep a strict 64MB limit for on-phone memory safety.
            ByteArrayOutputStream memory = new ByteArrayOutputStream(8 * 1024 * 1024);
            byte[] buffer = new byte[65536];
            int n; int total=0;
            while ((n=source.read(buffer)) != -1) {
                if (n == 0) continue;
                if ((long)total+n > 64L*1024*1024)
                    throw new IOException("hu".equals(Locale.getDefault().getLanguage())
                        ? "DLL túllépi a 64 MB-os elemzési korlátot"
                        : "DLL exceeds the 64 MB inspection limit");
                memory.write(buffer,0,n); md.update(buffer,0,n); total+=n;
            }
            byte[] all=memory.toByteArray();
            boolean pe=false;
            if (all.length >= 64 && all[0]=='M' && all[1]=='Z') {
                int pePos=le32(all,0x3c);
                pe=pePos>=64 && (long)pePos+4<=all.length && fourCC(all,pePos,"PE\0\0");
            }
            int dxbc=0,dxil=0,valid=0,shaders=0;
            for (int i=0; i<=all.length-4; i++) {
                if (fourCC(all,i,"DXIL")) dxil++;
                if (fourCC(all,i,"DXBC")) {
                    dxbc++;
                    int r=validateDxbc(all,i);
                    if (r>=0) {valid++; if (r==1) shaders++;}
                }
            }
            StringBuilder hex=new StringBuilder(64);
            for (byte b:md.digest()) hex.append(String.format(Locale.ROOT,"%02x",b&255));
            return new Result(total,hex.toString(),dxbc,dxil,valid,shaders,pe);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 unavailable",ex);
        } finally {source.close();}
    }
}
