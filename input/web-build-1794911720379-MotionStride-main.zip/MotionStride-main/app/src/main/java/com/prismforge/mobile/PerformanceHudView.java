package com.prismforge.mobile;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.util.Locale;

/** In-game, always touch-through, single-view diagnostic panel.
 * Draws only upon statistics updates (normally every 650 ms), not at 120 Hz.
 * The plot represents native engine counters; POST is not SurfaceFlinger FPS.
 */
public final class PerformanceHudView extends View {
    public static final int ACTION_NONE=0,ACTION_MINIMIZE=1,ACTION_FPS=2,
        ACTION_RESOURCES=3,ACTION_INFO=4,ACTION_STOP=5,ACTION_MULTIPLIER=6,
        ACTION_FLOW_DOWN=7,ACTION_FLOW_UP=8,ACTION_COMPATIBILITY=9;
    private static final int AQUA=0xff6debdc, AMBER=0xffffd18a, SKY=0xff84aeff;
    private static final int WHITE=0xffecf6ff, MUTED=0xffa6c1d9, WARN=0xffffa2a0;
    private static final int HISTORY=90;
    private final float[] real=new float[HISTORY], generated=new float[HISTORY];
    private int count,head;
    private long lastSampleMs=-1;
    private NativeLsfgStats.Snapshot snapshot;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line=new Path();
    private final float density;
    private final float textScale;
    private boolean compact;
    private boolean compactHorizontal;
    private int page,requestedMultiplier=2,activeMultiplier=2,streamW,streamH;
    private int compatibilityMode;
    private float refreshRate=120f,flowScale=0.45f;
    private String s(int id){return getContext().getString(id);}

    public PerformanceHudView(Context context) {
        super(context);
        density=context.getResources().getDisplayMetrics().density;
        textScale=context.getResources().getDisplayMetrics().scaledDensity;
        // Leave layer allocation to the parent HW-accelerated window.
    }
    public void update(NativeLsfgStats.Snapshot s) {
        if(s==null) return;
        snapshot=s;
        if(s.atMs>0 && s.atMs!=lastSampleMs) {
            lastSampleMs=s.atMs;
            real[head]=(float)Math.max(0,s.realFps);
            generated[head]=(float)Math.max(0,s.postedFps);
            head=(head+1)%HISTORY;
            if(count<HISTORY) count++;
        }
        invalidate();
    }
    public void setCompact(boolean value) {
        compact=value;
        invalidate();
    }
    public boolean isCompact() { return compact; }
    public boolean isCompactHorizontal() { return compactHorizontal; }
    public void setCompactHorizontal(boolean value) { compactHorizontal=value;invalidate(); }
    public void setPage(int value){page=Math.max(0,Math.min(2,value));invalidate();}
    public void setCompatibilityMode(int value){compatibilityMode=Math.max(0,Math.min(2,value));invalidate();}
    public void setSessionInfo(int requested,int active,int w,int h,float refresh,float flow){
        requestedMultiplier=requested;activeMultiplier=active;streamW=w;streamH=h;refreshRate=refresh;flowScale=flow;invalidate();
    }
    public int actionAt(float x,float y){
        float w=getWidth()/density,h=getHeight()/density;
        float scale=Math.min(1f,Math.min(h/344f,w/420f));
        if(scale>0f){x/=scale;y/=scale;}
        if(x>=382&&y<=45)return ACTION_MINIMIZE;
        if(x>=225&&x<365&&y<=45)return ACTION_MULTIPLIER;
        if(x>=365&&y>=57&&y<107)return ACTION_FPS;
        if(x>=365&&y>=107&&y<157)return ACTION_RESOURCES;
        if(x>=365&&y>=157&&y<207)return ACTION_INFO;
        if(x>=365&&y>=207&&y<262)return ACTION_COMPATIBILITY;
        if(x>=365&&y>=265&&y<340)return ACTION_STOP;
        if(page==2&&y>=258&&y<318&&x>=10&&x<75)return ACTION_FLOW_DOWN;
        if(page==2&&y>=258&&y<318&&x>=112&&x<177)return ACTION_FLOW_UP;
        return ACTION_NONE;
    }
    private void color(int argb) { paint.setColor(argb);paint.setStyle(Paint.Style.FILL);paint.setStrokeWidth(1);paint.setPathEffect(null); }
    private void text(Canvas c,String value,float x,float y,float sp,int color,boolean bold) {
        color(color);paint.setTypeface(bold?android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.BOLD):android.graphics.Typeface.DEFAULT);
        paint.setTextSize(sp*textScale/density);
        c.drawText(value,x,y,paint);
    }
    private static String number(double d,int digits) {
        return d<0 ? "N/A" : String.format(Locale.ROOT,digits==0?"%.0f":"%.1f",d);
    }
    private void path(Canvas c,float[] data,int color,float left,float top,float width,float height) {
        if(count<2) return;
        line.reset();
        int oldest=(head-count+HISTORY)%HISTORY;
        for(int i=0;i<count;i++) {
            float fps=data[(oldest+i)%HISTORY];
            float x=left+((HISTORY-count+i)*width/(HISTORY-1));
            float y=top+height*(1f-Math.min(120f,Math.max(0f,fps))/120f);
            if(i==0)line.moveTo(x,y);else line.lineTo(x,y);
        }
        color(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.9f);
        c.drawPath(line,paint);paint.setStyle(Paint.Style.FILL);
    }
    private void card(Canvas c,float l,float t,float r,float b,String label,String value,int accent){
        color(0xff10243a);c.drawRoundRect(l,t,r,b,9,9,paint);
        color(0xff29455c);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.8f);c.drawRoundRect(l+.5f,t+.5f,r-.5f,b-.5f,9,9,paint);paint.setStyle(Paint.Style.FILL);
        color(accent);c.drawRoundRect(l+8,t+12,l+12,b-10,2,2,paint);
        text(c,label,l+19,t+17,8,MUTED,false);text(c,value,l+19,t+38,13,WHITE,true);
    }
    private void compactIcon(Canvas c,int icon,float cx,float cy,int ink){
        color(ink);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.7f);
        paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        if(icon==0){
            // Game controller.
            android.graphics.Path p=new android.graphics.Path();
            p.moveTo(cx-8,cy+5);p.cubicTo(cx-10,cy+5,cx-9,cy-7,cx-5,cy-7);
            p.lineTo(cx+5,cy-7);p.cubicTo(cx+9,cy-7,cx+10,cy+5,cx+8,cy+5);
            p.cubicTo(cx+6,cy+5,cx+5,cy+1,cx+3,cy+1);p.lineTo(cx-3,cy+1);
            p.cubicTo(cx-5,cy+1,cx-6,cy+5,cx-8,cy+5);c.drawPath(p,paint);
            c.drawLine(cx-5,cy-3,cx-1,cy-3,paint);c.drawLine(cx-3,cy-5,cx-3,cy-1,paint);
            c.drawCircle(cx+4,cy-4,0.8f,paint);c.drawCircle(cx+6,cy-2,0.8f,paint);
        }else if(icon==1){
            // Display.
            c.drawRoundRect(cx-9,cy-7,cx+9,cy+5,2,2,paint);
            c.drawLine(cx,cy+5,cx,cy+8,paint);c.drawLine(cx-5,cy+8,cx+5,cy+8,paint);
        }else{
            // Alarm clock / frame time.
            c.drawCircle(cx,cy,7,paint);c.drawLine(cx,cy,cx,cy-4,paint);c.drawLine(cx,cy,cx+3,cy+2,paint);
            c.drawLine(cx-6,cy-7,cx-9,cy-4,paint);c.drawLine(cx+6,cy-7,cx+9,cy-4,paint);
            c.drawLine(cx-5,cy+6,cx-7,cy+9,paint);c.drawLine(cx+5,cy+6,cx+7,cy+9,paint);
        }
        paint.setStrokeCap(Paint.Cap.BUTT);paint.setStrokeJoin(Paint.Join.MITER);paint.setStyle(Paint.Style.FILL);
    }
    private void sideButton(Canvas c,float top,int icon,boolean selected,int fill){
        color(selected?0xff174c55:0xff10243a);c.drawRoundRect(370,top,412,top+48,9,9,paint);
        color(selected?AQUA:fill);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);c.drawRoundRect(370.5f,top+.5f,411.5f,top+47.5f,9,9,paint);paint.setStyle(Paint.Style.FILL);
        int ink=selected?AQUA:fill;
        color(ink);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.2f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        float cx=391,cy=top+24;
        if(icon==0){
            c.drawArc(cx-11,cy-10,cx+11,cy+12,195,150,false,paint);
            c.drawLine(cx,cy,cx+7,cy-7,paint);c.drawCircle(cx,cy,1.5f,paint);
        }else if(icon==1){
            c.drawRoundRect(cx-8,cy-8,cx+8,cy+8,2,2,paint);
            c.drawRect(cx-4,cy-4,cx+4,cy+4,paint);
            for(int i=-1;i<=1;i+=2){
                c.drawLine(cx+i*12,cy-5,cx+i*8,cy-5,paint);c.drawLine(cx+i*12,cy+5,cx+i*8,cy+5,paint);
                c.drawLine(cx-5,cy+i*12,cx-5,cy+i*8,paint);c.drawLine(cx+5,cy+i*12,cx+5,cy+i*8,paint);
            }
        }else{
            c.drawCircle(cx,cy,11,paint);c.drawLine(cx,cy-2,cx,cy+7,paint);c.drawCircle(cx,cy-7,1,paint);
        }
        paint.setStrokeCap(Paint.Cap.BUTT);paint.setStrokeJoin(Paint.Join.MITER);paint.setStyle(Paint.Style.FILL);
    }
    private void compatibilityButton(Canvas c,float top){
        color(0xff10243a);c.drawRoundRect(370,top,412,top+48,9,9,paint);
        color(AQUA);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);
        c.drawRoundRect(370.5f,top+.5f,411.5f,top+47.5f,9,9,paint);paint.setStyle(Paint.Style.FILL);
        String mode=compatibilityMode==1?"DIR":compatibilityMode==2?"SAFE":"AUTO";
        float x=compatibilityMode==0?376:compatibilityMode==1?380:374;
        text(c,mode,x,top+28,compatibilityMode==0?7:8,AQUA,true);
    }
    @Override protected void onDraw(Canvas raw) {
        super.onDraw(raw);
        // Drawing in design dp units gives a consistent footprint on 2340x1080.
        raw.save();
        raw.scale(density,density);
        final float w=getWidth()/density, h=getHeight()/density;
        if(w<=10||h<=10){raw.restore();return;}
        NativeLsfgStats.Snapshot s=snapshot;
        if(compact) {
            color(0xed0a1828);raw.drawRoundRect(0,0,w,h,11,11,paint);
            color(0xff355f79);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);
            raw.drawRoundRect(.5f,.5f,w-.5f,h-.5f,11,11,paint);
            paint.setStyle(Paint.Style.FILL);
            if(compactHorizontal) {
                text(raw,"MS",6,18,9,AQUA,true);
                color(0xff355f79);raw.drawRect(27,5,28,h-5,paint);
                if(s==null) text(raw,s(R.string.hud_starting),34,18,9,WHITE,true);
                else {
                    compactIcon(raw,0,38,14.5f,AQUA);text(raw,number(s.realFps,1),51,18,8,AQUA,true);
                    compactIcon(raw,1,91,14.5f,SKY);text(raw,number(s.postedFps,1),104,18,8,SKY,true);
                    compactIcon(raw,2,144,14.5f,WHITE);text(raw,number(s.postP50Ms,1),157,18,8,WHITE,true);
                }
            } else {
                text(raw,"MOTIONSTRIDE",10,18,10,AQUA,true);
                if(s==null) {
                    text(raw,s(R.string.hud_starting),10,52,11,WHITE,true);
                } else {
                    compactIcon(raw,0,18,37,AQUA);text(raw,number(s.realFps,1)+" FPS",35,41,11,AQUA,true);
                    compactIcon(raw,1,18,61,SKY);text(raw,number(s.postedFps,1)+" FPS",35,65,11,SKY,true);
                    compactIcon(raw,2,18,84,WHITE);text(raw,number(s.postP50Ms,1)+" ms",35,88,11,WHITE,true);
                }
            }
            raw.restore();
            return;
        }
        // Three-page dashboard inspired by compact game performance panels.
        float shrink=Math.min(1f,Math.min(h/344f,w/420f));
        raw.scale(shrink,shrink);
        float logicalW=w/shrink;
        float left=10;
        color(0xed0a1828);raw.drawRoundRect(0,0,logicalW,344,12,12,paint);
        color(0xff355f79);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);
        raw.drawRoundRect(.5f,.5f,logicalW-.5f,343.5f,12,12,paint);
        paint.setStyle(Paint.Style.FILL);
        text(raw,"MOTIONSTRIDE",left,25,14,WHITE,true);
        color(0xff1dcc63);raw.drawCircle(133,20,4,paint);text(raw,"STREAM / FRAMEGEN",142,24,8,MUTED,true);
        color(0xff10243a);raw.drawRoundRect(225,7,365,38,8,8,paint);
        text(raw,s(R.string.hud_mode)+"  "+requestedMultiplier+"×"+(activeMultiplier!=requestedMultiplier?" → "+activeMultiplier+"× "+s(R.string.hud_auto):""),237,27,10,AQUA,true);
        text(raw,"—",392,27,17,MUTED,true);
        if(s==null){text(raw,s(R.string.hud_starting),left,90,14,WHITE,true);raw.restore();return;}
        DeviceTelemetry.Sample d=s.device;
        sideButton(raw,57,0,page==0,AQUA);sideButton(raw,107,1,page==1,AQUA);sideButton(raw,157,2,page==2,AQUA);
        compatibilityButton(raw,207);
        color(0xffd9273e);raw.drawRoundRect(370,267,412,333,9,9,paint);
        color(WHITE);raw.drawRoundRect(385,288,397,300,2,2,paint);
        if(page==0){
            text(raw,"FPS / FRAME PACING",left,59,13,WHITE,true);text(raw,"P50 "+number(s.postP50Ms,1)+" ms",255,59,9,AQUA,true);
            final float gl=35,gt=76,gw=315,gh=125;
            for(int i=0;i<=4;i++){float y=gt+gh*i/4f;color(0xff294054);raw.drawLine(gl,y,gl+gw,y,paint);text(raw,String.valueOf(120-30*i),8,y+3,7,MUTED,false);}
            path(raw,real,AQUA,gl,gt,gw,gh);path(raw,generated,AMBER,gl,gt,gw,gh);
            text(raw,"● "+s(R.string.hud_game),95,216,8,AQUA,true);text(raw,"● POST",190,216,8,AMBER,true);
            card(raw,10,230,177,280,s(R.string.hud_game_fps),number(s.realFps,1),AQUA);card(raw,184,230,357,280,"POST FPS",number(s.postedFps,1),AMBER);
            card(raw,10,287,177,337,"FRAME TIME",number(s.postP50Ms,1)+" ms",SKY);card(raw,184,287,357,337,s(R.string.hud_generated),number(s.generatedFps,1)+" FPS",AQUA);
        }else if(page==1){
            text(raw,s(R.string.hud_memory),left,59,13,WHITE,true);
            card(raw,10,72,177,126,"CPU APP",d==null?"—":number(d.appCpuOneCorePct,0)+" %",AQUA);card(raw,184,72,357,126,"CPU RENDSZER",d==null?"—":number(d.systemCpuPct,0)+" %",SKY);
            card(raw,10,134,177,188,"GPU BUSY",d==null?"—":number(d.gpuBusyPct,0)+" %",AMBER);card(raw,184,134,357,188,s(R.string.hud_thermal),String.valueOf(s.thermalStatus),s.thermalStatus>=3?WARN:AQUA);
            card(raw,10,196,177,250,"APP PSS",d==null?"—":d.appPssMb+" MB",AQUA);card(raw,184,196,357,250,"GFX RAM",d==null?"—":d.graphicsMb+" MB",SKY);
            card(raw,10,258,177,318,"QUEUE",number(s.queueMs,1)+" ms",s.queueMs>16?WARN:AQUA);card(raw,184,258,357,318,"LATENCY",number(s.latencyMs,1)+" ms",AMBER);
        }else{
            text(raw,s(R.string.hud_diagnostics),left,59,13,WHITE,true);
            card(raw,10,72,177,126,"COPY / FG",number(s.copyMs,1)+" / "+number(s.presentMs,1)+" ms",AQUA);card(raw,184,72,357,126,"WAIT / BLIT",number(s.waitMs,1)+" / "+number(s.blitMs,1)+" ms",SKY);
            card(raw,10,134,177,188,"WALL",number(s.wallMs,1)+" ms",s.wallMs>16.7?WARN:AQUA);card(raw,184,134,357,188,"POST P95 / P99",number(s.postP95Ms,1)+" / "+number(s.postP99Ms,1),AMBER);
            card(raw,10,196,177,250,"INPUT JITTER",number(s.inputJitterP95,1)+" ms",AQUA);card(raw,184,196,357,250,s(R.string.hud_display),number(refreshRate,0)+" Hz",SKY);
            card(raw,10,258,177,318,"FLOW SCALE","−   "+String.format(Locale.ROOT,"%.2f",flowScale)+"   +",AQUA);card(raw,184,258,357,318,s(R.string.hud_resolution),streamW+" × "+streamH,AMBER);
        }
        raw.restore();
    }
}
