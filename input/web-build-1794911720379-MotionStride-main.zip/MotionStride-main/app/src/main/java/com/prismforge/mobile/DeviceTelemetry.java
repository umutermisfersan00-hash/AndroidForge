package com.prismforge.mobile;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Debug;
import android.os.Process;
import android.os.SystemClock;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** Low-rate observations only; never run on the capture / LSFG / UI thread.
 * GPU utilisation is optional: no privileged APIs or synthetic percentages.
 */
public final class DeviceTelemetry {
    public static final class Sample {
        public final long atMs;
        /** Percent of ONE logical core; may exceed 100% for a multithreaded app. */
        public final double appCpuOneCorePct, systemCpuPct, gpuBusyPct;
        public final int cores;
        public final long appPssMb, javaHeapMb, nativeHeapMb, graphicsMb, swapMb;
        public final long availableRamMb, totalRamMb;
        public final boolean lowMemory;
        public final String gpuSource;
        Sample(long atMs, double appCpuOneCorePct, double systemCpuPct,
                double gpuBusyPct, int cores, long appPssMb, long javaHeapMb,
                long nativeHeapMb, long graphicsMb, long swapMb, long availableRamMb, long totalRamMb,
                boolean lowMemory, String gpuSource) {
            this.atMs=atMs; this.appCpuOneCorePct=appCpuOneCorePct;
            this.systemCpuPct=systemCpuPct; this.gpuBusyPct=gpuBusyPct;
            this.cores=cores; this.appPssMb=appPssMb; this.javaHeapMb=javaHeapMb;
            this.nativeHeapMb=nativeHeapMb; this.graphicsMb=graphicsMb; this.swapMb=swapMb; this.availableRamMb=availableRamMb;
            this.totalRamMb=totalRamMb; this.lowMemory=lowMemory;
            this.gpuSource=gpuSource;
        }
    }
    private final ActivityManager activity;
    private final ActivityManager.MemoryInfo ram = new ActivityManager.MemoryInfo();
    private final Debug.MemoryInfo processRam = new Debug.MemoryInfo();
    private final int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
    private long prevMs, prevCpuMs, prevSystemTotal=-1, prevSystemIdle=-1;
    private boolean sysCpuDenied, gpuDenied;
    private static final long MB=1024L*1024L;

    public DeviceTelemetry(Context context) {
        activity=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
    }
    private static long parseKbToMb(String text) {
        try { return text==null ? -1L : Long.parseLong(text)/1024L; }
        catch(NumberFormatException ignored) { return -1L; }
    }
    public Sample sample() {
        long now=SystemClock.elapsedRealtime();
        long used=Process.getElapsedCpuTime();
        double appCpu=-1;
        if (prevMs>0 && now>prevMs && used>=prevCpuMs)
            appCpu=100.0*(used-prevCpuMs)/(now-prevMs);
        prevMs=now; prevCpuMs=used;

        double sysCpu=-1;
        if (!sysCpuDenied) {
            try (BufferedReader r=new BufferedReader(new FileReader("/proc/stat"))) {
                String line=r.readLine();
                if (line==null || !line.startsWith("cpu ")) throw new IllegalStateException("no cpu aggregate");
                String[] parts=line.trim().split("\\s+");
                long total=0,idle=0;
                for(int i=1;i<parts.length;i++) {
                    long v=Long.parseLong(parts[i]); total+=v;
                    if(i==4 || i==5) idle+=v; // idle + iowait
                }
                if(prevSystemTotal>=0 && total>prevSystemTotal)
                    sysCpu=100.0*Math.max(0.0,1.0-(idle-prevSystemIdle)/(double)(total-prevSystemTotal));
                prevSystemTotal=total;prevSystemIdle=idle;
            } catch(Exception denied) { sysCpuDenied=true; }
        }

        long available=-1,totalMem=-1;
        boolean low=false;
        if (activity!=null) {
            try {
                activity.getMemoryInfo(ram);
                available=ram.availMem/MB;totalMem=ram.totalMem/MB;low=ram.lowMemory;
            } catch(Exception ignored) { }
        }
        long pss=-1, graphics=-1, swap=-1;
        try {
            Debug.getMemoryInfo(processRam);
            pss=processRam.getTotalPss()/1024L;
            graphics=parseKbToMb(processRam.getMemoryStat("summary.graphics"));
            swap=parseKbToMb(processRam.getMemoryStat("summary.total-swap"));
        } catch(Exception ignored) { }
        Runtime runtime=Runtime.getRuntime();
        long javaHeap=(runtime.totalMemory()-runtime.freeMemory())/MB;
        long nativeHeap=Debug.getNativeHeapAllocatedSize()/MB;

        double gpu=-1;
        String gpuSource="not available";
        if (!gpuDenied) {
            // Qualcomm KGSL is private, often SELinux-restricted. If it cannot
            // be read, do NOT label kernel timings as a fabricated GPU %.
            try (BufferedReader r=new BufferedReader(new FileReader("/sys/class/kgsl/kgsl-3d0/gpubusy"))) {
                String[] t=r.readLine().trim().split("\\s+");
                if(t.length<2) throw new IllegalStateException("bad KGSL sample");
                double busy=Double.parseDouble(t[0]), total=Double.parseDouble(t[1]);
                if(total<=0 || busy<0 || busy>total) throw new IllegalStateException("invalid KGSL ratio");
                gpu=busy*100.0/total;
                gpuSource="KGSL";
            } catch(Exception ignored) { gpuDenied=true; }
        }
        return new Sample(now,appCpu,sysCpu,gpu,cores,pss,javaHeap,nativeHeap,
            graphics,swap,available,totalMem,low,gpuSource);
    }
}
