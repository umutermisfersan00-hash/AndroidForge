package com.prismforge.mobile;

import android.os.Build;
import android.content.Context;
import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import android.os.SystemClock;
import java.util.Arrays;
import com.frameflow.s25.session.NativeBridge;
import java.util.Locale;

public final class NativeLsfgStats {
    private static boolean hu() { return "hu".equals(Locale.getDefault().getLanguage()); }
    private static final StringBuilder log = new StringBuilder();
    private static String state=hu()?"Nincs natív LSFG munkamenet":"No native LSFG session";
    private static String error="";
    private static long callbacks, forwarded, generated, posted, unique, start, lastMs;
    private static double capturedFps, genFps, postFps, realFps, latencyMs, queueMs;
    private static int w,h, initRc=999;
    private static String mode="";
    private static double copyMs,presentMs,waitMs,blitMs,wallMs;
    private static boolean hasProfile;
    private static final long[] profile = new long[6];
    private static final long[] recentIntervalsNs = new long[96];
    private static final double[] postIntervalScratchMs = new double[96];
    // Full GPU timing snapshots are diagnostic-only. Keep FPS/latency polling
    // responsive, but sample heavyweight native profiling less frequently.
    private static long lastDetailedPollMs;
    private static double postP50Ms, postP95Ms, postP99Ms, postJankPercent;
    private static int postIntervals;
    private static int thermalStatus = -1;
    private static double inputFps, rawInputJitterP95, smoothInputJitterP95;
    private static long duplicateCaptureDrops, cadenceRebases, unavailableSignatures;
    private static DeviceTelemetry.Sample deviceSample;
    private static final Snapshot[] timeline = new Snapshot[360];
    private static int timelineCount, timelineHead;

    /** All observations at one instant; GPU % is unknown unless a device counter is readable.
     * Native POST counters do not prove actual display presentation timing.
     */
    public static final class Snapshot {
        public final long atMs;
        public final double realFps, generatedFps, postedFps, latencyMs, queueMs;
        public final double copyMs, presentMs, waitMs, blitMs, wallMs;
        public final double postP50Ms, postP95Ms, postP99Ms, postJankPct, inputJitterP95;
        public final int thermalStatus;
        public final long duplicateDrops;
        public final boolean profileValid;
        public final DeviceTelemetry.Sample device;
        Snapshot(long atMs, DeviceTelemetry.Sample device) {
            this.atMs=atMs;this.device=device;
            this.realFps=NativeLsfgStats.realFps;
            this.generatedFps=NativeLsfgStats.genFps;
            this.postedFps=NativeLsfgStats.postFps;
            this.latencyMs=NativeLsfgStats.latencyMs;
            this.queueMs=NativeLsfgStats.queueMs;
            this.copyMs=NativeLsfgStats.copyMs;
            this.presentMs=NativeLsfgStats.presentMs;
            this.waitMs=NativeLsfgStats.waitMs;
            this.blitMs=NativeLsfgStats.blitMs;
            this.wallMs=NativeLsfgStats.wallMs;
            this.postP50Ms=NativeLsfgStats.postP50Ms;
            this.postP95Ms=NativeLsfgStats.postP95Ms;
            this.postP99Ms=NativeLsfgStats.postP99Ms;
            this.postJankPct=NativeLsfgStats.postJankPercent;
            this.inputJitterP95=NativeLsfgStats.smoothInputJitterP95;
            this.thermalStatus=NativeLsfgStats.thermalStatus;
            this.duplicateDrops=NativeLsfgStats.duplicateCaptureDrops;
            this.profileValid=NativeLsfgStats.hasProfile;
        }
    }
    public static synchronized void telemetry(DeviceTelemetry.Sample sample) { deviceSample=sample; }
    public static synchronized Snapshot snapshot() { return new Snapshot(lastMs,deviceSample); }
    private static void retainSample(long atMs) {
        timeline[timelineHead]=new Snapshot(atMs,deviceSample);
        timelineHead=(timelineHead+1)%timeline.length;
        if(timelineCount<timeline.length)timelineCount++;
    }
    private static String csvNumber(double d) {
        return d<0?"NA":String.format(Locale.ROOT,"%.2f",d);
    }
    private static String exportTimeline() {
        StringBuilder csv=new StringBuilder("\nPERFORMANCE_TIMELINE_CSV (650ms, rolling ~4min; native POST != actual display)\n");
        csv.append("elapsed_ms,real_fps,fg_fps,posted_fps,app_cpu_one_core_pct,system_cpu_pct,gpu_busy_pct,app_pss_mb,graphics_mb,swap_mb,java_heap_mb,native_heap_mb,ram_available_mb,ram_total_mb,low_ram,copy_ms,fg_ms,wait_ms,blit_ms,wall_ms,queue_ms,latency_ms,post_p95_ms,post_p99_ms,jank_pct,input_jitter_ms,thermal\n");
        for(int i=0;i<timelineCount;i++) {
            Snapshot x=timeline[(timelineHead-timelineCount+i+timeline.length)%timeline.length];
            if(x==null)continue;
            DeviceTelemetry.Sample d=x.device;
            csv.append(x.atMs-start).append(',').append(csvNumber(x.realFps)).append(',')
               .append(csvNumber(x.generatedFps)).append(',').append(csvNumber(x.postedFps)).append(',')
               .append(csvNumber(d==null?-1:d.appCpuOneCorePct)).append(',')
               .append(csvNumber(d==null?-1:d.systemCpuPct)).append(',')
               .append(csvNumber(d==null?-1:d.gpuBusyPct)).append(',')
               .append(d==null?-1:d.appPssMb).append(',')
               .append(d==null?-1:d.graphicsMb).append(',').append(d==null?-1:d.swapMb).append(',')
               .append(d==null?-1:d.javaHeapMb).append(',').append(d==null?-1:d.nativeHeapMb).append(',')
               .append(d==null?-1:d.availableRamMb).append(',')
               .append(d==null?-1:d.totalRamMb).append(',').append(d!=null&&d.lowMemory?1:0).append(',')
               .append(csvNumber(x.copyMs)).append(',').append(csvNumber(x.presentMs)).append(',')
               .append(csvNumber(x.waitMs)).append(',').append(csvNumber(x.blitMs)).append(',')
               .append(csvNumber(x.wallMs)).append(',').append(csvNumber(x.queueMs)).append(',')
               .append(csvNumber(x.latencyMs)).append(',').append(csvNumber(x.postP95Ms)).append(',')
               .append(csvNumber(x.postP99Ms)).append(',').append(csvNumber(x.postJankPct)).append(',')
               .append(csvNumber(x.inputJitterP95)).append(',').append(x.thermalStatus).append('\n');
        }
        return csv.toString();
    }

    private NativeLsfgStats() {}
    public static synchronized void reset(int width, int height) {
        log.setLength(0); w=width;h=height;start=SystemClock.elapsedRealtime();
        callbacks=forwarded=generated=posted=unique=lastMs=0;
        capturedFps=genFps=postFps=realFps=latencyMs=queueMs=0;
        error="";initRc=999;state=hu()?"App-only capture indítása":"Starting app-only capture";
        mode="";hasProfile=false;copyMs=presentMs=waitMs=blitMs=wallMs=0;
        postP50Ms=postP95Ms=postP99Ms=postJankPercent=0;postIntervals=0;thermalStatus=-1;
        inputFps = rawInputJitterP95 = smoothInputJitterP95 = 0;
        duplicateCaptureDrops = cadenceRebases = unavailableSignatures = 0;
        lastDetailedPollMs = 0;
        deviceSample=null; timelineCount=timelineHead=0;
        Arrays.fill(timeline,null);
        note("MotionStride Native LSFG 1.9.19 Performance Monitor; " + width + "x" + height);
    }
    public static synchronized void setMode(String s) { mode=s;note("Profil: "+s); }
    public static final class LoadSnapshot {
        public final double queueMs, wallMs, postedFps;
        LoadSnapshot(double queueMs, double wallMs, double postedFps) {
            this.queueMs = queueMs; this.wallMs = wallMs; this.postedFps = postedFps;
        }
    }
    public static synchronized LoadSnapshot loadSnapshot() {
        return new LoadSnapshot(queueMs, hasProfile ? wallMs : 0.0, postFps);
    }
    public static synchronized void note(String s) {
        if (log.length()>24000) log.delete(0,6000);
        log.append(SystemClock.elapsedRealtime()).append(" | ").append(s).append('\n');
    }
    public static synchronized void status(String s) {state=s;note(s);}
    public static synchronized void error(String s) {error=s;state=hu()?"NATÍV LSFG HIBA":"NATIVE LSFG ERROR";note((hu()?"HIBA: ":"ERROR: ")+s);}
    public static synchronized void dims(int width,int height) {w=width;h=height;note("Capture resized "+w+"x"+h);}
    public static synchronized void initResult(int code) {initRc=code;note("native.initContext rc="+code);}
    public static synchronized void frame(boolean pushed) { callbacks++;if (pushed) forwarded++; }
    public static synchronized void inputCadence(double fps, double rawP95,
            double smoothedP95, long duplicates, long rebases, long unavailable) {
        inputFps = fps;
        rawInputJitterP95 = rawP95;
        smoothInputJitterP95 = smoothedP95;
        duplicateCaptureDrops = duplicates;
        cadenceRebases = rebases;
        unavailableSignatures = unavailable;
    }
    public static synchronized void setThermalStatus(int status) {
        if (thermalStatus != status) {
            thermalStatus=status;
            note("THERMAL_STATUS=" + status + " (0=none, 1=light, 2=moderate, 3=severe, 4=critical)");
        }
    }
    /** The native counters restart from 0 whenever a Vulkan context is recreated. */
    public static synchronized void resetNativeRates() {
        generated = posted = unique = lastMs = 0;
        genFps = postFps = realFps = latencyMs = queueMs = 0;
        hasProfile=false;copyMs=presentMs=waitMs=blitMs=wallMs=0;
        postP50Ms=postP95Ms=postP99Ms=postJankPercent=0;postIntervals=0;
        lastDetailedPollMs = 0;
        note("Native rates reset following context creation / rotation");
    }
    public static synchronized void poll(NativeBridge b) {
        if (b == null || initRc!=0) return;
        long now=SystemClock.elapsedRealtime();
        if (lastMs==0) {lastMs=now;return;}
        long delta=now-lastMs;
        if (delta<400) return;
        long g=b.getGeneratedFrameCount(),p=b.getPostedFrameCount(),u=b.getUniqueCaptureCount();
        genFps=(g-generated)*1000.0/delta;postFps=(p-posted)*1000.0/delta;
        realFps=(u-unique)*1000.0/delta;
        long since=now-start;
        capturedFps=since>0 ? forwarded*1000.0/since : 0;
        latencyMs=b.getAverageLatencyMs();queueMs=b.getAverageQueueMs();
        if (lastDetailedPollMs == 0 || now - lastDetailedPollMs >= 3000L) {
            lastDetailedPollMs = now;
        // JNI function is present in the existing .so; each value is summed
        // over the latest completed 60-input-frame processing window.
        if (b.getProfileWindowNs(profile)==6 && profile[5]>0) {
            double scale = 1e-6 / profile[5];
            copyMs = profile[0]*scale;
            presentMs = profile[1]*scale;
            waitMs = profile[2]*scale;
            blitMs = profile[3]*scale;
            wallMs = profile[4]*scale;
            hasProfile=true;
        }
        // Native ring contains intervals between POST calls, not SF presentation
        // fences. The P95 and jank figures reveal bursts even when FPS looks good.
        try {
            int n = b.getRecentPostIntervalsNs(recentIntervalsNs);
            if (n > 0 && n <= recentIntervalsNs.length) {
                int usable = 0, longFrames = 0;
                for (int i = 0; i < n; i++) {
                    double value = recentIntervalsNs[i] / 1_000_000.0;
                    if (value >= 0.1 && value <= 250.0) {
                        postIntervalScratchMs[usable++] = value;
                        if (value > 16.7) longFrames++;
                    }
                }
                if (usable > 0) {
                    Arrays.sort(postIntervalScratchMs, 0, usable);
                    postIntervals = usable;
                    postP50Ms = postIntervalScratchMs[(int)Math.ceil(usable * 0.50) - 1];
                    postP95Ms = postIntervalScratchMs[(int)Math.ceil(usable * 0.95) - 1];
                    postP99Ms = postIntervalScratchMs[(int)Math.ceil(usable * 0.99) - 1];
                    postJankPercent = 100.0 * longFrames / usable;
                }
            }
        } catch (Throwable t) { note("Post-interval profile not available: " + t); }
        } // End low-frequency detailed profiling; native frame path unchanged.
        generated=g; posted=p; unique=u; lastMs=now;
        retainSample(now);
    }
    public static synchronized String hud() {
        return String.format(Locale.ROOT,
            "LSFG ×2 • %s\nCapture: %.1f avg\nReal*: %.1f FPS\nGenerated: %.1f FPS\nPosted: %.1f FPS\n" +
            "Latency: %.1f ms • Queue: %.1f ms\nCopy: %.1f • FG: %.1f • Wait: %.1f\n" +
            "Blit: %.1f • Wall: %.1f ms\nPOST P50/P95: %.1f/%.1fms • >16.7ms: %.0f%%\n" +
            "Input jitter P95: %.2f → %.2f ms\nThermal status: %d",
            mode,capturedFps,realFps,genFps,postFps,latencyMs,queueMs,
            copyMs,presentMs,waitMs,blitMs,wallMs,
            postP50Ms,postP95Ms,postJankPercent,
            rawInputJitterP95,smoothInputJitterP95,thermalStatus);
    }
    public static synchronized String summary() {
        String head=hu()
            ? "%s%s\nMód: %s\nFeldolgozási felbontás: %dx%d\nNative rc: %d\nCallback: %d | Native forwarded: %d\nValódi (becsült): %.1f FPS (%d)\nLSFG generált: %.1f FPS (%d)\nKimeneten posztolt: %.1f FPS (%d)\nKésleltetés: %.1f ms • Queue: %.1f ms\n"
            : "%s%s\nMode: %s\nProcessing resolution: %dx%d\nNative rc: %d\nCallbacks: %d | Native forwarded: %d\nReal (estimated): %.1f FPS (%d)\nLSFG generated: %.1f FPS (%d)\nPosted to output: %.1f FPS (%d)\nLatency: %.1f ms • Queue: %.1f ms\n";
        return String.format(Locale.ROOT, head+
            "NATIVE PROFILE (ms/input): copy=%.2f present=%.2f waitIdle=%.2f blit=%.2f wall=%.2f valid=%s\n" +
            "POST_INTERVALS (native post, NOT actual display): n=%d P50=%.2fms P95=%.2fms P99=%.2fms >16.7ms=%.1f%%\n" +
            "INPUT_CADENCE: estimated=%.1fFPS rawJitterP95=%.2fms smoothedJitterP95=%.2fms dupDrops=%d rebases=%d unavailable=%d\nThermal status: %d",
            state,error.isEmpty()?"":"\n"+error,mode,w,h,initRc,callbacks,forwarded,
            realFps,unique,genFps,generated,postFps,posted,latencyMs,queueMs,
            copyMs,presentMs,waitMs,blitMs,wallMs,hasProfile,
            postIntervals,postP50Ms,postP95Ms,postP99Ms,postJankPercent,
            inputFps,rawInputJitterP95,smoothInputJitterP95,duplicateCaptureDrops,cadenceRebases,unavailableSignatures,
            thermalStatus) + telemetrySummary();
    }
    private static String telemetrySummary() {
        DeviceTelemetry.Sample d=deviceSample;
        if(d==null)return "\nPERF_MONITOR: collecting CPU and memory...";
        return String.format(Locale.ROOT,
            "\nPERF_MONITOR: cpu_app_one_core=%.1f%% cpu_system=%s gpu_busy=%s gpu_source=%s cores=%d app_pss=%dMB graphics=%dMB swap=%dMB java_heap=%dMB native_heap=%dMB ram_available=%dMB ram_total=%dMB low_ram=%s",
            d.appCpuOneCorePct,csvNumber(d.systemCpuPct),csvNumber(d.gpuBusyPct),
            d.gpuSource,d.cores,d.appPssMb,d.graphicsMb,d.swapMb,d.javaHeapMb,d.nativeHeapMb,
            d.availableRamMb,d.totalRamMb,d.lowMemory);
    }
    public static String exportCrash(Context context) {
        StringBuilder out = new StringBuilder("NATIVE LSFG CRASH + LOG (app private storage)\n");
        for (String filename : new String[]{"lsfg_last_crash.txt", "lsfg_native_trace.txt"}) {
            File file = new File(context.getFilesDir(), filename);
            out.append("\n==== ").append(filename).append(" ====\n");
            if (!file.isFile()) { out.append(hu()?"Még nincs ilyen fájl.\n":"No such file yet.\n"); continue; }
            try {
                byte[] bytes = Files.readAllBytes(file.toPath());
                int start = Math.max(0, bytes.length - 24000);
                out.append(new String(bytes, start, bytes.length - start, StandardCharsets.UTF_8));
            } catch (Throwable t) { out.append(hu()?"Nem olvasható: ":"Cannot read: ").append(t); }
        }
        return out.toString();
    }
    public static synchronized String export() {
        return "MotionStride 1.9.19 Native LSFG\nAndroid " + Build.VERSION.RELEASE + " SDK "+Build.VERSION.SDK_INT+
            "\nDevice "+Build.MANUFACTURER+" "+Build.MODEL+"\n"+summary()+"\n"+log+exportTimeline();
    }
}
