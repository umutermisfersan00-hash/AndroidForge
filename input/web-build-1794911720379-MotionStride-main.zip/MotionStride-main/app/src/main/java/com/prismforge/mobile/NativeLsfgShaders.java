package com.prismforge.mobile;

import android.content.Context;
import android.net.Uri;
import com.frameflow.s25.session.NativeBridge;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Locale;

/** User-owned Lossless.dll -> native DXBC translation -> local SPIR-V cache.
 * The DLL copy is deleted even if extraction fails. Shaders are never bundled.
 */
public final class NativeLsfgShaders {
    private NativeLsfgShaders() { }
    public static File cache(Context ctx) { return new File(ctx.getFilesDir(), "spirv"); }
    public static boolean available(Context ctx) {
        File f = new File(cache(ctx), "255.spv");
        return f.isFile() && f.length() > 20 &&
            ctx.getSharedPreferences("prismforge_lsfg", 0).getBoolean("verified", false);
    }
    private static void wipe(File dir) {
        File[] files = dir.listFiles();
        if (files != null) for (File f: files) {
            if (f.isDirectory()) wipe(f);
            if (!f.delete()) throw new IllegalStateException("Cache cleanup failed: " + f);
        }
    }
    public static String importDll(Context ctx, Uri uri) throws Exception {
        File local = new File(ctx.getFilesDir(), "lossless_import.tmp");
        File shaders = cache(ctx);
        if (!shaders.exists() && !shaders.mkdirs()) throw new Exception("Cannot create shader cache");
        ctx.getSharedPreferences("prismforge_lsfg",0).edit().putBoolean("verified",false).apply();
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream in = ctx.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(local)) {
                if (in == null) throw new Exception("Could not open Lossless.dll");
                byte[] block = new byte[64*1024]; int n;
                while ((n = in.read(block)) != -1) {
                    digest.update(block,0,n); out.write(block,0,n);
                }
            }
            StringBuilder hex = new StringBuilder();
            for (byte b: digest.digest()) hex.append(String.format(Locale.ROOT,"%02x",b & 255));
            wipe(shaders);
            NativeBridge bridge = new NativeBridge();
            int rc = bridge.extractShaders(local.getAbsolutePath(), hex.toString(), shaders.getAbsolutePath());
            if (rc != 0) throw new Exception("Native DXBC extraction failed rc=" + rc);
            // Note: Native Vulkan validation may reject translated SPIR-V on some drivers.
            int probe = bridge.probeShaders(shaders.getAbsolutePath());
            if (probe != 0) throw new Exception("Vulkan shader probe failed rc=" + probe);
            if (!new File(shaders,"255.spv").isFile()) throw new Exception("LSFG shader 255.spv missing");
            ctx.getSharedPreferences("prismforge_lsfg",0).edit()
                .putBoolean("verified",true).putString("sha256",hex.toString()).apply();
            return "LSFG SHADERS READY · " + bridge.nativeVersion() + "\nSHA256: " + hex;
        } finally {
            if (local.exists() && !local.delete()) local.deleteOnExit();
        }
    }
}
