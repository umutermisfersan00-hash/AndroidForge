#pragma once
#include <cstdint>

namespace lsfg_android {
// In FIFO WSI the display's presentation queue is the pacing source.
// Do not serially sleep once per post at the *same* refresh rate. Preserve
// a user-requested lower cap, or fall back to software pacing for CPU output.
// Integer arithmetic avoids floating point precision issues for 120 Hz.
inline bool shouldSoftwarePaceOutput(int capHz, int64_t vsyncPeriodNs,
                                      bool fifoSwapchainActive) {
    if (capHz <= 0) return false;
    if (!fifoSwapchainActive || vsyncPeriodNs <= 0) return true;
    // Half-percent tolerance absorbs truncation of periodNs (120 Hz =
    // 8,333,333 ns) and display reporting drift without disabling a
    // meaningful user cap such as 90 FPS on a 120 Hz panel.
    return static_cast<int64_t>(capHz) * vsyncPeriodNs < 995'000'000LL;
}
} // namespace lsfg_android
