plugins {
    alias(libs.plugins.android.application)
}

// NATIVE BUILD ROUTES
// prebuilt (fallback): Code on the Go / Android: uses known-good LSFG 0.1.2 .so,
//                     NEVER launches the broken Android-host CMake executable.
// cmake:              Android Studio / CI on Linux: rebuilds the modified native
//                     Vulkan engine from app/src/main/cpp and lsfg-vk-android.
//                    Requires functioning host CMake and NDK r27.
// Fail fast on accidental typos; never pretend the optimized native code built.
val prismforgeNativeMode = providers.gradleProperty("prismforgeNativeMode")
    .orNull?.trim()?.lowercase() ?: "prebuilt"
require(prismforgeNativeMode in setOf("prebuilt", "cmake")) {
    "Invalid prismforgeNativeMode=$prismforgeNativeMode (expected prebuilt or cmake)"
}
val rebuildNative = prismforgeNativeMode == "cmake"
// The CMake build contains the guarded direct-capture implementation and its
// copied-input fallback.  Keep it enabled by default for native builds so the
// expensive full-frame capture copy is not silently used for the whole
// session.  It can still be disabled explicitly for A/B diagnostics with
// -PprismforgeDirectAhb=false.
val directAhbExperiment = providers.gradleProperty("prismforgeDirectAhb")
    .orNull?.trim()?.equals("true", ignoreCase = true) ?: rebuildNative
require(!directAhbExperiment || rebuildNative) {
    "prismforgeDirectAhb=true requires prismforgeNativeMode=cmake (new JNI Image-lease ABI)"
}

android {
    namespace = "com.prismforge.mobile"
    buildFeatures { buildConfig = true }
    compileSdk = 36
    if (rebuildNative) ndkVersion = "27.0.12077973"

    // When CMake builds its .so, there must be NO stale prebuilt library with
    // the same name in the APK. When prebuilt, no CMake task is configured.
    sourceSets.getByName("main").jniLibs.setSrcDirs(
        if (rebuildNative) emptyList<String>() else listOf("nativePrebuilt")
    )
    if (rebuildNative) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }
    defaultConfig {
        applicationId = "com.prismforge.mobile"
        // App-window MediaProjection is the oldest capture mode MotionStride
        // can use without recording the whole display.
        minSdk = 34
        targetSdk = 36
        versionCode = 39
        versionName = "1.9.19-aligned-dashboard"
        buildConfigField("boolean", "DIRECT_AHB_EXPERIMENT", directAhbExperiment.toString())
        ndk { abiFilters += listOf("arm64-v8a") }
        if (rebuildNative) {
            externalNativeBuild {
                cmake { arguments += listOf("-DANDROID_STL=c++_shared") }
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint { checkReleaseBuilds = false }
    buildTypes {
        release { isMinifyEnabled = false }
    }
}

// Explicit build provenance: this line is printed during Gradle configuration.
logger.lifecycle("PrismForge DIRECT AHB opt-in: $directAhbExperiment")
logger.lifecycle("PrismForge native mode: $prismforgeNativeMode" +
    if (rebuildNative) " (NEW Vulkan .so compiled by CMake)"
    else " (KNOWN-GOOD old .so; fence optimization NOT ACTIVE)")

configurations.configureEach {
    resolutionStrategy {
        force("org.jetbrains.kotlin:kotlin-stdlib:2.3.21")
        force("org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.3.21")
        force("org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.3.21")
        force("androidx.core:core-ktx:1.8.0")
        force("androidx.collection:collection:1.4.2")
        force("androidx.annotation:annotation:1.8.1")
        force("androidx.lifecycle:lifecycle-runtime-ktx:2.3.1")
        force("androidx.collection:collection-ktx:1.4.2")
    }
}

dependencies { }
