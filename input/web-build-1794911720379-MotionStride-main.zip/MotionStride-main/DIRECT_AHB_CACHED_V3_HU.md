# PrismForge Direct AHB Cached v3 — fejlesztői jegyzet

Ez a forráskód a feltöltött `PrismForgeAndroid (3).zip` **codex/async-pipeline** ágából és a korábbi `codex/direct-capture-ahb-leased-v2` fejlesztésből lett összefésülve. A projektben a Git-előzmények megmaradnak. A korábbi működő `prebuilt` binárisok érintetlenek.

## Implementált

- **Két külön cache**: a session/present Vulkan-eszköz `AhbImage` importja és az LSFG 3.1/3.1P másik Vulkan-eszközének `Core::Image` importja egyaránt AHB-rendszerazonosítóhoz kötött.
- A rendszerazonosítót az Android API 31+ `AHardwareBuffer_getId` adja. Ha a függvény nem elérhető, a cache kimarad; **nyers pointerrel nem azonosítjuk a buffert**.
- Mindkét cache legfeljebb 12 importot tart meg (LRU). A különböző méretű/formátumú/usage-ű képek újra importálódnak. A cache-retenció nem akadályozza az aktív GPU-parancsok által még használt image/view élettartamát.
- A `Core::Image` Vulkan objektumait felszabadításkor **view → image → memory** sorrendben bontjuk le.
- A korábbi JNI `ImageReader`-lease kezelés és a két Vulkan-eszköz szinkronizációja megmaradt. Az új közvetlen út a capture-`SyncFence`-et **legfeljebb 75 ms-ig megvárja** a worker szálon. Hiba/időtúllépés esetén kikapcsolja a Direct AHB-t, és a másolásos módra vált.
- A korábban beépített aszinkron WSI, a 8 elemes descriptor-ring és a terhelés alatti friss capture-előnyben részesítése megmaradt.
- Natív azonosító: `lsfg-android 0.1.4-direct-ahb-import-cache`.

## Alapbeállítás — ezúttal tényleges kísérleti build

A `gradle.properties` tartalmazza:

```properties
prismforgeNativeMode=cmake
prismforgeDirectAhb=true
```

**Android Studio + NDK r27 szükséges.** A Code on the Go hibás CMake-jével ez a natív forrás nem fordul. A `prebuilt` módra állítás önmagában nem teszi aktívvá az új optimalizációt.

## Mit ellenőrizz az S25-ön?

Logcat szűrés: `lsfg-ahb-cache`, `lsfg-vk-loop`, `DIRECT_AHB`, `SESSION_AHB_CACHE`.

- `Native lib: lsfg-android 0.1.4-direct-ahb-import-cache` — az új motor **valóban fut**.
- `DIRECT_AHB_CONFIG: EXPERIMENTAL_ON` — beállítás engedélyezve.
- `direct capture-AHB framegen input active` — a közvetlen út belépett.
- `DIRECT_AHB_CACHE hit=... miss=...` — az LSFG-eszköz import-cache-e használatban.
- `SESSION_AHB_CACHE hit=... miss=...` — a kimeneti/session Vulkan-eszköz import-cache-e használatban.
- `DIRECT_AHB_PRODUCER_FENCE` vagy `direct capture-AHB path disabled` — visszaváltás másolásra.

Ellenőrizd hidegen és melegen a képhibákat, `copy/waitIdle/blit/wall`, queue, FG FPS, post P95/P99 és thermal értékeket. Az import-cache találata **önmagában nem jelent** folyamatos 120 valóban megjelenített FPS-t.

## Biztonságos visszaállás

A `gradle.properties` fájlban:

```properties
prismforgeNativeMode=prebuilt
prismforgeDirectAhb=false
```

Ez a projektben megtartott, korábbi fordított `liblsfg-android.so` könyvtárat használja. A Git-ág külön mentési pont; a régiek nem íródtak felül.

## Validációs korlát

A források Git merge-je konfliktusmentes állapotban van, a cache adatstruktúrája hostos szintetikus C++ teszten átment, a forrás-invariánsokat ellenőriztük. A teljes ARM64 Android NDK-fordítás és a tényleges Adreno Vulkan-futtatás **itt nem végezhető el**, ezért a cache, az ownership és a szinkronizáció telefonos stabilitása **még nincs igazolva**. A felhasználó által jelentett korábbi képszétesésnek lehet az importálási túlterhelésen kívül más oka is (queue-family ownership, descriptor verseny, frame pacing).

A mostani változtatás **nem** szünteti meg a kimeneti `vkCmdBlitImage` másolást; annak eltávolítása külön, nagyobb WSI/LSFG-output architektúraátalakítás.
