# PrismForge 1.8.1 — óvatos CPU-terheléscsökkentés

A stabil 1.8.0 verzióból készült. **A natív Vulkan LSFG könyvtár, a shaderek, az FG-profilok, a rögzítés módja, a kimeneti felbontás, a képkockasor és az időbélyeg-korrekció szabályai nem változtak.**

## Módosítások

1. A 8×8 RGBA képaláírás 64 képpontjának pozícióját az ImageReader adott méretéhez és stride-jaihoz gyorsítótárazzuk. Ezt az eddigi algoritmust változatlan hash-kimenettel futtatjuk. A gyorsítótár minden képrögzítési átméretezéskor újra létrejön.
2. A képkockaütemezés 96 elemű jitter-percentilis számításához újrahasznosítjuk a munkatömböt. A numerikus eredmény változatlan.
3. A natív FPS-, késleltetés- és queue-számlálók továbbra is kb. 650 ms-onként frissülnek, de az opcionális, részletes Vulkan-profil és post-intervallumok lekérdezése kb. 3 másodpercenként történik. Emiatt a **részletes diagnosztika lassabban frissül**.
4. Az Android hőállapotát kb. 4 másodpercenként kérdezzük le, nem minden FPS-méréskor.
5. A post-intervallumok rendezése közben nem hozunk létre új 96 elemű `double[]` tömböt minden alkalommal.

## Biztonsági határok

- `liblsfg-android.so` és `libc++_shared.so` változatlan.
- `NativeBridge.java` és az LSFG shaderimport változatlan.
- A 120 FPS-cél, a 0,45 flow-skála, az optikai flow algoritmusa, a capture timestamps és a `waitIdle` működése változatlan.
- A projekt teljes mappa; a Code on the Go-ban az előzőhöz hasonlóan fordítható.

## Ellenőrzés (fejlesztői környezet)

- 1400 szintetikus RGBA képen a régi és az új képaláírás egyenlő.
- 4000 szintetikus képkockán a CaptureCadence eredménye és a jitter P95 változatlan.
- 10 Java-forrás szintaktikailag ellenőrizve; a statisztikai osztály külön Java típustesztje sikeres.
- A natív .so könyvtárak SHA256-összehasonlítása azonos.

A teljes Android-buildet és a telefonos FPS/hőmérséklet-tesztet ebben a környezetben nem tudtuk végrehajtani. A változtatások a Java oldali járulékos munkát csökkentik, nem az LSFG fő GPU-költségét. A telefon hő-limitje miatt további teljesítményjavulás nem garantált.
