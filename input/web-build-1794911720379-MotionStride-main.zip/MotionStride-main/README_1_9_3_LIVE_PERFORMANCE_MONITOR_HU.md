# PrismForge 1.9.3 – Élő teljesítménydiagnosztika

**Alap:** 1.9.2 `prebuilt` buildút, az 1.9-es natív LSFG motor változatlan. Ez diagnosztikai UI-módosítás, NEM új Vulkan-gyorsítás.

## Mi változott?

A teljes képernyős, érintést továbbra is átengedő (`FLAG_NOT_TOUCHABLE`) accessibility overlay jobb felső sarkában egy 370dp széles, sötét monitorpanel jelenik meg. Egyetlen Canvas View rajzolja a panelt; nem kér folyamatos 120 Hz-es frissítést.

- **REAL** (türkiz) és **GENERÁLT** (sárga): ~58 mp-es gördülő FPS-grafikon, azonos 0–75 FPS skálán, 60-as célvonallal.
- **POST**: a natív oldalon posztolt FPS, NEM tényleges Android SurfaceFlinger-kijelző FPS.
- **CPU app**: a PrismForge folyamat teljes CPU-idejének aránya *egy logikai CPU-maghoz viszonyítva*. Többszálú appnál 100% fölé mehet.
- **CPU rendszer**: csak akkor mutat százalékot, ha az Android engedi a `/proc/stat` olvasását; ellenkező esetben N/A.
- **GPU busy**: csak ha a Qualcomm KGSL `gpubusy` számláló hozzáférhető, különben N/A. A másolási és várakozási idők NEM GPU-kihasználtsági százalékok.
- **GFX RAM**: `Debug.MemoryInfo` `summary.graphics`, ha az OS ad adatot; nem garantáltan a teljes GPU VRAM.
- **App PSS**: a PrismForge teljes arányos fizikai memóriahasználata (MB).
- **RAM haszn.**: a teljes elérhető RAM és `availMem` alapján számolt, közelítő rendszerkihasználtság.
- **HŐ**: Android PowerManager thermal státusz (0..6).
- **COPY / FG / WAIT / BLIT / WALL / QUEUE / LAT**: a natív motor profilozott idők ms-ban. A `wall` ütemezési várakozást is tartalmazhat. Ezek részletes mintái ~3 mp-enként frissülnek.
- **POST P95 / P99** és 16,7 ms-nál hosszabb posztolási szünetek aránya; ez az Android kijelző valós megjelenítési idejétől eltérhet.
- **INPUT JITTER**: az 1.8-as input időzítés smoothed P95 mérése.

A CPU-, memória- és opcionális GPU-számlálók mintavétele **külön, alacsony prioritású HandlerThreaden** történik ~1,9 másodpercenként. A HUD többnyire ~650 ms-onként kap új natív FPS-adatot. A frame generation algoritmusa, a bemeneti képkockaszűrés, a 120Hz kimeneti cél, a 0.45 flow-skála, a felbontás és az input/overlay lánc változatlan.

## Időbeli napló

A főképernyőn a **Teljes LSFG-napló másolása** gombbal a korábbi napló után új `PERFORMANCE_TIMELINE_CSV` szekció kerül a vágólapra. A szakasz legfeljebb **360 legutóbbi (~4 percnyi) mintát** tartalmaz. A korábbi `NATIVE PROFILE`, `POST_INTERVALS`, `INPUT_CADENCE`, `CAPACITY_LIMIT` naplóformák megmaradtak.

CSV-oszlopok: eltelt idő, valódi FPS, generált FPS, natív posztolt FPS, app/system CPU, GPU busy (ha olvasható), PSS/GFX/swap/Java/native memória, szabad és teljes RAM, low-RAM jelzés, copy/FG/wait/blit/wall/queue/latency, P95/P99/jank, input jitter és hőállapot.

Az `NA` azt jelenti, hogy a mért adat nem hozzáférhető, **nem azt, hogy nulla**. A `summary.graphics` PSS-ből származó részösszeg; nem tökéletes VRAM-teljesítménymérő.

## Fordítás – Code on the Go

A `gradle.properties` fájlban **`prismforgeNativeMode=prebuilt`** maradt. Ez elkerüli a telefonon hibás CMake-et. A korábban módosított C++ források a ZIP-ben megmaradtak későbbi külső natív fordításhoz, de **nem épülnek be az előre fordított `.so`-ba**.

1. Importálás után `:app:assembleDebug`.
2. Játékindítás és NATÍV GYORSÍTOTT mód kiválasztása.
3. Indulás után ellenőrizd, hogy két színes FPS-görbe és a CPU/PSS/COPY/WAIT/QUEUE mezők látszanak-e.
4. A bezuhanás alatt jegyezd fel, mi nőtt: `QUEUE`, `WAIT`, `COPY`, `WALL`, P99, app CPU, PSS/GFX vagy RAM kihasználtság. Ha ezek nem változnak, a posztolás/display útvonal is gyanús.
5. Kilépés után másold ki a teljes LSFG-naplót és küldd el – a CSV a végén lesz.

**A fordítást és az S25-ös futást ebben a környezetben nem lehetett tényleges Android eszközön tesztelni.** A Java-szintaxist és a monitor mérő/rajzoló osztályainak típusellenőrzését ellenőriztük, a ZIP és a natív előre fordított `.so` sértetlenségét szintén.
