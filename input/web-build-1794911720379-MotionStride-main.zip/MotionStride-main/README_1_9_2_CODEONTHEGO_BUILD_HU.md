# PrismForge 1.9.2 – Code on the Go CMake futtatási hiba megkerülése

## Mit jelent a hibád?

A `cmake[1]: syntax error: unexpected ')'` hiba **már a CMake futtatható
állományának indításakor** jelentkezik. A C++ forrás fordítása el sem kezdődik.
A projekt CMakeLists.txt fájljának átszerkesztése nem javítja ezt meg.
Lehetséges ok a hibás / ARM64-es Androiddal inkompatibilis telepített
CMake-bináris. Ezt a készüléken külön ellenőrizni kell.

## 1. Azonnali Code on the Go build – működő eredeti motorral

A projekt alapértelmezett `gradle.properties` sora:

    prismforgeNativeMode=prebuilt

A `:app:assembleDebug` így NEM hívja a hibás CMake-et; az eredeti,
1.9-es `app/nativePrebuilt/arm64-v8a/liblsfg-android.so` motor kerül az APK-ba.
Ez a működő frame gen motor, de **A FENCE OPTIMALIZÁCIÓ MÉG NEM AKTÍV**.
A natív logban: `lsfg-android 0.1.2`.

## 2. Javított natív .so fordítása GitHub Actions-szel (PC nélkül)

A forráskód `app/src/main/cpp`, `lsfg-vk-android` és
`.github/workflows/build-optimized-native.yml` helyen található.

1. A `PrismForgeAndroid` mappa **tartalmát** tedd egy GitHub-repo gyökerébe,
   a rejtett `.github` mappával együtt.
2. A repo **Actions** lapján válaszd a
   **Build PrismForge optimized ARM64 Vulkan** munkafolyamatot, majd
   **Run workflow**. A Linux x86_64-es futtató telepíti a CMake 3.22.1-et és
   az NDK 27.0.12077973-at, és `-PprismforgeNativeMode=cmake`-kel fordít.
3. Sikeres futásnál töltsd le a `PrismForge-1.9.2-native-fence-experimental`
   artifactot, csomagold ki, és a `native/` mappa **mindkét** fájlját:
   `liblsfg-android.so` és `libc++_shared.so` másold be a telefonon lévő
   projekt `app/nativePrebuilt/arm64-v8a/` mappájába.
4. A telefonon maradjon `prismforgeNativeMode=prebuilt`. Futtass **Clean**,
   majd `:app:assembleDebug` buildet. Ez a megoldás a **külsőleg lefordított,
   módosított .so-t** csomagolja a saját, Code on the Go által aláírt APK-ba.
5. A natív verzió ezután `lsfg-android 0.1.2-fence-experimental`, valamint
   `COPY_SYNC: per-submit fence enabled` naplósor jelezheti az új kód futását.

Megjegyzés: a GitHub Actions natív fordítása e kiadás készítésekor még nem
volt lefuttatva, tehát a munkafolyamat esetleges C++ hibái további javítást
igényelhetnek. **Ne tekintsd az eredeti .so-t optimalizáltnak.**

## 3. CMake a saját számítógépen

Ha Windows / Linux / macOS gépen működő NDK 27 + CMake 3.22.1 áll rendelkezésre,
`gradle.properties`:

    prismforgeNativeMode=cmake

és `:app:assembleDebug`. A natív `.so` az APK-ba kerül. Visszatérés a régi
motorhoz: `prismforgeNativeMode=prebuilt`, majd Clean build.

## 4. Korlátok

- Az új fence továbbra is megvárja a konkrét Vulkan másolási műveletet.
  Ettől még nem lesz a számítás aszinkron az LSFG-motorral.
- A képgenerálás utáni `waitIdle` megmarad. Stabil 120 FPS **nem garantált**.
- A 2.0-s Adaptive Load Guard nincs ebben a kiadásban: nem korlátozzuk új
  szabállyal a bemeneti FPS-t.
- A működő app-only capture, teljes overlay, touch-through, képminőség és
  frame pacing Java-oldali útvonalát nem módosítottuk.
