# PrismForge 1.7.0

Natív LSFG Androidra – Code on the Go projekt.

## Funkciók
- Natív gyorsított (alapértelmezett): a játék eredeti felbontásán dolgozik, flowScale=0.45.
- 720p gyorsított: ugyanez a Vulkan/LSFG konfiguráció és flowScale=0.45, de az alkalmazásrögzítés belső felbontása 1560×720 körüli (2340×1080-as játék esetén).
- A felület csak a natív LSFG indulását/leállítását, a profilokat, jogosultságot, Lossless.dll-importot és a szükséges teljesítménydiagnosztikát tartalmazza.
- Tesztmód alapértelmezetten KI. Tesztmódon belül külön aktiválható időzített leállás: 45 mp / 2 perc / 5 perc / 15 perc.
- Alapértelmezett használatban **nincs 45 másodperces automatikus leállás**. Az értesítésben a **Leállítás** művelet továbbra is elérhető.
- Az alkalmazásválasztó továbbra is csak egy alkalmazás rögzítését engedi, hogy az 100%-os overlay ne kerüljön bele a rögzítésbe.

## Működő lánc
Android 17 alkalmazásmegosztás → ImageReader RGBA → AHardwareBuffer → ARM64 Vulkan LSFG → Accessibility TextureView (100%-os fedés, touch-through).

Az ARM64 liblsfg-android.so és libc++_shared.so, illetve a shaderimport/JNI implementáció változatlan az 1.6.0-hoz képest. A natív szolgáltatásban csak a két profil azonos flow-konfigurációja és a felhasználó által vezérelt leállítás lett módosítva.

## Build
Nyisd meg a PrismForgeAndroid mappát Code on the Go-ban, és futtasd az `:app:assembleDebug` feladatot. A módosítás forrásszinten ellenőrzött; Androidon külön le kell fordítani és próbálni.

## Későbbi terv – útmutató videók (NINCS BEÉPÍTVE)
A beállítások mellett `?` ikonos, felugró súgó rövid, lépésekhez igazított videókkal. A Lossless.dll esetén két fül: **Beszerzés** (telepítés, telepítési mappa, fájl átmásolása telefonra) és **Importálás** (fájl kiválasztása, import, siker jelzése). A videó az egyes lépéseknél megáll, az aktuális lépés kiemelve. A videókat és lejátszót később építjük be.
