#!/usr/bin/env python3
"""Source and deterministic hash-invariant checks; NOT an Android NDK build."""
from pathlib import Path
import random
p=Path(__file__).resolve().parents[1]
render=(p/'app/src/main/cpp/lsfg_render_loop.cpp').read_text()
java=(p/'app/src/main/java/com/prismforge/mobile/NativeLsfgService.java').read_text()
bridge=(p/'app/src/main/cpp/lsfg_jni.cpp').read_text()
api=(p/'app/src/main/cpp/lsfg_render_loop.hpp').read_text()
start=render.index('void pushFrame(AHardwareBuffer *ahb, int64_t timestampNs,')
end=render.index('\nvoid shutdownRenderLoop()',start)
hot=render[start:end]
assert 'std::lock_guard<std::mutex> lock(g.pendingMu)' in hot
assert 'std::lock_guard<std::mutex> lock(g.mu)' not in hot
assert 'g.acceptsInput.load' in hot
assert 'suppliedCaptureHash != 0u' in hot
assert 'displaced.imageLease.reset();' in hot
assert 'g.pendingCv.wait(lock' in render
assert 'std::unique_lock<std::mutex> lock(g.pendingMu)' in render
assert 'g.hasDeferredDirectSources.load' in render
assert 'g.deferredDirectSources.empty()) {' not in render[render.index('void workerThread()'):render.index('const auto frameWorkStartedAt')]
assert 'pushFrameLeasedWithHash' in bridge and 'pushFrameLeasedWithHash' in java
assert 'hashedLeaseSupported' in java and 'pushFrameLeased(hb, img, cadence.timestampNs)' in java
assert 'uint32_t suppliedCaptureHash = 0u' in api
assert 'capture-admission' in bridge
# Java FrameSignature and native captureContentHash use the same luma,
# sentinel and FNV accumulation; exercise both orderings on random images.
random.seed(19415)
for _ in range(2000):
    w,h=random.choice([32,64,120,320,1080]),random.choice([24,40,64,180,240])
    rgba=bytes(random.getrandbits(8) for _ in range(w*h*4))
    def java_hash():
        hash=0x811c9dc5
        for gy in range(8):
            y=min((gy*h)//8,h-1)
            for gx in range(8):
                x=min((gx*w)//8,w-1)
                off=(y*w+x)*4
                r,g,b=rgba[off],rgba[off+1],rgba[off+2]
                lum=(77*r+150*g+29*b)>>10
                hash=((hash^lum)*0x01000193)&0xffffffff
        return hash or 1
    def native_hash():
        hsh=0x811c9dc5
        for yidx in range(8):
            y=min((yidx*h)//8,h-1)
            for xidx in range(8):
                x=min((xidx*w)//8,w-1)
                pos=(y*w+x)*4
                lum=((77*rgba[pos]+150*rgba[pos+1]+29*rgba[pos+2])>>10)
                hsh=((hsh^lum)*0x01000193)&0xffffffff
        return hsh or 1
    assert java_hash()==native_hash()
print('PASS: decoupled capture queue, JNI compatibility, 2000 matching 8x8 hash simulations')
