#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
clang++ -std=c++20 -D__ANDROID__ -I"$HERE/include" \
  -I"$ROOT/lsfg-vk-android/framegen/include" "$HERE/test.cpp" \
  -o "$OUT/test_ahb_cache"
"$OUT/test_ahb_cache"
