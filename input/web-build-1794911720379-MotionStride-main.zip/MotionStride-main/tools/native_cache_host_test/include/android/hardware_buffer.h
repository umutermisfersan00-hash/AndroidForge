#pragma once
#include <stdint.h>
struct AHardwareBuffer { uint64_t id; uint32_t width, height, stride, format; uint64_t usage; int refs; };
struct AHardwareBuffer_Desc { uint32_t width, height, layers, format; uint64_t usage; uint32_t stride, rfu0, rfu1; };
extern "C" void AHardwareBuffer_describe(AHardwareBuffer*, AHardwareBuffer_Desc*);
extern "C" void AHardwareBuffer_acquire(AHardwareBuffer*);
extern "C" void AHardwareBuffer_release(AHardwareBuffer*);
