#pragma once
#include <memory>
#include <cstdint>
using VkFormat = int;
using VkImageUsageFlags = unsigned;
using VkImageAspectFlags = unsigned;
struct VkExtent2D { uint32_t width, height; };
namespace LSFG { namespace Core {
struct Device { };
struct Image {
    std::shared_ptr<int> token;
    Image() = default;
    Image(const Device&, VkExtent2D, VkFormat, VkImageUsageFlags, VkImageAspectFlags, struct AHardwareBuffer*);
};
}}
