#include <cassert>
#include <cstring>
#include <iostream>
#include <memory>
#include <unordered_map>
#include "android/hardware_buffer.h"
#include "core/android_ahb_import_cache.hpp"
int imports=0, destroyed=0;
LSFG::Core::Image::Image(const Device&, VkExtent2D, VkFormat, VkImageUsageFlags, VkImageAspectFlags, AHardwareBuffer*)
: token(new int(++imports), [](int* x){++destroyed;delete x;}) {}
extern "C" void AHardwareBuffer_describe(AHardwareBuffer* b, AHardwareBuffer_Desc* d){
 *d={b->width,b->height,1,b->format,b->usage,b->stride,0,0};
}
extern "C" void AHardwareBuffer_acquire(AHardwareBuffer* b){++b->refs;}
extern "C" void AHardwareBuffer_release(AHardwareBuffer* b){--b->refs;assert(b->refs>=0);}
extern "C" int __android_log_print(int,const char*,const char*,...){return 0;}
extern "C" int mockedGetId(const AHardwareBuffer* b,uint64_t* id){*id=b->id;return 0;}
extern "C" void* dlsym(void*,const char* name){return !strcmp(name,"AHardwareBuffer_getId")?reinterpret_cast<void*>(mockedGetId):nullptr;}
int main(){
 using namespace LSFG::Core;
 Device d;
 AndroidAhbImportCache cache;
 AHardwareBuffer b{4,2340,1080,2340,1,3,0};
 {
   auto first=cache.get(d,&b,{2340,1080},1,7,1);
   assert(imports==1&&b.refs==1);
   auto again=cache.get(d,&b,{2340,1080},1,7,1);
   assert(first.token==again.token&&imports==1);
   b.stride=2352;
   auto replaced=cache.get(d,&b,{2340,1080},1,7,1);
   assert(imports==2&&b.refs==1);
 }
 assert(b.refs==1);
 AHardwareBuffer many[13]{};
 for (int i=0;i<13;++i){
   many[i]={100u+static_cast<uint64_t>(i),2340,1080,2340,1,3,0};
   cache.get(d,&many[i],{2340,1080},1,7,1);
 }
 assert(imports==15);
 cache.clear();
 assert(destroyed==imports);
 for(auto& item:many) assert(item.refs==0);
 assert(b.refs==0);
 std::cout<<"PASS: import reuse, desc invalidation, 12-entry LRU, safe shared-retirement ("<<imports<<" imports)\n";
}
