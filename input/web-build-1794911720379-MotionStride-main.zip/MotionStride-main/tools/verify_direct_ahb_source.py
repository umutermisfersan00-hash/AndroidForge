#!/usr/bin/env python3
"""Lightweight source-configuration invariants, NOT an Android compile/test."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
files = {str(p.relative_to(root)): p.read_text(errors="replace") for p in [
    root/'app/src/main/cpp/lsfg_jni.cpp',
    root/'app/src/main/cpp/lsfg_render_loop.cpp',
    root/'app/src/main/java/com/prismforge/mobile/NativeLsfgService.java',
    root/'app/src/main/java/com/frameflow/s25/session/NativeBridge.java',
    root/'app/build.gradle.kts',
    root/'gradle.properties',
    root/'lsfg-vk-android/framegen/v3.1p_src/context.cpp',
    root/'lsfg-vk-android/framegen/v3.1p_src/shaders/generate.cpp',
]}
blob='\n'.join(files.values())
checks = [
    'prismforgeDirectAhb=true',
    'prismforgeNativeMode=cmake',
    'pushFrameLeased(',
    'makeCapturedImageLease(',
    'g.deferredInputImageLease',
    'g.previousDirectImageLease',
    'retireCompletedDirectSources()',
    'DIRECT_AHB_BACKPRESSURE',
    'direct-ahb-import-cache',
    'previous.handle()!=current.handle()',
    'prior.handle()!=current.handle()',
    'needsCopiedInputBootstrap',
    'AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE',
    'SESSION_AHB_CACHE',
    'DIRECT_AHB_PRODUCER_FENCE',
]
for needle in checks:
    if needle not in blob:
        raise AssertionError(f'missing invariant: {needle}')
print(f'PASS: {len(checks)} source invariants (NOT NDK build or device testing)')
