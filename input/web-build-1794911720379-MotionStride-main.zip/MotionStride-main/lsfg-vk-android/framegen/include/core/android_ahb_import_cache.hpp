#pragma once

// Per-LSFG-context cache of Vulkan imports for ImageReader-owned AHardwareBuffers.
// No pixel copy: the VkImage/VkDeviceMemory/VkImageView objects are reused when
// the same system-wide AHB ID reappears. An AHB native ref is retained while an
// entry remains in the cache; Java Image leases are managed separately by the
// PrismForge capture worker until GPU completion (do not conflate these).
#ifdef __ANDROID__

#include "core/image.hpp"
#include <android/hardware_buffer.h>
#include <android/log.h>
#include <dlfcn.h>
#include <algorithm>
#include <cstdint>
#include <memory>
#include <unordered_map>

namespace LSFG::Core {

class AndroidAhbImportCache {
public:
    static constexpr size_t kMaxCachedBuffers = 12;

    Image get(const Core::Device& device, AHardwareBuffer* buffer,
              VkExtent2D extent, VkFormat format,
              VkImageUsageFlags usage, VkImageAspectFlags aspect) {
        AHardwareBuffer_Desc d{};
        AHardwareBuffer_describe(buffer, &d);

        // AHardwareBuffer_getId is API 31+. Never cache by a bare address:
        // Android can recycle addresses after the source buffer is destroyed.
        using GetIdFn = int (*)(const AHardwareBuffer*, uint64_t*);
        static const GetIdFn getId = reinterpret_cast<GetIdFn>(
            dlsym(RTLD_DEFAULT, "AHardwareBuffer_getId"));
        uint64_t id = 0;
        if (!getId || getId(buffer, &id) != 0 || id == 0) {
            ++uncached_;
            return Image(device, extent, format, usage, aspect, buffer);
        }

        auto it = entries_.find(id);
        if (it != entries_.end()) {
            const Entry& e = it->second;
            if (e.width == d.width && e.height == d.height &&
                e.stride == d.stride && e.format == d.format &&
                e.usage == d.usage && e.vkFormat == format &&
                e.vkUsage == usage && e.aspect == aspect) {
                it->second.lastUsed = ++tick_;
                ++hits_;
                report();
                return e.image; // cheap shared VkImage/VkImageView ownership
            }
            // A descriptor or resolution change invalidates the import.
            // RenderData/lastDynamicInput still retain their own shared refs;
            // eviction never destroys resources of in-flight command buffers.
            entries_.erase(it);
        }

        // Import first: an exception leaves the valid cache unchanged.
        Image image(device, extent, format, usage, aspect, buffer);
        AHardwareBuffer_acquire(buffer);
        std::shared_ptr<AHardwareBuffer> hold(buffer, [](AHardwareBuffer* p) {
            if (p) AHardwareBuffer_release(p);
        });
        if (entries_.size() >= kMaxCachedBuffers) {
            auto oldest = std::min_element(entries_.begin(), entries_.end(),
                [](const auto& a, const auto& b) {
                    return a.second.lastUsed < b.second.lastUsed;
                });
            if (oldest != entries_.end()) {
                entries_.erase(oldest);
                ++evictions_;
            }
        }
        entries_.emplace(id, Entry{
            image, std::move(hold), d.width, d.height, d.stride, d.format,
            d.usage, format, usage, aspect, ++tick_
        });
        ++misses_;
        report();
        return image;
    }

    void clear() { entries_.clear(); tick_ = 0; }

private:
    struct Entry {
        Image image;
        std::shared_ptr<AHardwareBuffer> retainedBuffer;
        uint32_t width, height, stride, format;
        uint64_t usage;
        VkFormat vkFormat;
        VkImageUsageFlags vkUsage;
        VkImageAspectFlags aspect;
        uint64_t lastUsed;
    };
    std::unordered_map<uint64_t, Entry> entries_;
    uint64_t tick_ = 0;
    uint64_t hits_ = 0, misses_ = 0, evictions_ = 0, uncached_ = 0;

    void report() const {
        const uint64_t n = hits_ + misses_;
        if (n <= 8 || n % 240 == 0)
            __android_log_print(ANDROID_LOG_INFO, "lsfg-ahb-cache",
                "DIRECT_AHB_CACHE hit=%llu miss=%llu evict=%llu entries=%zu uncached=%llu",
                static_cast<unsigned long long>(hits_),
                static_cast<unsigned long long>(misses_),
                static_cast<unsigned long long>(evictions_), entries_.size(),
                static_cast<unsigned long long>(uncached_));
    }
};

} // namespace LSFG::Core
#endif
