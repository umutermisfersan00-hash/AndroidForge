#pragma once

#include "core/buffer.hpp"
#include "core/commandbuffer.hpp"
#include "core/descriptorset.hpp"
#include "core/image.hpp"
#include "core/pipeline.hpp"
#include "core/sampler.hpp"
#include "core/shadermodule.hpp"
#include "common/utils.hpp"

#include <vulkan/vulkan_core.h>

#include <array>
#include <vector>
#include <cstdint>

namespace LSFG_3_1P::Shaders {

    using namespace LSFG;

    ///
    /// Generate shader.
    ///
    class Generate {
    public:
        Generate() = default;

        ///
        /// Initialize the shaderchain.
        ///
        /// @param inImg1 Input image 1.
        /// @param inImg2 Input image 2.
        /// @param inImg3 Input image 3.
        /// @param inImg4 Input image 4.
        /// @param inImg5 Input image 5.
        /// @param fds File descriptors for the output images.
        ///
        /// @throws LSFG::vulkan_error if resource creation fails.
        ///
        Generate(Vulkan& vk,
            Core::Image inImg1, Core::Image inImg2,
            Core::Image inImg3, Core::Image inImg4, Core::Image inImg5,
            const std::vector<int>& fds, VkFormat format);

        /// From pre-allocated output images (Android AHB path).
        Generate(Vulkan& vk,
            Core::Image inImg1, Core::Image inImg2,
            Core::Image inImg3, Core::Image inImg4, Core::Image inImg5,
            std::vector<Core::Image> outImgs);

        ///
        /// Dispatch the shaderchain.
        ///
        void Dispatch(const Core::CommandBuffer& buf, uint64_t frameCount, uint64_t pass_idx);
        void updateDynamicInputs(Vulkan& vk, size_t slot,
                                 const Core::Image& previous, const Core::Image& current);
        void DispatchDynamic(const Core::CommandBuffer& buf, uint64_t frameCount,
                             uint64_t pass_idx, size_t slot,
                             Core::Image& previous, Core::Image& current);
        /// Expose output images for Android queue-family acquire/release.
        [[nodiscard]] std::vector<Core::Image>& getOutImages() { return this->outImgs; }
        [[nodiscard]] const std::vector<Core::Image>& getOutImages() const { return this->outImgs; }

        /// Trivially copyable, moveable and destructible
        Generate(const Generate&) noexcept = default;
        Generate& operator=(const Generate&) noexcept = default;
        Generate(Generate&&) noexcept = default;
        Generate& operator=(Generate&&) noexcept = default;
        ~Generate() = default;
    private:
        Core::ShaderModule shaderModule;
        Core::Pipeline pipeline;
        std::array<Core::Sampler, 2> samplers;
        struct GeneratePass {
            Core::Buffer buffer;
            std::array<Core::DescriptorSet, 2> descriptorSet;
            std::array<Core::DescriptorSet, 8> dynamicDescriptorSet;
            std::array<bool, 8> dynamicDescriptorReady{};
        };
        std::vector<GeneratePass> passes;

        Core::Image inImg1, inImg2;
        Core::Image inImg3, inImg4, inImg5;
        std::vector<Core::Image> outImgs;
    };

}
