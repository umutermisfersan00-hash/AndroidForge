#include <volk.h>
#ifdef __ANDROID__
#include <android/hardware_buffer.h>
#endif
#include <vulkan/vulkan_core.h>

#include "v3_1p/context.hpp"
#include "common/utils.hpp"
#include "common/exception.hpp"

#include <vector>
#include <cstddef>
#include <algorithm>
#include <optional>
#include <cstdint>

using namespace LSFG;
using namespace LSFG_3_1P;

#ifdef __ANDROID__
namespace {

void add_external_acquire(std::vector<VkImageMemoryBarrier2>& barriers,
        Vulkan& vk, Core::Image& image, VkAccessFlags2 accessMask) {
    if (!image.isExternalShared())
        return;

    barriers.emplace_back(VkImageMemoryBarrier2{
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2,
        .srcStageMask = VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT,
        .srcAccessMask = 0,
        .dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
        .dstAccessMask = accessMask,
        .oldLayout = image.getLayout(),
        .newLayout = VK_IMAGE_LAYOUT_GENERAL,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_EXTERNAL,
        .dstQueueFamilyIndex = vk.device.getComputeFamilyIdx(),
        .image = image.handle(),
        .subresourceRange = {
            .aspectMask = image.getAspectFlags(),
            .levelCount = 1,
            .layerCount = 1,
        },
    });
}

void add_external_release(std::vector<VkImageMemoryBarrier2>& barriers,
        Vulkan& vk, Core::Image& image, VkAccessFlags2 accessMask) {
    if (!image.isExternalShared())
        return;

    barriers.emplace_back(VkImageMemoryBarrier2{
        .sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2,
        .srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
        .srcAccessMask = accessMask,
        .dstStageMask = VK_PIPELINE_STAGE_2_BOTTOM_OF_PIPE_BIT,
        .dstAccessMask = 0,
        .oldLayout = image.getLayout(),
        .newLayout = VK_IMAGE_LAYOUT_GENERAL,
        .srcQueueFamilyIndex = vk.device.getComputeFamilyIdx(),
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_EXTERNAL,
        .image = image.handle(),
        .subresourceRange = {
            .aspectMask = image.getAspectFlags(),
            .levelCount = 1,
            .layerCount = 1,
        },
    });
}

void emit_external_barriers(const Core::CommandBuffer& buf,
        const std::vector<VkImageMemoryBarrier2>& barriers) {
    if (barriers.empty())
        return;

    const VkDependencyInfo dependencyInfo{
        .sType = VK_STRUCTURE_TYPE_DEPENDENCY_INFO,
        .imageMemoryBarrierCount = static_cast<uint32_t>(barriers.size()),
        .pImageMemoryBarriers = barriers.data(),
    };
    vkCmdPipelineBarrier2(buf.handle(), &dependencyInfo);
}

} // namespace
#endif

Context::Context(Vulkan& vk,
        int in0, int in1, const std::vector<int>& outN,
        VkExtent2D extent, VkFormat format) {
    // import input images
    this->inImg_0 = Core::Image(vk.device, extent, format,
        VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        VK_IMAGE_ASPECT_COLOR_BIT, in0);
    this->inImg_1 = Core::Image(vk.device, extent, format,
        VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        VK_IMAGE_ASPECT_COLOR_BIT, in1);

    // prepare render data
    for (size_t i = 0; i < 8; i++) {
        auto& data = this->data.at(i);
        data.internalSemaphores.resize(vk.generationCount);
        data.outSemaphores.resize(vk.generationCount);
        data.completionFences.resize(vk.generationCount);
        data.cmdBuffers2.resize(vk.generationCount);
    }

    // create shader chains
    this->mipmaps = Shaders::Mipmaps(vk, this->inImg_0, this->inImg_1);
    for (size_t i = 0; i < 7; i++)
        this->alpha.at(i) = Shaders::Alpha(vk, this->mipmaps.getOutImages().at(i));
    this->beta = Shaders::Beta(vk, this->alpha.at(0).getOutImages());
    for (size_t i = 0; i < 7; i++) {
        this->gamma.at(i) = Shaders::Gamma(vk,
            this->alpha.at(6 - i).getOutImages(),
            this->beta.getOutImages().at(std::min<size_t>(6 - i, 5)),
            (i == 0) ? std::nullopt : std::make_optional(this->gamma.at(i - 1).getOutImage()));
        if (i < 4) continue;

        this->delta.at(i - 4) = Shaders::Delta(vk,
            this->alpha.at(6 - i).getOutImages(),
            this->beta.getOutImages().at(6 - i),
            (i == 4) ? std::nullopt : std::make_optional(this->gamma.at(i - 1).getOutImage()),
            (i == 4) ? std::nullopt : std::make_optional(this->delta.at(i - 5).getOutImage1()),
            (i == 4) ? std::nullopt : std::make_optional(this->delta.at(i - 5).getOutImage2()));
    }
    this->generate = Shaders::Generate(vk,
        this->inImg_0, this->inImg_1,
        this->gamma.at(6).getOutImage(),
        this->delta.at(2).getOutImage1(),
        this->delta.at(2).getOutImage2(),
        outN, format);
}

std::vector<int> Context::present(Vulkan& vk,
        int inSem, const std::vector<int>& outSem) {
#ifdef __ANDROID__
    return this->presentImpl(vk,inSem,outSem,nullptr);
#else
    return {};
#endif
}

#ifdef __ANDROID__
std::vector<int> Context::presentDynamic(Vulkan& vk,AHardwareBuffer* current,
        int inSem,const std::vector<int>& outSem) {
    if(current==nullptr)
        throw LSFG::vulkan_error(VK_ERROR_INITIALIZATION_FAILED,"Dynamic input AHB is null");
    return this->presentImpl(vk,inSem,outSem,current);
}

std::vector<int> Context::presentImpl(Vulkan& vk,int inSem,
        const std::vector<int>& outSem,AHardwareBuffer* dynamicCurrent) {
    auto& data = this->data.at(this->frameIdx % 8);

    // 3. wait for completion of previous frame in this slot
    if (data.shouldWait)
        for (auto& fence : data.completionFences)
            if (!fence.wait(vk.device, UINT64_MAX))
                throw LSFG::vulkan_error(VK_TIMEOUT, "Fence wait timed out");
    data.shouldWait = true;
    const bool dynamic=dynamicCurrent!=nullptr;
    if (!dynamic && this->hasLastDynamicInput) {
        // Restart the direct-input temporal history on a later opt-in.
        // Ring-slot references remain alive until their completion fences.
        this->lastDynamicInput = {};
        this->lastDynamicHold.reset();
        this->hasLastDynamicInput = false;
    }
    const size_t dynamicSlot=this->frameIdx%this->data.size();
    if(dynamic) {
        AHardwareBuffer_Desc desc{};
        AHardwareBuffer_describe(dynamicCurrent,&desc);
        if(desc.width!=this->inImg_0.getExtent().width || desc.height!=this->inImg_0.getExtent().height ||
           desc.format!=AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM ||
           (desc.usage & AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE)==0)
            throw LSFG::vulkan_error(VK_ERROR_FORMAT_NOT_SUPPORTED,"Dynamic input AHB extent/format/usage mismatch");
        auto hold=[](AHardwareBuffer* ahb) {
            AHardwareBuffer_acquire(ahb);
            return std::shared_ptr<AHardwareBuffer>(ahb,[](AHardwareBuffer* p){if(p)AHardwareBuffer_release(p);});
        };
        data.dynamicCurrent = this->directAhbImportCache.get(
            vk.device, dynamicCurrent, this->inImg_0.getExtent(),
            this->inImg_0.getFormat(), VK_IMAGE_USAGE_SAMPLED_BIT,
            VK_IMAGE_ASPECT_COLOR_BIT);
        data.dynamicCurrentHold=hold(dynamicCurrent);
        if(this->hasLastDynamicInput) {
            data.dynamicPrevious=this->lastDynamicInput;
            data.dynamicPreviousHold=this->lastDynamicHold;
        } else {
            data.dynamicPrevious=data.dynamicCurrent;
            data.dynamicPreviousHold=data.dynamicCurrentHold;
        }
        this->mipmaps.updateDynamicInput(vk,dynamicSlot,data.dynamicCurrent);
        this->generate.updateDynamicInputs(vk,dynamicSlot,data.dynamicPrevious,data.dynamicCurrent);
        this->lastDynamicInput=data.dynamicCurrent;
        this->lastDynamicHold=data.dynamicCurrentHold;
        this->hasLastDynamicInput=true;
    }

    // 1. create mipmaps and process input image
    if (inSem >= 0) data.inSemaphore = Core::Semaphore(vk.device, inSem);
    for (size_t i = 0; i < vk.generationCount; i++)
        data.internalSemaphores.at(i) = Core::Semaphore(vk.device);

    data.cmdBuffer1 = Core::CommandBuffer(vk.device, vk.commandPool);
    data.cmdBuffer1.begin();

#ifdef __ANDROID__
    {
        std::vector<VkImageMemoryBarrier2> acquireBarriers;
        acquireBarriers.reserve(2);

        auto& prior = dynamic ? data.dynamicPrevious : this->inImg_0;
        auto& current = dynamic ? data.dynamicCurrent : this->inImg_1;
        add_external_acquire(acquireBarriers,vk,prior,VK_ACCESS_2_SHADER_READ_BIT);
        // On the first dynamic frame prior==current. Duplicate ownership
        // barriers over the same VkImage are not a valid synchronization plan.
        if(prior.handle()!=current.handle())
            add_external_acquire(acquireBarriers,vk,current,VK_ACCESS_2_SHADER_READ_BIT);
        emit_external_barriers(data.cmdBuffer1, acquireBarriers);
    }
#endif

    if(dynamic)this->mipmaps.DispatchDynamic(data.cmdBuffer1,this->frameIdx,dynamicSlot,data.dynamicCurrent);
    else this->mipmaps.Dispatch(data.cmdBuffer1, this->frameIdx);
    for (size_t i = 0; i < 7; i++)
        this->alpha.at(6 - i).Dispatch(data.cmdBuffer1, this->frameIdx);
    this->beta.Dispatch(data.cmdBuffer1, this->frameIdx);

    data.cmdBuffer1.end();
    std::vector<Core::Semaphore> waits = { data.inSemaphore };
    if (inSem < 0) waits.clear();
    data.cmdBuffer1.submit(vk.device.getComputeQueue(), std::nullopt,
        waits, std::nullopt,
        data.internalSemaphores, std::nullopt);

    // 2. generate intermediary frames
    for (size_t pass = 0; pass < vk.generationCount; pass++) {
        auto& internalSemaphore = data.internalSemaphores.at(pass);
        auto& outSemaphore = data.outSemaphores.at(pass);
        if (inSem >= 0) {
            if (outSem.empty()) outSemaphore=Core::Semaphore(vk.device,Core::ExportSyncFdTag{});
            else outSemaphore=Core::Semaphore(vk.device,outSem.at(pass));
        }
        auto& completionFence = data.completionFences.at(pass);
        completionFence = Core::Fence(vk.device);

        auto& buf2 = data.cmdBuffers2.at(pass);
        buf2 = Core::CommandBuffer(vk.device, vk.commandPool);
        buf2.begin();

#ifdef __ANDROID__
        {
            std::vector<VkImageMemoryBarrier2> acquireBarriers;
            acquireBarriers.reserve(1);
            add_external_acquire(acquireBarriers, vk, this->generate.getOutImages().at(pass),
                VK_ACCESS_2_SHADER_WRITE_BIT);
            emit_external_barriers(buf2, acquireBarriers);
        }
#endif

        for (size_t i = 0; i < 7; i++) {
            this->gamma.at(i).Dispatch(buf2, this->frameIdx, pass);
            if (i >= 4)
                this->delta.at(i - 4).Dispatch(buf2, this->frameIdx, pass);
        }
        if(dynamic)this->generate.DispatchDynamic(buf2,this->frameIdx,pass,dynamicSlot,
            data.dynamicPrevious,data.dynamicCurrent);
        else this->generate.Dispatch(buf2, this->frameIdx, pass);

#ifdef __ANDROID__
        {
            std::vector<VkImageMemoryBarrier2> releaseBarriers;
            releaseBarriers.reserve(pass + 1 == vk.generationCount ? 3 : 1);
            add_external_release(releaseBarriers, vk, this->generate.getOutImages().at(pass),
                VK_ACCESS_2_SHADER_WRITE_BIT);
            if (pass + 1 == vk.generationCount) {

                auto& prior = dynamic ? data.dynamicPrevious : this->inImg_0;
                auto& current = dynamic ? data.dynamicCurrent : this->inImg_1;
                add_external_release(releaseBarriers,vk,prior,VK_ACCESS_2_SHADER_READ_BIT);
                if(prior.handle()!=current.handle())
                    add_external_release(releaseBarriers,vk,current,VK_ACCESS_2_SHADER_READ_BIT);
            }
            emit_external_barriers(buf2, releaseBarriers);
        }
#endif

        buf2.end();
        std::vector<Core::Semaphore> signals = { outSemaphore };
        if (inSem < 0) signals.clear();
        buf2.submit(vk.device.getComputeQueue(), completionFence,
            { internalSemaphore }, std::nullopt,
            signals, std::nullopt);
    }

    this->frameIdx++;
    std::vector<int> exported;
    if(inSem>=0&&outSem.empty()){
        exported.reserve(vk.generationCount);
        for(size_t pass=0;pass<vk.generationCount;pass++)
            exported.push_back(data.outSemaphores.at(pass).exportSyncFd(vk.device));
    }
    return exported;
}
#endif

#ifdef __ANDROID__

#include <android/hardware_buffer.h>

Context::Context(Vulkan& vk,
        AHardwareBuffer* in0, AHardwareBuffer* in1,
        const std::vector<AHardwareBuffer*>& outN,
        VkExtent2D extent, VkFormat format) {
    this->inImg_0 = Core::Image(vk.device, extent, format,
        VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        VK_IMAGE_ASPECT_COLOR_BIT, in0);
    this->inImg_1 = Core::Image(vk.device, extent, format,
        VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
        VK_IMAGE_ASPECT_COLOR_BIT, in1);

    std::vector<Core::Image> outImgs;
    outImgs.reserve(outN.size());
    for (auto* ahb : outN) {
        outImgs.emplace_back(vk.device, extent, format,
            VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
            VK_IMAGE_ASPECT_COLOR_BIT, ahb);
    }

    for (size_t i = 0; i < 8; i++) {
        auto& data = this->data.at(i);
        data.internalSemaphores.resize(vk.generationCount);
        data.outSemaphores.resize(vk.generationCount);
        data.completionFences.resize(vk.generationCount);
        data.cmdBuffers2.resize(vk.generationCount);
    }

    this->mipmaps = Shaders::Mipmaps(vk, this->inImg_0, this->inImg_1);
    for (size_t i = 0; i < 7; i++)
        this->alpha.at(i) = Shaders::Alpha(vk, this->mipmaps.getOutImages().at(i));
    this->beta = Shaders::Beta(vk, this->alpha.at(0).getOutImages());
    for (size_t i = 0; i < 7; i++) {
        this->gamma.at(i) = Shaders::Gamma(vk,
            this->alpha.at(6 - i).getOutImages(),
            this->beta.getOutImages().at(std::min<size_t>(6 - i, 5)),
            (i == 0) ? std::nullopt : std::make_optional(this->gamma.at(i - 1).getOutImage()));
        if (i < 4) continue;

        this->delta.at(i - 4) = Shaders::Delta(vk,
            this->alpha.at(6 - i).getOutImages(),
            this->beta.getOutImages().at(6 - i),
            (i == 4) ? std::nullopt : std::make_optional(this->gamma.at(i - 1).getOutImage()),
            (i == 4) ? std::nullopt : std::make_optional(this->delta.at(i - 5).getOutImage1()),
            (i == 4) ? std::nullopt : std::make_optional(this->delta.at(i - 5).getOutImage2()));
    }
    this->generate = Shaders::Generate(vk,
        this->inImg_0, this->inImg_1,
        this->gamma.at(6).getOutImage(),
        this->delta.at(2).getOutImage1(),
        this->delta.at(2).getOutImage2(),
        std::move(outImgs));
}

#endif // __ANDROID__
