# PrismForge 1.9.0 – Capture Efficiency / Capacity Diagnostics

Kiindulás: PrismForge 1.8.1 Safe Optimization. A natív LSFG-könyvtárak,
shader-feldolgozás, GPU-flow = 0.45, Vulkan-szinkronizáció, 120 Hz-es cél,
app-only MediaProjection, 100%-os érintésátengedő overlay és az alapból
korlátlan munkamenet változatlan.

## Konkrét módosítások

1. ImageReader: maxImages 3 -> 2. Az ImageReader.acquireLatestImage()
   Android API-szerződése szerint két foglalható slot elegendő, ha az
   alkalmazás minden megszerzett Image-et bezár (a szolgáltatás ezt teszi).
   Ez csökkentheti az egyszerre fenntartott RGBA-pufferek felső korlátját,
   de a gyártói bufferpool miatt a tényleges RAM-nyereség készülékfüggő.
2. CaptureCadence.Result: az egyetlen capture thread-en újrahasznosított
   eredményobjektum, képenkénti új Java-objektum nélkül. Minden forward/
   timestamp döntés pontosan azonos marad. Stresszteszt: 20 000 esemény,
   azonos digest, 4001 továbblépés és 15 999 ismétlés-kiszűrés.
3. MainActivity: háttérben nem fut, előtérben 800 ms-onként frissít;
   megszűnik az 5/s UI-ébresztés és a felesleges 200 ms-os polling.
4. INPUT_CADENCE: az utolsó játék közben mért értékeket nem törli a
   portré módra visszalépés. Az új session elején viszont resetelődik.
5. CAPACITY_LIMIT: tartós túlterhelésnél legfeljebb 5 másodpercenként
   külön naplósor mutatja a 16,67 ms fölötti natív wall time-ot,
   a natív queue-t és a post FPS-t.

## Amit NEM változtattunk

A szállított liblsfg-android.so min. queueDepth=2 értékre clampel.
A Java-ból kért queueDepth=1 látszatoptimalizáció lenne, ezért nem
került be. A legnagyobb GPU-szűk keresztmetszet (LSFG waitIdle és Vulkan
input/output másolás) megoldása egy új, külön tesztelhető ARM64 natív
könyvtár újrafordítását és Vulkan szinkronizációs vizsgálatot kíván.

## Tesztelés

A 1.8.1 és 1.9.0 összevetése ugyanazon a Genshin útvonalon és azonos
hőállapot mellett javasolt. Figyeld: NATIVE PROFILE wall/waitIdle,
POST_INTERVALS P95/P99, Queue, Thermal status, CAPACITY_LIMIT, FPS.
Amennyiben bármelyik verzióban a kép befagy vagy minősége romlik,
maradjon az 1.8.1 biztonsági mentés.

A ZIP teljes Code on the Go forrásprojekt; a natív .so-k változatlanok.
A Java-források szintaktikailag és XML-ek szerkezetileg ellenőrizve;
Android-device build/futtatás ebben a környezetben nem volt lehetséges.
