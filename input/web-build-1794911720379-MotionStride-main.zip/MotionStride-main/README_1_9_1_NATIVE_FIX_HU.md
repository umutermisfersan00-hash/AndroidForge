# PrismForge 1.9.1 – natív bemeneti másolás / fence kísérlet

## Mi változott?

Az 1.9.0-s PrismForge Java app-only MediaProjection, CaptureCadence, 100%-os
Accessibility overlay és az LSFG 3.1P shaderes számítás változatlan.
A 2.0-s Adaptive Load Guard NINCS ebben a projektben; NEM dobunk el
szándékosan új képkockákat a GPU terhelésének csökkentéséhez.

Az eredeti FrameFlowS25-ből származó LSFG C++ forrás is a projektben van:
- `app/src/main/cpp/lsfg_render_loop.cpp` – a *bemeneti kép másolását* végző
  `copyAhbImage` most egyetlen újrahasznosított Vulkan parancspuffert alkalmaz,
  és `vkQueueWaitIdle` helyett `vkWaitForFences`-t használ ugyanarra a
  másolási parancsra. A fence-et megvárjuk az AHB másik Vulkan eszköznek való
  átadása előtt, tehát a szinkronizációt nem töröltük ki.
- Az LSFG 3.1P `waitIdle()` továbbra is megmaradt, mert az az előállított
  képek felhasználásának helyes kereszt-eszköz szinkronizációja.
- NDK-s Debug buildnél az eredeti C++ könyvtárakat `-O2` optimalizációval
  fordítjuk, nem `-O0`-val.

## Hogyan buildeld Code on the Go-ban?

1. Az `app/build.gradle.kts` már a **teljes ARM64 C++ motorból** fordít natív
   binárist, ha a `gradle.properties` fájlban
   `prismforgeNativeRebuild=true` (alapbeállítás).
2. Szükséges a **Android NDK 27.0.12077973**, valamint **CMake 3.22.1**.
   Ezeket a Code on the Go környezetében kell elérni. NDK hiánya esetén a build
   nem fogja az optimalizált natív kódot lefordítani.
3. `:app:assembleDebug` után telepítsd. A `COPY_SYNC: per-submit fence enabled`
   és `COPY_SYNC: persistent input command buffer allocated` logok csak a
   módosított natív könyvtárból jöhetnek.
4. Ha fordítási vagy runtime gond van, `gradle.properties`:
   `prismforgeNativeRebuild=false`. Ez az 1.9.0-s eredeti, változatlan
   prebuilt `.so`-t csomagolja (app/nativePrebuilt/arm64-v8a/). Csinálj
   clean rebuildet profilváltáskor, hogy ne maradjon bent a régi lib.

## Mire számíts?

Ez nem garantált 120 FPS javítás. A két Vulkan eszköz közötti szinkronizáció
miatt a fő LSFG utáni várakozás még fennáll. A változás a másolás szinkronizációját
célozza, nem csökkenti a flow-skálát és nem módosítja a képet. Mérd a
`copy`, `waitIdle`, `wall`, `POST P95/P99`, `Queue` és thermal értékeket
hidegen és melegen is. Ha a kimenet megszakad, lépj vissza a prebuilt módra.

## Build ellenőrzés

A forrás CMake-szintű konfigurációját itt ellenőriztem, de a jelen környezetben
nincs Android NDK: az ARM64 fordítást és a tényleges eszköztesztet csak a
telefonodon lehet elvégezni. A beküldött korábbi `.so` nincs módosítva.
