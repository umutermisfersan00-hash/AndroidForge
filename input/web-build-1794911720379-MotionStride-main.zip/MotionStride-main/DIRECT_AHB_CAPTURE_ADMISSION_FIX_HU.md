# PrismForge Direct AHB – képfogadási torlódás javítása (v4 kísérlet)

## Cél
A meglévő Direct AHB import-cache megtartása mellett a MediaProjection/ImageReader
callback gyors kiszolgálása. **Nem** változik a popup, a korábbi elnevezés, a
felbontás, a flowScale, az FPS-cél, az LSFG shader vagy a képkockák tartalma.

## Konkrét kódváltozások

1. A `pushFrame` bemeneti várakozósora külön `pendingMu` mutexet használ.
   A Vulkan/WSI kimenet `g.mu` zárát korábban akár a
   `vkAcquireNextImageKHR` alatt is tartotta; most a capture callback nem
   vár emiatt a megjelenítőre.
2. A Java `FrameSignature.hash(image)` eredménye az új
   `pushFrameLeasedWithHash(...)` JNI híváson át a natív belépéshez kerül.
   A natív kód az **ugyanazon 8×8-as FNV képmintát** nem olvassa ki másodszor.
   Ha a hash ismeretlen (`0`), marad a natív hash fallback.
3. A sorból kiszorított és eldobott `ImageReader` képek lezárása a
   `pendingMu` **elengedése után** történik; a `Image.close()` nem tarthatja
   fölöslegesen a capture-admission zárolását.
4. A befejezett Direct AHB kimeneti fence-ek ellenőrzése egy esetleges
   capture-starvation idején 12 ms helyett 4 ms időközzel történik. Az
   ellenőrzés csak akkor aktív, ha ténylegesen van függő kimeneti fence.
5. A motor leállítása explicit letiltja az új bemenet befogadását, mielőtt
   a képkockasort és a Vulkan-eszközt felszabadítja.
6. Az előző, új JNI nélküli Direct AHB binárissal kompatibilis Java-ág
   megmaradt (régi `pushFrameLeased` hívás). Az új ABI azonosító:
   `lsfg-android 0.1.5-direct-ahb-import-cache-capture-admission`.

## Nem változott
- A Direct AHB cache és a másolásos fallback.
- A 60 valódi + 60 generált FPS cél, 120 Hz, 0.45 flow scale.
- A Java-oldali cadence, az input- és output-képek sorrendje, a képminőség.
- A popup feliratai, megjelenése és a teljesítményadatok megnevezései.
- A natív GPU/LSFG szinkronizációs szabályok és az ImageReader-lease funkció.

## Fordítás
A projekt `gradle.properties` értékei továbbra is:

```properties
prismforgeNativeMode=cmake
prismforgeDirectAhb=true
```

Android Studióban: `:app:assembleDebug` és telepítés. A Logcatben az
`lsfg-vk-loop` üzenetei közül az alábbiak igazolják a friss natív motor
használatát / a képfogadási mutex leválasztását:

```text
Native lib: lsfg-android 0.1.5-direct-ahb-import-cache-capture-admission
DIRECT_AHB_CAPTURE_DECOUPLED: input queue is independent of WSI device locks
```

A Direct AHB valódi aktiválódását továbbra is a meglévő
`direct capture-AHB framegen input active` log igazolja. A cache
`DIRECT_AHB_CACHE`, `SESSION_AHB_CACHE` naplói változatlanok.

## Mit mérj?
A **Callback**, **Native forwarded**, **Valódi FPS**, **Generált FPS**,
**Queue**, **copy/waitIdle/wall**, valamint a `DIRECT_AHB_BACKPRESSURE`
bejegyzések különösen fontosak. A cél, hogy a callback üteme a régi
másolásos módhoz közelítsen, miközben a Direct AHB aktív.

## Ellenőrzött és nem ellenőrzött
- `tools/verify_capture_admission.py`: 2000 szimulált képhez egyező
  Java/natív hash, JNI és queue-forrásinvariánsok – sikeres.
- `tools/native_cache_host_test/run.sh`: korábbi cache-teszt – sikeres.
- `tools/verify_direct_ahb_source.py`: korábbi forrásellenőrzés – sikeres.
- CMake-konfiguráció **host** rendszerre stub library útvonallal – sikeres;
  **ez nem ARM64 fordítás**.
- Android ARM64 natív build / S25 élő futási teszt: **nem végrehajtott**.

A változtatás a callback tartós feltartását csökkenti. Ha maga a GPU / LSFG
számítás nem fér bele tartósan 16.67 ms-ba vagy az összes képslot GPU-fence-re
vár, továbbra is lehet FPS-esés. Ez nem GPU-gyorsítás és nem garantált 120 FPS.
