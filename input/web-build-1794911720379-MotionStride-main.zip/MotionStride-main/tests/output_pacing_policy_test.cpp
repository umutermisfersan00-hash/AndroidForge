#include "../app/src/main/cpp/output_pacing_policy.hpp"
#include <cassert>
int main() {
    using lsfg_android::shouldSoftwarePaceOutput;
    assert(!shouldSoftwarePaceOutput(120, 8'333'333, true)); // 120 on 120 Hz WSI
    assert(!shouldSoftwarePaceOutput(60, 16'666'666, true)); // 60 on 60 Hz WSI
    assert( shouldSoftwarePaceOutput(90, 8'333'333, true)); // lower user cap
    assert( shouldSoftwarePaceOutput(120, 8'333'333, false)); // CPU fallback
    assert( shouldSoftwarePaceOutput(120, 0, true)); // no refresh data
    assert(!shouldSoftwarePaceOutput(0, 8'333'333, true)); // unlimited
    assert(!shouldSoftwarePaceOutput(144, 8'333'333, true)); // cap above panel
    return 0;
}
