# PrismForge – Direct Capture AHB (kísérleti kiegészítés, 2026-11-01)

## Mire épül?

A Codex félbeszakadt `codex/direct-capture-ahb` ágának meglévő dinamikus framegen descriptor/image és Vulkan WSI/SYNC_FD munkájára. Nem írja újra a meglevő aszinkron copy/fence fallbacket. A forrásban a közvetlen út elkészült **kísérleti, külön bekapcsolható** módon. A telefonteszt és a teljes Android ARM64 build még HIÁNYZIK. Sem FPS-, sem hőmérséklet-javulás nincs igazolva.

## Mit egészítettem ki?

1. **ImageReader producer-lease**: az `Image` Java-objektum JNI GlobalRefként kerül át a natív sorba; a natív RAII kezelő zárja be, amikor a hozzá tartozó GPU-munka lezárult. AHC `acquire()` önmagában nem akadályozza meg a producer általi újrahasznosítást!
2. **Jelenlegi és korábbi dinamikus input**: a Java `Image` addig foglalt, amíg a saját WSI blitje, illetve a következő dinamikus framegenhez szükséges olvasás be nem fejeződött. A host VkQueue-n a valós képkocka blit-fence-e a megelőző, framegen-kimeneti SYNC_FD-re váró blit után jelződik.
3. **Fence-nyugdíjazás bemenet nélkül is**: a natív worker 12 ms-onként megnézi a befejezett fence-eket, kizárólag akkor, ha van felszabadítandó kép; ez megakadályozza a holtpontot, amikor az ImageReader teljesen elfogyna, és emiatt több kép már nem érkezne.
4. **Hiba-/fallback-kezelés**: a régi másolásos út megmarad, az átmenetkor mindkét állandó input-slot frissül, a dinamikus temporal history kiürül.
5. **Vulkan barrier helyessége**: a legelső közvetlen képnél prev == current; nem bocsátunk ki kétszer egymást átfedő acquire/release vagy shader barriert.
6. **AHB-képességek**: explicit RGBA8 és GPU sampled usage ellenőrzés; a framegen dinamikus képet sampled-only usage módban importálja.
7. **Bináris-azonosító**: az új forrásból létrejövő `liblsfg-android.so` a `lsfg-android 0.1.3-direct-ahb-lease-v2` verziót adja vissza. Ha ehelyett `0.1.2` látható, akkor továbbra is a régi könyvtár fut.

## Kockázatok, amelyek miatt alapból KI van kapcsolva

- Ezt a változatot ebben a futtatókörnyezetben Android NDK híján **nem sikerült natív ARM64-kóddá fordítani**. A CMake konfigurációját ellenőriztem (Linuxon host-library placeholderrel), de ez nem helyettesíti az Android fordítást.
- A dinamikus VkImage-import és a külön VkDevice-ek közötti ownership/SYNC_FD működése csak valódi Adreno/Android 17 telefonon ellenőrizhető. A WSI és a natív bináris logja alapján kell dönteni.
- A 8 ImageReader-slot legfeljebb nyolc aktív képet enged, és extra grafikus memóriát fogyaszt. Nem garantált, hogy ez a felbontás/driver kombináció a közvetlen importot elfogadja.
- Nem állítjuk, hogy tartós 120 FPS már elérhető; ennek az a célja, hogy egy full-frame input GPU-copy eltávolításának hatását mérjük a `copy`, `waitIdle`, `blit`, `wall`, queue és thermal idősoron.

## Fordítás Android Studióban

1. **Először alapútvonal:** `gradle.properties`:

   ```properties
   prismforgeNativeMode=prebuilt
   prismforgeDirectAhb=false
   ```

   A régi, ismert binárissal működik, NEM tartalmazza a kódváltozást.

2. **Új natív forrás, még direct nélkül:**

   ```properties
   prismforgeNativeMode=cmake
   prismforgeDirectAhb=false
   ```

   Android Studio: NDK r27 (`27.0.12077973`) és CMake 3.22.1. Build: `:app:assembleDebug`. Indítsd el és ellenőrizd a natív azonosítót: `lsfg-android 0.1.3-direct-ahb-lease-v2`. Ezután először teszteld a korábbi copy-útvonal működését.

3. **Külön kísérlet, a fentiek sikeres tesztje után:**

   ```properties
   prismforgeNativeMode=cmake
   prismforgeDirectAhb=true
   ```

   Új APK-build szükséges. Csak a fenti azonosítójú natív binárissal aktiválódik a kísérlet. Napló: `DIRECT_AHB_BUILD`, `DIRECT_AHB_ENABLED`, `DIRECT_AHB_CONFIG`, később `direct capture-AHB framegen input active`.

4. Mérések: ugyanazon játékhelyzetben 10–15 perc után `copy`, `waitIdle`, `wall`, `POST_INTERVALS`, hőállapot, valamint `DIRECT_AHB_BACKPRESSURE` megjelenése.

## Visszaállás

`prismforgeDirectAhb=false` — az új natív bináris COPY módban fut. Ha natív crash vagy kép-felhasználási hiba van, `prismforgeNativeMode=prebuilt` is legyen, majd fordítsd újra az APK-t. Gitben a kiinduló `codex/direct-capture-ahb` és `codex/deferred-input-copy` ágak, valamint a mentett tagek megmaradtak.

## Fontos azonosítási szabály

Az APK verziócímkéje vagy egy `CMakeLists.txt` fájl jelenléte **nem** bizonyítja az új motor futását. Csak az APK-ba csomagolt `.so` és a runtime `Native lib:` azonosító számít.
