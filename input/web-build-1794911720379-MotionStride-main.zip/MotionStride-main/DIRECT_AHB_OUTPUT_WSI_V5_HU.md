# PrismForge Direct AHB v5 – WSI kimeneti ütemezés javítása

Kiinduló állapot: v4 `codex/direct-ahb-capture-admission-v4`.

## Mi módosult?

- A GPU-s Vulkan `VK_PRESENT_MODE_FIFO_KHR` kimenetnél a kijelző saját FIFO/vsync ütemezését használjuk. Ha a felhasználói FPS-korlát eléri a kijelző frissítését, a CPU **nem alszik további 8,33 ms-ot minden kimenő kép előtt**. A 120 Hz alatti felhasználói korlát, illetve a CPU-s fallback szoftveres időzítése változatlanul aktív marad.
- A WSI command-buffer/fence ring következő szabad helyét **a `vkAcquireNextImageKHR` előtt** várjuk meg, így a ring túlterheltsége nem tart már lefoglalt swapchain-képet.
- A korlátlan (FPS-cap nélküli) pacing egyik felesleges második várakozása megszűnt: a generált és valódi képek közé már korábban be van ütemezve a szükséges várakozás.
- A WSI kimenethez 120 postos gördülő profil készült (`WSI_OUTPUT_TIMING`). A `acquire`, `acquireMax`, `submit` és `present` *CPU-oldali várakozási idejét* méri. Nem GPU-idő és nem bizonyítja a tényleges kijelzőképek számát.
- Az Android Studio ékezetes Windows-útvonalaihoz beállítva: `android.overridePathCheck=true`.
- Egyedi natív azonosító: `lsfg-android 0.1.6-direct-ahb-wsi-output-pacing`.

**Változatlan:** 60 FPS-es képfogadási javítás, Direct AHB cache és fallback, framegen algoritmus, input-/output-felbontás, flowScale=0.45, popup/HUD, képfeliratok és grafikonok.

## Fordítás

Android Studio, Gradle `:app:assembleDebug`; a projekt `gradle.properties` fájljában a `prismforgeNativeMode=cmake`, `prismforgeDirectAhb=true` értékek maradnak.

## Ellenőrzés a telefonon

1. Android Studio Logcat → `lsfg-vk-loop`.
2. Az új natív buildazonosító jelenjen meg.
3. `Swapchain ready` és `WSI_OUTPUT_TIMING window=120` esetén a Vulkan WSI útvonal aktív; a kimenet várakozásai mérhetők.
4. Ha `WSI blit unavailable ... CPU blit` jelenik meg, a szoftveres limit továbbra is aktív, és a fenti gyorsítás nem lép működésbe.
5. Hasonlítsd össze a v4/v5 kimeneti FPS-ét és a `frame profile` (`waitIdle`, `blitWork`, `wallEnd`, `queue`) értékeit azonos játékszakaszon, hideg és meleg telefonon is.

## Korlátok

Ez egy célzott kimeneti ütemezési és sorfoglalási javítás. A hardveres WSI FIFO továbbra is blokkolhat túlterheléskor, a `vkAcquireNextImageKHR` timeout 500 ms maradt (nem veszünk el szándékosan képkockákat rövidebb timeout miatt), a swapchainbe történő teljes képmásolás megmaradt. Ha a GPU nem képes 60 input-pár + 120 post/sec munkára, ez a módosítás önmagában nem teremt plusz számítási kapacitást.

A host környezetben nincs Android NDK, ezért ARM64 APK-buildet és S25-ös futást nem tudtunk igazolni. A platformfüggetlen pacing-szabály C++ tesztje sikeres.

Biztonságos visszaállás: az előző ág (`codex/direct-ahb-capture-admission-v4`), vagy `prismforgeNativeMode=prebuilt` + `prismforgeDirectAhb=false` (régi natív engine).
