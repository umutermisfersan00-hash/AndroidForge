# PrismForge 1.8 – képkockaütemezés / Capture Cadence

A natív LSFG-motor binárisa, shaderimportja, profilbeállításai, a 100%-os Accessibility overlay, a 120 Hz-es kimeneti kérés és a felület funkciói változatlanok.

## Módosítás

A MediaProjection 120 Hz-es képfogadása során egy 60 FPS-es játék ugyanazt a képkockát többször átadhatja; a különböző képek időbélyegei ingadozhatnak (például 8/25 ms váltakozás). A natív ütemező az érkező képek időbélyeg-különbségét felhasználja a köztes képek posztolásának ütemezéséhez.

Az új `FrameSignature` ugyanazzal a 8×8 RGBA luma/FNV aláírással szűri a duplikátumokat, amelyet a natív motor is használ. A `CaptureCadence` a **különböző** képek időbélyegeit korlátozott fáziskorrekcióval simítja, majd így adja át őket a meglévő `NativeBridge.pushFrame()` hívásnak. Nem változtat képtartalmat, nem dob el egyedi képkockát. Ha a képminták nem olvashatók, az eredeti időbélyeg és a régi útvonal lép életbe.

Ez **nem** cseréli le a natív `liblsfg-android.so` WSI/SurfaceFlinger-kimeneti frame pacerét. Ha a mozgás továbbra is hullámzik, a következő lépés az ARM64 könyvtár C++ pacing loopjának újrafordítása (állandó 8,33 ms-os cél-slotok, a korai postok és a BufferQueue-torlódás kezelése).

## Vizsgálandó értékek

- `INPUT_CADENCE rawJitterP95`: az egyedi bemeneti képkockák intervallumainak eltérése
- `INPUT_CADENCE smoothedJitterP95`: a natív motornak átadott ütem eltérése
- `INPUT_CADENCE dupDrops`: Java-ban már kiszűrt azonos képek; nulla, ha a minták nem olvashatók
- `INPUT_CADENCE unavailable`: az aláírásolvasás sikertelenségeinek száma
- `POST_INTERVALS P50/P95/P99`: natív képkockaposztolások közötti intervallumok (nem tényleges kijelzőre kerülési idők)

Ha az `unavailable` folyamatosan nő, a kímélő fallback aktív, és ez a verzió érdemben nem simítja a bemenetet.

## Ellenőrzés

10 Java-forrás szintaktikai ellenőrzése, ZIP-épségvizsgálat, valamint a tisztán Java `CaptureCadence` szimulációja megtörtént. Teljes Code on the Go Android-build és S25-ös futási teszt nem történt.
